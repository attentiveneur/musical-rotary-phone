import SwiftUI
import UIKit

// MARK: - 动态背景特效层（v6.7.0）
// 三样东西：漂浮粒子 + HUD 扫描光带 + 呼吸光斑。
// 纯 SwiftUI 绘制，iOS 15 起可用，不需要 Metal，也不依赖任何外部资源。
// 只影响观感，不参与任何业务逻辑。

struct LiveFX: View {
    var tint: Color = Mecha.mint
    var warm: Color = Mecha.amber
    var intensity: Double = 1.0
    var showScan: Bool = true
    var particleCount: Int = 42
    var streamCount: Int = 6

    var body: some View {
        TimelineView(.animation(minimumInterval: 1.0 / 30.0)) { ctx in
            let t = ctx.date.timeIntervalSinceReferenceDate
            ZStack {
                if showScan {
                    ScanBeam(tint: tint, t: t)
                }
                Canvas(opaque: false, rendersAsynchronously: true) { context, size in
                    drawDust(&context, size: size, t: t)
                    drawStreams(&context, size: size, t: t)
                }
            }
        }
        .allowsHitTesting(false)
    }

    // MARK: 漂浮粒子

    private func drawDust(_ ctx: inout GraphicsContext, size: CGSize, t: Double) {
        guard size.width > 1, size.height > 1 else { return }
        for i in 0..<max(0, particleCount) {
            let s = Double(i)
            let rx = LiveFX.hash(s * 3.13 + 1.0)
            let ry = LiveFX.hash(s * 7.77 + 2.0)
            let sp = 0.008 + LiveFX.hash(s * 1.37 + 3.0) * 0.026
            let amp = 5.0 + LiveFX.hash(s * 5.11 + 4.0) * 20.0
            let phase = LiveFX.hash(s * 2.97 + 5.0) * 6.28318
            let radius = CGFloat(0.7 + LiveFX.hash(s * 9.31 + 6.0) * 1.7)
            let isWarm = LiveFX.hash(s * 4.41 + 7.0) > 0.86

            var prog = ry + t * sp
            prog -= floor(prog)

            let py = size.height * CGFloat(1.0 - prog)
            let px = size.width * CGFloat(rx) + CGFloat(sin(t * 0.55 + phase) * amp)

            let twinkle = 0.30 + 0.70 * abs(sin(t * (0.70 + LiveFX.hash(s + 11.0) * 1.30) + phase))
            let base = isWarm ? warm : tint
            let a = 0.55 * twinkle * intensity

            // 光晕
            let halo = radius * 3.4
            ctx.fill(Path(ellipseIn: CGRect(x: px - halo, y: py - halo,
                                            width: halo * 2, height: halo * 2)),
                     with: .color(base.opacity(a * 0.10)))
            // 核心
            ctx.fill(Path(ellipseIn: CGRect(x: px - radius, y: py - radius,
                                            width: radius * 2, height: radius * 2)),
                     with: .color(base.opacity(a)))
        }
    }

    // MARK: 竖直数据流

    private func drawStreams(_ ctx: inout GraphicsContext, size: CGSize, t: Double) {
        guard size.width > 1, size.height > 1 else { return }
        for j in 0..<max(0, streamCount) {
            let s = Double(j) + 51.0
            let rx = LiveFX.hash(s * 3.70 + 1.0)
            let sp = 0.030 + LiveFX.hash(s * 1.90 + 2.0) * 0.045
            var prog = LiveFX.hash(s * 5.30 + 3.0) + t * sp
            prog -= floor(prog)

            let py = size.height * CGFloat(1.0 - prog)
            let len = CGFloat(18.0 + LiveFX.hash(s * 2.30 + 4.0) * 46.0)
            let x = size.width * CGFloat(rx)
            let rect = CGRect(x: x - 0.6, y: py - len, width: 1.2, height: len)
            let alpha = 0.20 * intensity * (0.4 + 0.6 * abs(sin(t * 0.8 + s)))

            ctx.fill(Path(roundedRect: rect, cornerRadius: 0.6),
                     with: .color(tint.opacity(alpha)))
        }
    }

    // 稳定的伪随机（同一颗粒每帧位置连续，不会乱跳）
    private static func hash(_ n: Double) -> Double {
        let v = sin(n * 12.9898) * 43758.5453
        return v - floor(v)
    }
}

// MARK: - HUD 扫描光带

struct ScanBeam: View {
    var tint: Color = Mecha.mint
    var t: Double

    var body: some View {
        GeometryReader { geo in
            let h = max(geo.size.height, 1)
            let band: CGFloat = 110
            let p = (sin(t * 0.22) * 0.5 + 0.5)
            Rectangle()
                .fill(
                    LinearGradient(colors: [.clear,
                                            tint.opacity(0.07),
                                            tint.opacity(0.16),
                                            .clear],
                                   startPoint: .top, endPoint: .bottom)
                )
                .frame(height: band)
                .offset(y: -band + CGFloat(p) * (h + band * 2))
        }
        .allowsHitTesting(false)
    }
}

// MARK: - 呼吸光斑（交给系统动画驱动，几乎不耗电）

struct BreathingGlow: View {
    var color: Color
    var corner: UnitPoint = .topTrailing
    @State private var on = false

    var body: some View {
        GeometryReader { geo in
            RadialGradient(colors: [color.opacity(on ? 0.26 : 0.09), .clear],
                           center: corner,
                           startRadius: 0,
                           endRadius: max(geo.size.width, geo.size.height) * 0.85)
                .animation(.easeInOut(duration: 4.6).repeatForever(autoreverses: true), value: on)
                .onAppear { on = true }
        }
        .allowsHitTesting(false)
    }
}

// MARK: - 缓慢推近的图片（自定义背景的动态效果）

struct KenBurnsImage: View {
    var image: UIImage
    @State private var zoom = false

    var body: some View {
        GeometryReader { geo in
            Image(uiImage: image)
                .resizable()
                .scaledToFill()
                .frame(width: geo.size.width, height: geo.size.height)
                .scaleEffect(zoom ? 1.10 : 1.00, anchor: .center)
                .animation(.easeInOut(duration: 22).repeatForever(autoreverses: true), value: zoom)
                .onAppear { zoom = true }
                .clipped()
        }
        .allowsHitTesting(false)
    }
}
