import SwiftUI

// MARK: - 墨绿 HUD 视觉层（v6.7.0）
// 只做外观：切角装甲面板 / 青绿荧光描边 / 橙金警示描边 / HUD 网格背景 / 裂纹质感。
// 不碰任何业务逻辑，内核那套一行不改。

enum Mecha {
    // 主色：青绿
    static let mint  = Color(red: 0.23, green: 0.94, blue: 0.75)
    static let cyan  = Color(red: 0.49, green: 1.00, blue: 0.88)
    // 主色别名（界面各处统一引用，改这一行就整体换色）
    static let blue  = Color(red: 0.23, green: 0.94, blue: 0.75)
    // 警示橙金（② 修复 / ④ 全盘找 pak 用）
    static let amber = Color(red: 1.00, green: 0.66, blue: 0.17)
    static let amberDim = Color(red: 0.72, green: 0.44, blue: 0.10)

    static let steel = Color(red: 0.06, green: 0.20, blue: 0.17)
    static let deep  = Color(red: 0.012, green: 0.046, blue: 0.042)
    static let panelTop = Color(red: 0.035, green: 0.125, blue: 0.110)
    static let panelBottom = Color(red: 0.012, green: 0.055, blue: 0.050)

    static let ok    = Color(red: 0.30, green: 0.95, blue: 0.62)
    static let warn  = Color(red: 1.00, green: 0.72, blue: 0.26)
    static let bad   = Color(red: 1.00, green: 0.36, blue: 0.32)
}

// MARK: - 切角矩形（装甲板外形）

struct ChamferedRect: Shape {
    var cut: CGFloat = 12

    func path(in rect: CGRect) -> Path {
        var p = Path()
        let k = max(0, min(cut, min(rect.width, rect.height) / 2.6))
        p.move(to: CGPoint(x: rect.minX + k, y: rect.minY))
        p.addLine(to: CGPoint(x: rect.maxX - k, y: rect.minY))
        p.addLine(to: CGPoint(x: rect.maxX, y: rect.minY + k))
        p.addLine(to: CGPoint(x: rect.maxX, y: rect.maxY - k))
        p.addLine(to: CGPoint(x: rect.maxX - k, y: rect.maxY))
        p.addLine(to: CGPoint(x: rect.minX + k, y: rect.maxY))
        p.addLine(to: CGPoint(x: rect.minX, y: rect.maxY - k))
        p.addLine(to: CGPoint(x: rect.minX, y: rect.minY + k))
        p.closeSubpath()
        return p
    }
}

// MARK: - 装甲裂纹（按钮上的细划痕，纯装饰）

struct CrackMarks: Shape {
    /// 0…1 的固定折线，按面板尺寸缩放
    private static let lines: [[CGPoint]] = [
        [CGPoint(x: 0.08, y: 0.92), CGPoint(x: 0.30, y: 0.62), CGPoint(x: 0.26, y: 0.34), CGPoint(x: 0.42, y: 0.10)],
        [CGPoint(x: 0.26, y: 0.34), CGPoint(x: 0.52, y: 0.42), CGPoint(x: 0.68, y: 0.30)],
        [CGPoint(x: 0.62, y: 1.00), CGPoint(x: 0.72, y: 0.74), CGPoint(x: 0.94, y: 0.58)],
        [CGPoint(x: 0.72, y: 0.74), CGPoint(x: 0.86, y: 0.84)]
    ]

    func path(in rect: CGRect) -> Path {
        var p = Path()
        for line in CrackMarks.lines {
            guard let first = line.first else { continue }
            p.move(to: CGPoint(x: rect.minX + first.x * rect.width,
                               y: rect.minY + first.y * rect.height))
            for pt in line.dropFirst() {
                p.addLine(to: CGPoint(x: rect.minX + pt.x * rect.width,
                                      y: rect.minY + pt.y * rect.height))
            }
        }
        return p
    }
}

// MARK: - 装甲面板底

struct MechaPanelBackground: View {
    var cut: CGFloat = 12
    var strong: Bool = false
    var accent: Color = Mecha.blue

    var body: some View {
        ZStack {
            ChamferedRect(cut: cut)
                .fill(
                    LinearGradient(colors: [Mecha.panelTop.opacity(0.94),
                                            Mecha.panelBottom.opacity(0.96)],
                                   startPoint: .topLeading,
                                   endPoint: .bottomTrailing)
                )

            ChamferedRect(cut: cut)
                .fill(
                    LinearGradient(colors: [accent.opacity(0.10), .clear],
                                   startPoint: .topLeading,
                                   endPoint: .center)
                )

            ChamferedRect(cut: cut)
                .stroke(
                    LinearGradient(colors: [accent.opacity(strong ? 0.92 : 0.46),
                                            accent.opacity(0.10),
                                            accent.opacity(strong ? 0.62 : 0.22)],
                                   startPoint: .topLeading,
                                   endPoint: .bottomTrailing),
                    lineWidth: strong ? 1.4 : 1
                )

            // 左上角高亮装甲条
            ChamferedRect(cut: cut)
                .trim(from: 0.02, to: 0.16)
                .stroke(accent.opacity(strong ? 0.95 : 0.60), lineWidth: 1.6)

            // 右上角短装甲条（HUD 取景角）
            ChamferedRect(cut: cut)
                .trim(from: 0.70, to: 0.79)
                .stroke(accent.opacity(strong ? 0.70 : 0.28), lineWidth: 1.2)
        }
    }
}

// MARK: - 面板 / 芯片修饰器

extension View {
    func mechaPanel(_ cut: CGFloat = 12, strong: Bool = false, accent: Color = Mecha.blue) -> some View {
        background(MechaPanelBackground(cut: cut, strong: strong, accent: accent))
    }

    func mechaChip(_ cut: CGFloat = 10, accent: Color = Mecha.blue) -> some View {
        background(
            ChamferedRect(cut: cut)
                .fill(accent.opacity(0.10))
                .overlay(
                    ChamferedRect(cut: cut)
                        .stroke(accent.opacity(0.32), lineWidth: 1)
                )
        )
    }
}

// MARK: - HUD 背景（网格 + 斜切光带 + 底部辉光）

struct MechaHUD: View {
    var accent: Color = Mecha.blue

    var body: some View {
        GeometryReader { geo in
            let w = max(geo.size.width, 1)
            let h = max(geo.size.height, 1)
            ZStack {
                Path { p in
                    let step: CGFloat = 26
                    let cols = max(1, Int(w / step))
                    for i in 0...cols {
                        let x = CGFloat(i) * step
                        p.move(to: CGPoint(x: x, y: 0))
                        p.addLine(to: CGPoint(x: x, y: h))
                    }
                    let rows = max(1, Int(h / step))
                    for j in 0...rows {
                        let y = CGFloat(j) * step
                        p.move(to: CGPoint(x: 0, y: y))
                        p.addLine(to: CGPoint(x: w, y: y))
                    }
                }
                .stroke(accent.opacity(0.055), lineWidth: 0.5)

                LinearGradient(colors: [.clear, accent.opacity(0.10), .clear],
                               startPoint: .topLeading,
                               endPoint: .bottomTrailing)
                    .rotationEffect(.degrees(-12))
                    .scaleEffect(1.8)

                LinearGradient(colors: [accent.opacity(0.16), .clear],
                               startPoint: .bottom,
                               endPoint: .top)
                    .frame(height: h * 0.42)
                    .frame(maxHeight: .infinity, alignment: .bottom)
                    .blur(radius: 26)
            }
            .frame(width: geo.size.width, height: geo.size.height)
        }
        .allowsHitTesting(false)
    }
}
