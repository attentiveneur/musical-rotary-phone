import SwiftUI
import UIKit
import Combine
import PhotosUI

// MARK: - 背景外观管理
// 内置几套渐变 + 支持相册自选图片；选择存 UserDefaults，图片存 Documents/background.jpg
final class Appearance: ObservableObject {
    static let shared = Appearance()

    enum BgStyle: Int, CaseIterable, Identifiable {
        case deep = 0
        case night
        case forest
        case plum
        case noir
        case photo
        case mecha

        var id: Int { rawValue }

        var title: String {
            switch self {
            case .deep:   return "深空"
            case .night:  return "午夜蓝"
            case .forest: return "墨绿"
            case .plum:   return "暗紫"
            case .noir:   return "纯黑"
            case .photo:  return "我的图片"
            case .mecha:  return "墨绿机甲"
            }
        }

        var isPhoto: Bool { self == .photo }
    }

    @Published var style: BgStyle = .mecha
    @Published var dim: Double = 0.55
    @Published var image: UIImage? = nil

    private let styleKey = "ls.bg.style"
    private let dimKey   = "ls.bg.dim"

    private var imgURL: URL {
        let d = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)[0]
        return d.appendingPathComponent("background.jpg")
    }

    private init() {
        if let raw = UserDefaults.standard.object(forKey: styleKey) as? Int,
           let s = BgStyle(rawValue: raw) {
            style = s
        }
        if let d = UserDefaults.standard.object(forKey: dimKey) as? Double {
            dim = min(0.85, max(0.15, d))
        }
        if let data = try? Data(contentsOf: imgURL), let img = UIImage(data: data) {
            image = img
        }
        // 选了「我的图片」但文件不在（换机/清缓存），退回深空，别留白屏
        if style == .photo && image == nil {
            style = .mecha
        }
    }

    // MARK: - 配色

    var colors: [Color] {
        switch style {
        case .deep:
            return [Color(red: 0.05, green: 0.06, blue: 0.08),
                    Color(red: 0.08, green: 0.10, blue: 0.15)]
        case .night:
            return [Color(red: 0.02, green: 0.06, blue: 0.15),
                    Color(red: 0.04, green: 0.11, blue: 0.26)]
        case .forest:
            return [Color(red: 0.02, green: 0.09, blue: 0.07),
                    Color(red: 0.04, green: 0.16, blue: 0.12)]
        case .plum:
            return [Color(red: 0.09, green: 0.03, blue: 0.13),
                    Color(red: 0.16, green: 0.06, blue: 0.22)]
        case .noir:
            return [Color.black,
                    Color(red: 0.04, green: 0.04, blue: 0.05)]
        case .photo:
            return [Color(red: 0.05, green: 0.06, blue: 0.08),
                    Color(red: 0.08, green: 0.10, blue: 0.15)]
        case .mecha:
            return [Color(red: 0.010, green: 0.052, blue: 0.046),
                    Color(red: 0.020, green: 0.108, blue: 0.090)]
        }
    }

    var glow: Color {
        switch style {
        case .deep:   return Color(red: 0.30, green: 0.55, blue: 0.95)
        case .night:  return Color(red: 0.25, green: 0.60, blue: 1.00)
        case .forest: return Color(red: 0.25, green: 0.90, blue: 0.60)
        case .plum:   return Color(red: 0.70, green: 0.35, blue: 1.00)
        case .noir:   return Color(red: 0.35, green: 0.35, blue: 0.40)
        case .photo:  return .clear
        case .mecha:  return Color(red: 0.23, green: 0.94, blue: 0.75)
        }
    }

    /// 粒子 / 描边主色（跟当前主题走）
    var accentTint: Color {
        switch style {
        case .deep:   return Color(red: 0.38, green: 0.62, blue: 1.00)
        case .night:  return Color(red: 0.28, green: 0.66, blue: 1.00)
        case .forest: return Color(red: 0.23, green: 0.94, blue: 0.75)
        case .plum:   return Color(red: 0.74, green: 0.42, blue: 1.00)
        case .noir:   return Color(red: 0.85, green: 0.88, blue: 0.90)
        case .photo:  return Color(red: 0.23, green: 0.94, blue: 0.75)
        case .mecha:  return Color(red: 0.23, green: 0.94, blue: 0.75)
        }
    }

    // MARK: - 选择

    func pick(_ s: BgStyle) {
        style = s
        save()
    }

    func setDim(_ v: Double) {
        dim = min(0.85, max(0.15, v))
        save()
    }

    func setImage(_ img: UIImage) {
        let scaled = Appearance.downscale(img, maxSide: 1800)
        if let data = scaled.jpegData(compressionQuality: 0.9) {
            try? data.write(to: imgURL, options: .atomic)
            image = scaled
            style = .photo
            save()
        }
    }

    func clearImage() {
        try? FileManager.default.removeItem(at: imgURL)
        image = nil
        if style == .photo {
            style = .mecha
        }
        save()
    }

    func save() {
        UserDefaults.standard.set(style.rawValue, forKey: styleKey)
        UserDefaults.standard.set(dim, forKey: dimKey)
    }

    static func downscale(_ img: UIImage, maxSide: CGFloat) -> UIImage {
        let w = max(1, img.size.width)
        let h = max(1, img.size.height)
        let m = max(w, h)
        if m <= maxSide { return img }
        let k = maxSide / m
        let size = CGSize(width: w * k, height: h * k)
        let fmt = UIGraphicsImageRendererFormat.default()
        fmt.scale = 1
        fmt.opaque = true
        return UIGraphicsImageRenderer(size: size, format: fmt).image { _ in
            img.draw(in: CGRect(origin: .zero, size: size))
        }
    }
}

// MARK: - 背景层
struct BackgroundLayer: View {
    @ObservedObject private var ap = Appearance.shared

    var body: some View {
        GeometryReader { geo in
            ZStack {
                if ap.style.isPhoto, let img = ap.image {
                    // 自定义图片：缓慢推近，配合下层的粒子一起动
                    KenBurnsImage(image: img)
                        .overlay(Color.black.opacity(ap.dim))
                } else {
                    LinearGradient(colors: ap.colors,
                                   startPoint: .topLeading,
                                   endPoint: .bottomTrailing)
                    RadialGradient(colors: [ap.glow.opacity(0.20), .clear],
                                   center: .topLeading,
                                   startRadius: 0,
                                   endRadius: max(geo.size.width, geo.size.height) * 0.95)
                    BreathingGlow(color: ap.glow, corner: .topTrailing)
                    BreathingGlow(color: ap.glow.opacity(0.7), corner: .bottomLeading)
                }

                if !ap.style.isPhoto {
                    MechaHUD(accent: ap.glow)
                }

                // 动态层：漂浮粒子 + HUD 扫描光带。所有背景都有，自定义图片一样有
                LiveFX(tint: ap.accentTint,
                       warm: Mecha.amber,
                       intensity: ap.style.isPhoto ? 0.85 : 1.0,
                       showScan: !ap.style.isPhoto)

                // 底部压暗一层，保证日志区文字永远看得清
                LinearGradient(colors: [.clear, Color.black.opacity(ap.style.isPhoto ? 0.10 : 0.28)],
                               startPoint: .center,
                               endPoint: .bottom)
            }
            .frame(width: geo.size.width, height: geo.size.height)
        }
        .ignoresSafeArea()
    }
}

// MARK: - 相册选图（PHPicker，不需要相册权限弹窗）

struct PhotoBackgroundPicker: UIViewControllerRepresentable {
    var onPick: (UIImage?) -> Void

    func makeUIViewController(context: Context) -> PHPickerViewController {
        var cfg = PHPickerConfiguration()
        cfg.filter = .images
        cfg.selectionLimit = 1
        let vc = PHPickerViewController(configuration: cfg)
        vc.delegate = context.coordinator
        return vc
    }

    func updateUIViewController(_ uiViewController: PHPickerViewController, context: Context) {}

    func makeCoordinator() -> Coord {
        Coord(onPick: onPick)
    }

    final class Coord: NSObject, PHPickerViewControllerDelegate {
        let onPick: (UIImage?) -> Void

        init(onPick: @escaping (UIImage?) -> Void) {
            self.onPick = onPick
        }

        func picker(_ picker: PHPickerViewController, didFinishPicking results: [PHPickerResult]) {
            picker.dismiss(animated: true)
            guard let provider = results.first?.itemProvider,
                  provider.canLoadObject(ofClass: UIImage.self) else {
                onPick(nil)
                return
            }
            provider.loadObject(ofClass: UIImage.self) { obj, _ in
                DispatchQueue.main.async {
                    self.onPick(obj as? UIImage)
                }
            }
        }
    }
}
