import Foundation
import SwiftUI

final class Store: ObservableObject {

    // 游戏侧
    @Published var gamePath: String? = nil
    @Published var paksDir: String? = nil
    @Published var gamePaks: [PakItem] = []

    // 本机沙盒侧
    @Published var localPaks: [PakItem] = []

    // 规则
    @Published var rules: [Rule] = [] {
        didSet { saveRules() }
    }
    @Published var newOld = ""
    @Published var newNew = ""

    // 状态
    @Published var logs: [String] = []
    @Published var busy = false
    @Published var progressText = ""
    @Published var progressValue: Double = 0
    @Published var banner: String? = nil
    @Published var permOK = false
    @Published var freeSpace = "—"
    @Published var backupOn = true
    @Published var previewMode = false
    @Published var autoShortenOn = true
    @Published var backups: [LSPaths.BackupSet] = []

    // 自动导文件
    @Published var importList: [PakItem] = []
    @Published var overwriteOn = true
    @Published var clearSourceOn = true

    // 导入记录 + 删除已导入的文件
    @Published var imported: [ImportRecord] = []
    @Published var pendingUndo: [ImportRecord] = []
    @Published var undoKeepCopy = true
    @Published var undoRestoreBackup = true
    @Published var showPicker = false
    @Published var gameFileCount = 0
    @Published var scanFound: [PakItem] = []
    @Published var scanNote = ""

    // 弹窗：导入成功 / 修复成功 / 动手前确认，全走这一套
    @Published var alertShown = false
    @Published var alertTitle = ""
    @Published var alertBody = ""
    @Published var alertNeedsConfirm = false
    @Published var pendingGameDelete: [PakItem] = []

    let queue = DispatchQueue(label: "ls.autopak", qos: .userInitiated)
    private let rulesKey = "ls.rules.v5"

    init() {
        LSPaths.ensureDirs()
        loadRules()
        DispatchQueue.main.async { [weak self] in
            self?.refresh()
        }
    }

    // MARK: - 日志

    func log(_ s: String) {
        let line = "[\(Fmt.clock())] \(s)"
        if Thread.isMainThread {
            logs.append(line)
            if logs.count > 800 { logs.removeFirst(logs.count - 800) }
        } else {
            DispatchQueue.main.async { [weak self] in
                guard let self = self else { return }
                self.logs.append(line)
                if self.logs.count > 800 { self.logs.removeFirst(self.logs.count - 800) }
            }
        }
    }

    func ui(_ block: @escaping () -> Void) {
        if Thread.isMainThread { block() } else { DispatchQueue.main.async(execute: block) }
    }

    func setProgress(_ v: Double, _ t: String) {
        ui {
            self.progressValue = v
            self.progressText = t
        }
    }

    // MARK: - 弹窗

    /// 只报结果的弹窗（导入成功 / 修复成功 / 出错）
    func popup(_ title: String, _ body: String, delay: Double = 0) {
        let fire: () -> Void = { [weak self] in
            guard let self = self else { return }
            self.alertTitle = title
            self.alertBody = body
            self.alertNeedsConfirm = false
            self.alertShown = true
        }
        if delay > 0 {
            DispatchQueue.main.asyncAfter(deadline: .now() + delay) { fire() }
        } else {
            ui(fire)
        }
    }

    /// 弹窗里点了「修复」
    func doConfirmedDelete() {
        let gameTargets = pendingGameDelete
        pendingGameDelete = []
        if !gameTargets.isEmpty {
            deleteGameFiles(gameTargets)
        } else {
            undoRun()
        }
    }

    func cancelConfirm() {
        pendingGameDelete = []
        pendingUndo = []
    }

    // MARK: - 规则持久化

    private func loadRules() {
        if let data = UserDefaults.standard.data(forKey: rulesKey),
           let list = try? JSONDecoder().decode([Rule].self, from: data),
           !list.isEmpty {
            rules = list
            return
        }
        // 首次：给两条常用规则，可自己关掉
        rules = [
            Rule(old: "Core", new: "浪神"),
            Rule(old: "@LDUNB", new: "@Zxddy1254")
        ]
    }

    private func saveRules() {
        if let data = try? JSONEncoder().encode(rules) {
            UserDefaults.standard.set(data, forKey: rulesKey)
        }
    }

    func addRule() {
        let o = newOld.trimmingCharacters(in: .whitespacesAndNewlines)
        let n = newNew.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !o.isEmpty, !n.isEmpty else {
            log("✗ 原文和新文都填上才能加")
            return
        }
        if rules.contains(where: { $0.old == o && $0.new == n }) {
            log("· 这条规则已经有了")
            return
        }
        let r = Rule(old: o, new: n)
        rules.append(r)
        newOld = ""
        newNew = ""
        log("✓ 已加规则：\(o) → \(n)")
        let f = PakEngine.feasibility(r)
        log(f.ok ? "  能改：\(f.text)" : "  ⚠️ \(f.text)")
    }

    func deleteRule(_ r: Rule) {
        rules.removeAll { $0.id == r.id }
        log("· 已删规则：\(r.label)")
    }

    func toggleRule(_ r: Rule) {
        if let i = rules.firstIndex(where: { $0.id == r.id }) {
            rules[i].enabled.toggle()
        }
    }

    // MARK: - 刷新

    func refresh() {
        if busy { return }
        log("—— 刷新 ——")
        queue.async { [weak self] in
            guard let self = self else { return }
            let container = LSPaths.gameContainer()
            let pdir = container.flatMap { LSPaths.paksDir(container: $0) }
            let gpaks = container == nil ? [] : LSPaths.listGamePaks(container: container!)
            let locals = LSPaths.listLocalPaks()
            let imports = LSPaths.listImportSources()
            let free = LSPaths.freeSpaceText()
            let bks = LSPaths.backupList()
            let gameAll = pdir.map { LSPaths.listFiles(in: $0, exts: ["pak", "sig"], depth: 3) } ?? []
            let recs = ImportLog.load()

            self.ui {
                self.gamePath = container
                self.paksDir = pdir
                self.gamePaks = gpaks
                self.gameFileCount = gameAll.count
                self.imported = recs
                self.localPaks = locals
                self.importList = imports
                self.freeSpace = free
                self.backups = bks
                self.permOK = (pdir != nil)
                if pdir != nil {
                    self.banner = "已就位：游戏里 \(gpaks.count) 个包，点下面大按钮就完事"
                } else if container != nil {
                    self.banner = "找到游戏容器但没找到 Paks 目录，可能游戏还没启动过一次"
                } else {
                    self.banner = "这台设备没给全盘权限 → 用「改本机的包」模式"
                }
            }

            if let p = pdir {
                self.log("✓ Paks 目录：\(p)")
                self.log("游戏里 pak：\(gpaks.count) 个 · 本机可改：\(locals.count) 个 · 备份：\(bks.count) 份")
            } else {
                self.log("✗ 没拿到游戏 Paks 目录（\(LSPaths.bundleId)）")
            }
        }
    }

    // MARK: - 全自动（游戏里的包）

    func autoRun() {
        guard !busy else { return }
        let active = rules.filter { $0.enabled }
        guard !active.isEmpty else {
            log("✗ 规则全是关的，先去打开一条")
            return
        }
        guard gamePath != nil, let pd = paksDir else {
            log("✗ 还没找到游戏目录。这台设备要是没有全盘权限，就用下面「改本机的包」")
            return
        }
        let paks = gamePaks
        guard !paks.isEmpty else {
            log("✗ Paks 目录里没找到 .pak")
            return
        }

        busy = true
        let snapshot = active
        let preview = previewMode
        let doBackup = backupOn
        let short = autoShortenOn
        log("==== \(preview ? "只看看不改" : "全自动")开始：\(paks.count) 个包，\(snapshot.count) 条规则 ====")
        log("目录：\(pd)")

        queue.async { [weak self] in
            guard let self = self else { return }
            let stamp = Fmt.stamp()
            var totalHits = 0
            var touched = 0
            var failed: [String] = []

            for (i, p) in paks.enumerated() {
                self.setProgress(Double(i) / Double(paks.count), "\(i + 1)/\(paks.count)  \(p.name)")
                self.log("【\(i + 1)/\(paks.count)】\(p.name)  \(p.sizeText)")

                let rep = PakEngine.editFile(p,
                                             rules: snapshot,
                                             backupRoot: LSPaths.backupRoot(),
                                             stamp: stamp,
                                             doBackup: doBackup,
                                             preview: preview,
                                             autoShorten: short)
                self.log("  " + rep.summary)
                totalHits += rep.hitCount
                if rep.hitCount > 0 { touched += 1 }
                if let e = rep.error { failed.append("\(p.name)：\(e)") }
            }

            self.setProgress(1, "完成")
            if preview {
                self.log("==== 看完了：\(touched) 个包里有能改的字，一共 \(totalHits) 处。一个字节都没动 ====")
                self.log("确认没问题，把「只看不改」关掉，再点一次就真改")
            } else {
                self.log("==== 全自动完成：改了 \(touched) 个包，共 \(totalHits) 处 ====")
                if doBackup {
                    self.log("原件已备份到 App 的 Backups/\(stamp)/，不满意可以一键还原")
                }
                self.log("现在退出游戏后台，重新打开游戏看效果")
            }
            if !failed.isEmpty {
                self.log("⚠️ 有 \(failed.count) 个包没改成：")
                for f in failed { self.log("   · \(f)") }
            }

            self.ui {
                self.busy = false
                self.banner = preview
                    ? "预演：\(touched) 个包有可改内容，共 \(totalHits) 处"
                    : "完成：\(touched) 个包 / \(totalHits) 处"
                self.backups = LSPaths.backupList()
            }
            self.refreshGameOnly()
        }
    }

    func refreshGameOnly() {
        guard let container = gamePath else { return }
        queue.async { [weak self] in
            guard let self = self else { return }
            let gpaks = LSPaths.listGamePaks(container: container)
            let pdir = LSPaths.paksDir(container: container)
            let all = pdir.map { LSPaths.listFiles(in: $0, exts: ["pak", "sig"], depth: 3) } ?? []
            self.ui {
                self.gamePaks = gpaks
                self.gameFileCount = all.count
            }
        }
    }

    // MARK: - 自动导文件

    func refreshImportList() {
        guard !busy else { return }
        queue.async { [weak self] in
            guard let self = self else { return }
            let list = LSPaths.listImportSources()
            self.ui { self.importList = list }
            if list.isEmpty {
                self.log("· App 里还没有包：点「③ 从手机里选文件」选一次，选完就存在 App 里，下次不用再挑")
            } else {
                self.log("· 待导入 \(list.count) 个文件：")
                for f in list.prefix(20) { self.log("   · \(f.name)   \(f.sizeText)") }
                if list.count > 20 { self.log("   …… 还有 \(list.count - 20) 个") }
            }
        }
    }

    func importRun() {
        guard !busy else { return }
        guard let pd = paksDir else {
            log("✗ 还没拿到游戏 Paks 目录，导不进去")
            log("  有 3105 的那台：先回主界面把内核漏洞利用点成「已激活」，再回来点刷新")
            log("  没全盘权限的机器：只能用 3105 的文件浏览器手动搬")
            return
        }
        let sources = LSPaths.listImportSources()
        guard !sources.isEmpty else {
            log("✗ App 里还没有能导的包")
            log("  先用「③ 从手机里选文件」选一次：选完就存在这个 App 里，以后不用再进去挑")
            return
        }

        busy = true
        let overwrite = overwriteOn
        let clearSource = clearSourceOn
        let park = LSPaths.importedDir()
        let stamp = Fmt.stamp()
        let total = sources.count

        log("==== 自动导文件：\(total) 个 → \(pd) ====")
        log(overwrite ? "同名会在覆盖前备份原件" : "同名一律跳过（覆盖没开）")

        queue.async { [weak self] in
            guard let self = self else { return }

            let reports = AutoIO.importAll(items: sources,
                                           into: pd,
                                           backupRoot: LSPaths.backupRoot(),
                                           stamp: stamp,
                                           overwrite: overwrite,
                                           clearSource: clearSource,
                                           sourcePark: park) { i, all, name in
                self.setProgress(Double(i) / Double(max(all, 1)), "\(i + 1)/\(all)  \(name)")
            }

            var ok = 0
            var skip = 0
            var bad = 0
            for r in reports {
                if let e = r.error {
                    if r.action.hasPrefix("跳过") {
                        skip += 1
                        self.log("· \(r.name) — \(r.action)：\(e)")
                    } else {
                        bad += 1
                        self.log("✗ \(r.name) — \(r.action)：\(e)")
                    }
                } else {
                    ok += 1
                    let bak = r.backedUp ? "（原件已备份）" : ""
                    self.log("✓ \(r.name) — \(r.action)，\(Fmt.size(r.size))\(bak)")
                    if let dp = r.dstPath {
                        ImportLog.add(ImportRecord(name: r.name,
                                                   gamePath: dp,
                                                   size: r.size,
                                                   time: Fmt.shortDate(),
                                                   action: r.action.contains("覆盖") ? "覆盖" : "新增",
                                                   backupPath: r.backupPath))
                    }
                }
            }

            self.setProgress(1, "完成")
            self.log("==== 导入结束：成功 \(ok) / 跳过 \(skip) / 失败 \(bad)，共 \(total) 个 ====")
            if ok > 0 {
                self.log("原件备份在 Backups/导入前-\(stamp)/，有问题点「还原备份」")
                self.log("包的副本留在 App 库里，下次点「① 导入文件」直接再导一遍，不用再去「文件」里挑")
                self.log("现在退掉游戏后台重新进，看效果")
            }

            let rest = LSPaths.listImportSources()
            let recs = ImportLog.load()
            self.ui {
                self.busy = false
                self.importList = rest
                self.imported = recs
                self.banner = "导入：成功 \(ok) / 共 \(total)"
                if overwrite { self.backups = LSPaths.backupList() }
            }

            if ok > 0 {
                var body = ok == total
                    ? "已写进游戏：\(ok) 个文件\n\n"
                    : "成功 \(ok) 个 / 共 \(total) 个\n"
                if skip > 0 { body += "跳过 \(skip) 个（游戏里已经是这一份）\n" }
                if bad > 0 { body += "失败 \(bad) 个（原因在运行记录里）\n" }
                body += "\n现在退掉游戏后台，重新进游戏看效果。"
                self.popup("导入成功 ✅", body)
            } else if skip > 0 && bad == 0 {
                self.popup("不用再导了", "这 \(skip) 个游戏里已经是最新的了，跳过没重复写。")
            } else {
                self.popup("没导进去", "一个都没成功，看下面运行记录里的原因。")
            }
            self.refreshGameOnly()
        }
    }

    // MARK: - 反向导出（把游戏里的包拷出来）

    func exportRun() {
        guard !busy else { return }
        let paks = gamePaks
        guard !paks.isEmpty else {
            log("✗ 游戏目录里没扫到 .pak，先点「刷新」")
            return
        }
        let out = LSPaths.exportDir()
        busy = true
        let total = paks.count
        log("==== 导出游戏里的包：\(total) 个 → Documents/导出的 ====")

        queue.async { [weak self] in
            guard let self = self else { return }
            let fm = FileManager.default
            if !fm.fileExists(atPath: out.path) {
                try? fm.createDirectory(at: out, withIntermediateDirectories: true)
            }
            var ok = 0
            var bad = 0

            for (i, p) in paks.enumerated() {
                self.setProgress(Double(i) / Double(total), "\(i + 1)/\(total)  \(p.name)")
                let dst = out.appendingPathComponent(p.name)
                try? fm.removeItem(at: dst)
                do {
                    try fm.copyItem(at: p.url, to: dst)
                    let attrs = try? fm.attributesOfItem(atPath: dst.path)
                    let size = (attrs?[.size] as? NSNumber)?.int64Value ?? 0
                    if size == p.size {
                        ok += 1
                        self.log("✓ \(p.name)  \(p.sizeText)")
                    } else {
                        bad += 1
                        self.log("✗ \(p.name) 大小不对（\(p.size) → \(size)）")
                    }
                } catch {
                    bad += 1
                    self.log("✗ \(p.name) 导出失败：\(LSPaths.describe(error))")
                }
            }

            self.setProgress(1, "完成")
            self.log("==== 导出完成：\(ok) 个成功，\(bad) 个有问题 ====")
            self.log("文件在 App 的「导出的」文件夹，用「文件」App 或电脑拷走")
            self.ui {
                self.busy = false
                self.banner = "导出 \(ok) 个包"
            }
        }
    }

    // MARK: - 改本机的包（没全盘权限时用）

    func localRun() {
        guard !busy else { return }
        let active = rules.filter { $0.enabled }
        guard !active.isEmpty else {
            log("✗ 规则全是关的")
            return
        }
        let paks = LSPaths.listLocalPaks()
        guard !paks.isEmpty else {
            log("✗ App 的「文件」里没有 .pak（从别的工具拷进来再刷新）")
            return
        }
        busy = true
        let preview = previewMode
        let short = autoShortenOn
        log("==== 改本机的包：\(paks.count) 个 ====")

        queue.async { [weak self] in
            guard let self = self else { return }
            let stamp = Fmt.stamp()
            var ok = 0
            var fail = 0
            var hits = 0
            let outDir = LSPaths.fixedDir()

            for (i, p) in paks.enumerated() {
                self.setProgress(Double(i) / Double(paks.count), "\(i + 1)/\(paks.count)  \(p.name)")
                // 先备份原件，再在副本上改，原件永远不动
                let work = outDir.appendingPathComponent(p.name)
                let fm = FileManager.default
                try? fm.removeItem(at: work)
                do {
                    try fm.copyItem(at: p.url, to: work)
                } catch {
                    self.log("✗ \(p.name) 复制失败：\(LSPaths.describe(error))")
                    fail += 1
                    continue
                }
                let workItem = PakItem(id: work.path, url: work, size: p.size)
                let rep = PakEngine.editFile(workItem,
                                             rules: active,
                                             backupRoot: LSPaths.backupRoot(),
                                             stamp: stamp,
                                             doBackup: false,
                                             preview: preview,
                                             autoShorten: short)
                self.log(rep.summary)
                if rep.error != nil { fail += 1 } else { ok += 1 }
                hits += rep.hitCount
            }

            self.setProgress(1, "完成")
            self.log("==== 完成：\(ok) 个成功，\(fail) 个有问题，共 \(hits) 处 ====")
            self.log("改好的包在 App 的「改好的」文件夹里，用文件工具拖回游戏 Paks 覆盖")
            self.ui {
                self.busy = false
                self.banner = "本机改包完成：\(ok) 个 / \(hits) 处"
                self.localPaks = LSPaths.listLocalPaks()
            }
        }
    }

    // MARK: - 还原

    func restore(_ set: LSPaths.BackupSet) {
        guard !busy else { return }
        busy = true
        log("==== 还原备份 \(set.stamp)：\(set.files.count) 个文件 ====")
        let pd = paksDir
        queue.async { [weak self] in
            guard let self = self else { return }
            let fm = FileManager.default
            var ok = 0
            for name in set.files {
                let src = set.dir.appendingPathComponent(name)
                let dst: URL
                if let pd = pd {
                    dst = URL(fileURLWithPath: pd).appendingPathComponent(name)
                } else {
                    dst = LSPaths.fixedDir().appendingPathComponent(name)
                }
                do {
                    if fm.fileExists(atPath: dst.path) { try? fm.removeItem(at: dst) }
                    try fm.copyItem(at: src, to: dst)
                    ok += 1
                    self.log("✓ 已还原 \(name)")
                } catch {
                    self.log("✗ \(name) 还原失败：\(LSPaths.describe(error))")
                }
            }
            self.log("==== 还原完成：\(ok)/\(set.files.count) ====")
            self.ui { self.busy = false }
            self.refreshGameOnly()
        }
    }

    func deleteBackup(_ set: LSPaths.BackupSet) {
        try? FileManager.default.removeItem(at: set.dir)
        log("· 已删备份 \(set.stamp)")
        backups = LSPaths.backupList()
    }

    // MARK: - 权限自检

    func selfCheck() {
        log("—— 权限自检 ——")
        let ok = LSPaths.canListContainer()
        let container = LSPaths.gameContainer()
        let pd = container.flatMap { LSPaths.paksDir(container: $0) }
        ui {
            self.permOK = (pd != nil)
            self.banner = pd != nil
                ? "✓ 能直接读写游戏目录，全自动可用"
                : (ok ? "能看容器但没找到 Paks" : "没有全盘权限 → 用「改本机的包」")
        }
        log(ok ? "✓ 能列出 App 容器目录" : "✗ 列不出 App 容器目录")
        if let c = container { log("✓ 游戏容器：\(c)") } else { log("✗ 没定位到 \(LSPaths.bundleId)") }
        if let p = pd { log("✓ Paks：\(p)") } else { log("✗ 没找到 Paks 目录") }
    }
}
