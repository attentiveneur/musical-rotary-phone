import Foundation

/// 自动导文件 + 自动删文件
enum AutoIO {

    // MARK: - 结果结构

    struct ImportReport {
        var name: String
        var action: String
        var error: String? = nil
        var size: Int64 = 0
        var backedUp: Bool = false
        var dstPath: String? = nil
        var backupPath: String? = nil
    }

    /// 撤回一条导入的结果
    struct UndoReport {
        var id: String
        var name: String
        var gamePath: String
        var action: String
        var error: String? = nil
        var holdPath: String? = nil
    }

    struct DeleteReport {
        var name: String
        var path: String
        var size: Int64
        var error: String? = nil
        var movedTo: String? = nil
    }

    // MARK: - 工具

    /// 按时间戳建一个子目录，比如 Backups/导入前-20260101-120000
    static func stampedDir(_ root: URL, _ prefix: String, _ stamp: String) -> URL {
        return root.appendingPathComponent("\(prefix)-\(stamp)", isDirectory: true)
    }

    private static func makeDir(_ url: URL) -> Bool {
        let fm = FileManager.default
        if fm.fileExists(atPath: url.path) { return true }
        do {
            try fm.createDirectory(at: url, withIntermediateDirectories: true)
            return true
        } catch {
            return false
        }
    }

    private static func fileSize(_ path: String) -> Int64 {
        let attrs = try? FileManager.default.attributesOfItem(atPath: path)
        return (attrs?[.size] as? NSNumber)?.int64Value ?? 0
    }

    /// 判断两份是不是同一份：大小一致，再比头尾各 64KB（够用，又快）
    private static func sameContent(_ a: String, _ b: String, _ size: Int64) -> Bool {
        if fileSize(a) != size || fileSize(b) != size { return false }
        if size <= 0 { return true }
        guard let fa = FileHandle(forReadingAtPath: a),
              let fb = FileHandle(forReadingAtPath: b) else { return false }
        defer { fa.closeFile(); fb.closeFile() }

        let chunk = 64 * 1024
        if size <= Int64(chunk) * 2 {
            let da = fa.readData(ofLength: Int(size))
            let db = fb.readData(ofLength: Int(size))
            return da == db
        }
        let ha = fa.readData(ofLength: chunk)
        let hb = fb.readData(ofLength: chunk)
        if ha.count != chunk || ha != hb { return false }
        let off = UInt64(size) - UInt64(chunk)
        _ = fa.seek(toFileOffset: off)
        _ = fb.seek(toFileOffset: off)
        let ta = fa.readData(ofLength: chunk)
        let tb = fb.readData(ofLength: chunk)
        return ta == tb
    }

    /// 把源文件收进 App 的库里（已经在库里就一个字节都不动），返回一句给日志用的尾巴
    private static func parkSource(_ fm: FileManager, _ it: PakItem, _ park: URL) -> String {
        // ⚠️ 这一步是先挪后放，所以「源本来就在库里」时必须直接返回，
        //    否则会把库里那份当成旧文件删掉
        if it.url.path.hasPrefix(park.path + "/") { return " · 已在App库里" }
        if !makeDir(park) { return " · 没存进App库" }
        let dest = park.appendingPathComponent(it.name)
        try? fm.removeItem(at: dest)
        do {
            try fm.moveItem(at: it.url, to: dest)
            return " · 已存进App库"
        } catch {
            return " · 没存进App库"
        }
    }

    // MARK: - 自动导入

    /// 把 items 全部导进 dstDir：同名先备份 → 临时文件写入 → 原子替换 → 核对字节数
    static func importAll(items: [PakItem],
                          into dstDir: String,
                          backupRoot: URL,
                          stamp: String,
                          overwrite: Bool,
                          clearSource: Bool,
                          sourcePark: URL,
                          progress: (Int, Int, String) -> Void) -> [ImportReport] {

        let fm = FileManager.default
        let dstBase = URL(fileURLWithPath: dstDir, isDirectory: true)
        let bakDir = stampedDir(backupRoot, "导入前", stamp)
        var reports: [ImportReport] = []

        for (i, it) in items.enumerated() {
            progress(i, items.count, it.name)

            var rep = ImportReport(name: it.name, action: "", size: it.size)
            let dst = dstBase.appendingPathComponent(it.name)
            let dstPath = dst.path

            var isDir: ObjCBool = false
            let exists = fm.fileExists(atPath: dstPath, isDirectory: &isDir)

            if exists && isDir.boolValue {
                rep.action = "跳过"
                rep.error = "游戏目录里有个同名文件夹，不敢覆盖"
                reports.append(rep)
                continue
            }

            if exists && !overwrite {
                rep.action = "跳过（同名已在，覆盖没开）"
                rep.backedUp = false
                reports.append(rep)
                continue
            }

            // 游戏里已经是这一份了 → 不重复写，省时间也不白备份
            if exists && sameContent(dstPath, it.url.path, it.size) {
                rep.action = "跳过（游戏里已经是这一份）"
                if clearSource { rep.action += parkSource(fm, it, sourcePark) }
                reports.append(rep)
                continue
            }

            // 同名先备份原件，备份不成功就不动它
            if exists {
                if !makeDir(bakDir) {
                    rep.action = "跳过"
                    rep.error = "建备份目录失败，没敢动原文件"
                    reports.append(rep)
                    continue
                }
                let bak = bakDir.appendingPathComponent(it.name)
                try? fm.removeItem(at: bak)
                do {
                    try fm.copyItem(at: dst, to: bak)
                    rep.backedUp = true
                    rep.backupPath = bak.path
                } catch {
                    rep.action = "跳过"
                    rep.error = "备份原件失败（\(LSPaths.describe(error))），没敢动它"
                    reports.append(rep)
                    continue
                }
            }

            // 先写临时文件，成功了再替换，避免中途断了留下半个包
            let tmp = dstBase.appendingPathComponent(".ls_tmp_\(it.name)")
            try? fm.removeItem(at: tmp)
            do {
                try fm.copyItem(at: it.url, to: tmp)
                if exists {
                    try fm.removeItem(at: dst)
                }
                try fm.moveItem(at: tmp, to: dst)
            } catch {
                try? fm.removeItem(at: tmp)
                rep.action = "失败"
                rep.error = LSPaths.describe(error)
                reports.append(rep)
                continue
            }

            // 逐字节核对，大小不一致就算失败
            let after = fileSize(dstPath)
            if after != it.size {
                rep.action = "失败"
                rep.error = "写进去以后大小不对（\(it.size) → \(after)），已停在原地，请用备份还原"
                reports.append(rep)
                continue
            }

            rep.action = exists ? "覆盖成功" : "新增成功"
            rep.dstPath = dstPath

            // 源文件存进 App 的库：以后点「①」直接从库里再导，不用再选文件
            if clearSource {
                rep.action += parkSource(fm, it, sourcePark)
            }

            reports.append(rep)
        }

        progress(items.count, items.count, "完成")
        return reports
    }

    // MARK: - 扫要删的

    /// 在 root 下按关键字 + 后缀找文件（只找，不动手）
    static func scanForDelete(root: String,
                              keyword: String,
                              ext: String,
                              depth: Int = 4,
                              limit: Int = 5000) -> [PakItem] {

        let fm = FileManager.default
        let kw = keyword.trimmingCharacters(in: .whitespacesAndNewlines).lowercased()
        let wantedExt = ext.trimmingCharacters(in: .whitespacesAndNewlines).lowercased()
        var out: [PakItem] = []
        var scanned = 0

        func walk(_ path: String, _ level: Int) {
            if scanned >= limit { return }
            guard let names = try? fm.contentsOfDirectory(atPath: path) else { return }
            for n in names where !n.hasPrefix(".") {
                if scanned >= limit { return }
                let full = path + "/" + n
                var isDir: ObjCBool = false
                guard fm.fileExists(atPath: full, isDirectory: &isDir) else { continue }

                if isDir.boolValue {
                    if level < depth { walk(full, level + 1) }
                    continue
                }

                scanned += 1
                let low = n.lowercased()
                let extOK: Bool = (wantedExt.isEmpty || wantedExt == "any")
                    ? true
                    : low.hasSuffix("." + wantedExt)
                let kwOK: Bool = kw.isEmpty ? true : low.contains(kw)
                if extOK && kwOK {
                    let size = fileSize(full)
                    out.append(PakItem(id: full, url: URL(fileURLWithPath: full), size: size))
                }
            }
        }

        walk(root, 0)
        return out.sorted { $0.name < $1.name }
    }

    // MARK: - 自动删

    /// keepCopy = true 时是「挪到备份」，不是真删，后悔能拿回来
    static func deleteAll(_ targets: [PakItem],
                          backupRoot: URL,
                          stamp: String,
                          keepCopy: Bool,
                          progress: (Int, Int, String) -> Void) -> [DeleteReport] {

        let fm = FileManager.default
        let hold = stampedDir(backupRoot, "删掉的", stamp)
        var reports: [DeleteReport] = []

        for (i, t) in targets.enumerated() {
            progress(i, targets.count, t.name)
            var rep = DeleteReport(name: t.name, path: t.id, size: t.size)

            do {
                if keepCopy {
                    if !makeDir(hold) {
                        rep.error = "建备份目录失败，没删"
                        reports.append(rep)
                        continue
                    }
                    var dest = hold.appendingPathComponent(t.name)
                    if fm.fileExists(atPath: dest.path) {
                        let n = Int(Date().timeIntervalSince1970 * 1000)
                        dest = hold.appendingPathComponent("\(n)_\(t.name)")
                    }
                    try fm.moveItem(at: t.url, to: dest)
                    rep.movedTo = dest.path
                } else {
                    try fm.removeItem(at: t.url)
                }
            } catch {
                rep.error = LSPaths.describe(error)
            }

            reports.append(rep)
        }

        progress(targets.count, targets.count, "完成")
        return reports
    }

    // MARK: - 删除导入的文件（撤回）

    /// 把已经导进游戏的文件撤掉：
    /// 1) 游戏里那份 → 挪进 Backups/删掉的-时间/（或直删）
    /// 2) 当初覆盖过原件的 → 自动把原件写回去
    static func undoImports(_ recs: [ImportRecord],
                            backupRoot: URL,
                            stamp: String,
                            keepCopy: Bool,
                            restoreBackup: Bool,
                            progress: (Int, Int, String) -> Void) -> [UndoReport] {

        let fm = FileManager.default
        let hold = stampedDir(backupRoot, "删掉的", stamp)
        var out: [UndoReport] = []

        for (i, r) in recs.enumerated() {
            progress(i, recs.count, r.name)
            var rep = UndoReport(id: r.id, name: r.name, gamePath: r.gamePath, action: "")
            let game = URL(fileURLWithPath: r.gamePath)
            let existsGame = fm.fileExists(atPath: r.gamePath)

            // 1) 先处理游戏里那份
            if existsGame {
                if keepCopy {
                    if !makeDir(hold) {
                        rep.error = "建备份目录失败，没敢动"
                        out.append(rep)
                        continue
                    }
                    var dest = hold.appendingPathComponent(r.name)
                    if fm.fileExists(atPath: dest.path) {
                        let n = Int(Date().timeIntervalSince1970 * 1000)
                        dest = hold.appendingPathComponent("\(n)_\(r.name)")
                    }
                    do {
                        try fm.moveItem(at: game, to: dest)
                        rep.holdPath = dest.path
                        rep.action = "已修复 · 从游戏撤掉"
                    } catch {
                        rep.error = LSPaths.describe(error)
                        out.append(rep)
                        continue
                    }
                } else {
                    do {
                        try fm.removeItem(at: game)
                        rep.action = "已修复 · 从游戏撤掉"
                    } catch {
                        rep.error = LSPaths.describe(error)
                        out.append(rep)
                        continue
                    }
                }
            } else {
                rep.action = "游戏里本来就没有"
            }

            // 2) 原来是覆盖上传的，把原件还回去
            if restoreBackup, let bp = r.backupPath {
                if fm.fileExists(atPath: bp) {
                    do {
                        if fm.fileExists(atPath: r.gamePath) {
                            try? fm.removeItem(at: game)
                        }
                        try fm.copyItem(at: URL(fileURLWithPath: bp), to: game)
                        rep.action += " · 原件已还原"
                    } catch {
                        rep.action += " · 原件还原失败：\(LSPaths.describe(error))"
                    }
                } else {
                    rep.action += " · 备份里的原件找不到了"
                }
            }

            out.append(rep)
        }

        progress(recs.count, recs.count, "完成")
        return out
    }

    /// 把删掉留着的那一份再放回游戏
    static func putBack(from holdPath: String,
                        to gamePath: String,
                        progress: (Int, Int, String) -> Void) -> String? {

        let fm = FileManager.default
        progress(0, 1, (gamePath as NSString).lastPathComponent)
        guard fm.fileExists(atPath: holdPath) else {
            return "留存的副本不见了：\(holdPath)"
        }
        let src = URL(fileURLWithPath: holdPath)
        let dst = URL(fileURLWithPath: gamePath)
        let tmp = dst.deletingLastPathComponent()
            .appendingPathComponent(".ls_tmp_putback_\(dst.lastPathComponent)")
        try? fm.removeItem(at: tmp)
        do {
            try fm.copyItem(at: src, to: tmp)
            if fm.fileExists(atPath: gamePath) {
                try fm.removeItem(at: dst)
            }
            try fm.moveItem(at: tmp, to: dst)
        } catch {
            try? fm.removeItem(at: tmp)
            return LSPaths.describe(error)
        }
        progress(1, 1, "完成")
        return nil
    }

    // MARK: - 给界面看的一句话说明

    static func extLabel(_ ext: String) -> String {
        switch ext {
        case "pak": return "只 .pak"
        case "sig": return "只 .sig"
        case "any": return "任意后缀"
        default: return ext
        }
    }
}
