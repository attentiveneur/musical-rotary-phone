import SwiftUI
import UIKit
import UniformTypeIdentifiers

/// 原生「文件」面板。
///
/// 为什么不用 SwiftUI 的 .fileImporter：那套面板的回调挂在系统内部的一个宿主对象上，
/// 只要界面在面板打开期间刷新一次（本 App 每秒都在写运行记录、刷进度），
/// 「打开」按钮就变成点上去毫无反应。这里自己当 delegate 并强持有，
/// 而且用 asCopy 让系统先把选中的文件拷一份到本 App 里——大包不用走安全作用域，
/// 选完马上就能读，不会再出现「选了等于没选」。
final class DocPicker: NSObject, UIDocumentPickerDelegate {

    static let shared = DocPicker()

    private var onPick: (([URL]) -> Void)?

    func open(_ completion: @escaping ([URL]) -> Void) {
        guard let host = Self.topViewController() else {
            completion([])
            return
        }
        // 已经开着一个了，别叠第二层
        if host is UIDocumentPickerViewController { return }

        onPick = completion

        var types: [UTType] = [.data]
        for ext in ["pak", "sig", "zip", "obb", "bin"] {
            if let t = UTType(filenameExtension: ext), !types.contains(t) {
                types.append(t)
            }
        }

        let vc = UIDocumentPickerViewController(forOpeningContentTypes: types, asCopy: true)
        vc.delegate = self
        vc.allowsMultipleSelection = true
        vc.shouldShowFileExtensions = true
        vc.modalPresentationStyle = .fullScreen

        DispatchQueue.main.async {
            host.present(vc, animated: true)
        }
    }

    // MARK: - UIDocumentPickerDelegate

    func documentPicker(_ controller: UIDocumentPickerViewController,
                        didPickDocumentsAt urls: [URL]) {
        let cb = onPick
        onPick = nil
        cb?(urls)
    }

    func documentPickerWasCancelled(_ controller: UIDocumentPickerViewController) {
        let cb = onPick
        onPick = nil
        cb?([])
    }

    // MARK: - 找最上层的界面

    static func topViewController() -> UIViewController? {
        let scenes = UIApplication.shared.connectedScenes.compactMap { $0 as? UIWindowScene }
        var window = scenes.flatMap { $0.windows }.first(where: { $0.isKeyWindow })
        if window == nil { window = scenes.first?.windows.first }
        var vc = window?.rootViewController
        while let p = vc?.presentedViewController, !p.isBeingDismissed {
            vc = p
        }
        return vc
    }
}
