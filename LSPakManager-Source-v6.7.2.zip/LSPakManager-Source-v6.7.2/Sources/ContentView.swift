import SwiftUI
import UniformTypeIdentifiers

struct ContentView: View {
    @EnvironmentObject var store: Store
    @ObservedObject private var kernel = KernelEngine.shared
    @State private var tab = 0
    @State private var showAdvanced = false
    @ObservedObject private var ap = Appearance.shared
    @State private var showBg = false
    @State private var showPhotoPicker = false

    var body: some View {
        ZStack {
            BackgroundLayer()

            ScrollView {
                VStack(spacing: 12) {
                    statusCard
                    kernelCard
                    actionGrid
                    switchRow
                    listCard
                    progressCard
                    advancedCard
                    logCard
                }
                .padding(.horizontal, 14)
                .padding(.top, 10)
                .padding(.bottom, 26)
            }
        }
        .preferredColorScheme(.dark)
        .onChange(of: kernel.phase) { ph in
            if ph == .ready { store.refresh() }
        }
        .alert(store.alertTitle, isPresented: $store.alertShown) {
            if store.alertNeedsConfirm {
                Button("取消", role: .cancel) { store.cancelConfirm() }
                Button("修复") { store.doConfirmedDelete() }
            } else {
                Button("好", role: .cancel) { }
            }
        } message: {
            Text(store.alertBody)
        }
        .sheet(isPresented: $showBg) {
            bgSheet
        }
    }

    // MARK: - 背景面板

    private var bgSheet: some View {
        NavigationView {
            ScrollView {
                VStack(alignment: .leading, spacing: 16) {
                    Text("选一个背景")
                        .font(.system(size: 15, weight: .heavy))
                        .foregroundColor(.white)
                    Text("内置几套现成的，也可以用相册里自己的图。选完自动记住，下次打开还是这个。")
                        .font(.system(size: 11.5))
                        .foregroundColor(.white.opacity(0.45))
                        .fixedSize(horizontal: false, vertical: true)

                    LazyVGrid(columns: [GridItem(.flexible(), spacing: 10),
                                        GridItem(.flexible(), spacing: 10),
                                        GridItem(.flexible(), spacing: 10)],
                              spacing: 12) {
                        ForEach(Appearance.BgStyle.allCases) { s in
                            Button {
                                if s.isPhoto && ap.image == nil {
                                    showPhotoPicker = true
                                } else {
                                    ap.pick(s)
                                }
                            } label: {
                                bgSwatch(s)
                            }
                        }
                    }

                    Divider().background(Color.white.opacity(0.1))

                    Button {
                        showPhotoPicker = true
                    } label: {
                        HStack(spacing: 8) {
                            Image(systemName: "photo.on.rectangle.angled")
                                .font(.system(size: 14, weight: .semibold))
                            Text(ap.image == nil ? "从相册选一张图" : "换一张相册里的图")
                                .font(.system(size: 13, weight: .semibold))
                            Spacer()
                        }
                        .foregroundColor(.white)
                        .padding(.vertical, 12)
                        .padding(.horizontal, 13)
                        .frame(maxWidth: .infinity)
                        .mechaPanel(10)
                    }

                    if ap.image != nil {
                        VStack(alignment: .leading, spacing: 8) {
                            HStack {
                                Text("压暗程度")
                                    .font(.system(size: 12.5, weight: .semibold))
                                    .foregroundColor(.white.opacity(0.75))
                                Spacer()
                                Text("\(Int(ap.dim * 100))%")
                                    .font(.system(size: 11, design: .monospaced))
                                    .foregroundColor(.white.opacity(0.45))
                            }
                            Slider(value: Binding(get: { ap.dim },
                                                  set: { ap.setDim($0) }),
                                   in: 0.15...0.85)
                                .tint(Mecha.blue)
                            Text("图片太亮、字看不清就往上拉；想更透就往左。")
                                .font(.system(size: 10))
                                .foregroundColor(.white.opacity(0.35))
                            Button {
                                ap.clearImage()
                            } label: {
                                Text("删掉这张图")
                                    .font(.system(size: 11.5, weight: .semibold))
                                    .foregroundColor(Mecha.bad)
                            }
                        }
                        .padding(13)
                        .mechaPanel(10)
                    }
                }
                .padding(16)
            }
            .background(Mecha.deep.ignoresSafeArea())
            .navigationTitle("背景")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .navigationBarTrailing) {
                    Button("完成") { showBg = false }
                        .foregroundColor(.cyan)
                }
            }
        }
        .preferredColorScheme(.dark)
        .sheet(isPresented: $showPhotoPicker) {
            PhotoBackgroundPicker { img in
                showPhotoPicker = false
                if let img = img {
                    ap.setImage(img)
                }
            }
        }
    }

    private func bgSwatch(_ s: Appearance.BgStyle) -> some View {
        let picked = ap.style == s
        return VStack(spacing: 6) {
            ZStack {
                if s.isPhoto {
                    if let img = ap.image {
                        Image(uiImage: img)
                            .resizable()
                            .scaledToFill()
                    } else {
                        Color.white.opacity(0.06)
                        Image(systemName: "plus")
                            .font(.system(size: 16, weight: .bold))
                            .foregroundColor(.white.opacity(0.5))
                    }
                } else {
                    LinearGradient(colors: bgPreviewColors(s),
                                   startPoint: .topLeading,
                                   endPoint: .bottomTrailing)
                }
            }
            .frame(height: 62)
            .clipShape(ChamferedRect(cut: 8))
            .overlay(
                ChamferedRect(cut: 8)
                    .stroke(picked ? Mecha.blue : Mecha.blue.opacity(0.20),
                            lineWidth: picked ? 2 : 1)
            )
            .overlay(
                Group {
                    if picked {
                        Image(systemName: "checkmark.circle.fill")
                            .font(.system(size: 15, weight: .bold))
                            .foregroundColor(Mecha.blue)
                            .padding(5)
                    }
                },
                alignment: .topTrailing
            )

            Text(s.title)
                .font(.system(size: 10.5, weight: picked ? .bold : .regular))
                .foregroundColor(picked ? .white : .white.opacity(0.55))
        }
    }

    private func bgPreviewColors(_ s: Appearance.BgStyle) -> [Color] {
        switch s {
        case .deep:
            return [Color(red: 0.05, green: 0.06, blue: 0.08),
                    Color(red: 0.08, green: 0.10, blue: 0.15)]
        case .night:
            return [Color(red: 0.02, green: 0.06, blue: 0.15),
                    Color(red: 0.04, green: 0.11, blue: 0.26)]
        case .forest:
            return [Color(red: 0.02, green: 0.09, blue: 0.07),
                    Color(red: 0.04, green: 0.16, blue: 0.12)]
        case .plum:
            return [Color(red: 0.09, green: 0.03, blue: 0.13),
                    Color(red: 0.16, green: 0.06, blue: 0.22)]
        case .noir:
            return [Color.black, Color(red: 0.04, green: 0.04, blue: 0.05)]
        case .photo:
            return [Color.white.opacity(0.06), Color.white.opacity(0.03)]
        case .mecha:
            return [Color(red: 0.015, green: 0.035, blue: 0.075),
                    Color(red: 0.030, green: 0.105, blue: 0.215)]
        }
    }

    private var activeImportCount: Int {
        store.imported.filter { !$0.deleted }.count
    }

    // MARK: - 顶部

    private var statusCard: some View {
        VStack(alignment: .leading, spacing: 8) {
            HStack(spacing: 10) {
                Text("浪神文件管理器")
                    .font(.system(size: 25, weight: .heavy))
                    .kerning(1.5)
                    .foregroundStyle(
                        LinearGradient(colors: [Color.white, Mecha.cyan],
                                       startPoint: .topLeading,
                                       endPoint: .bottomTrailing)
                    )
                    .lineLimit(1)
                    .minimumScaleFactor(0.7)

                Spacer()

                Button {
                    showBg = true
                } label: {
                    Image(systemName: "photo.on.rectangle.angled")
                        .font(.system(size: 13, weight: .semibold))
                        .foregroundColor(.white.opacity(0.75))
                        .frame(width: 32, height: 30)
                        .mechaPanel(8)
                }
            }

            HStack(spacing: 6) {
                Image(systemName: store.paksDir == nil ? "exclamationmark.triangle.fill" : "checkmark.circle.fill")
                    .font(.system(size: 13, weight: .bold))
                Text(store.paksDir == nil ? (kernel.ready ? "内核已激活，但还没定位到游戏目录（点 ④ 全盘找）" : "还没拿到游戏目录 —— 先点下面「一键激活内核」") : "已找到：\(LSPaths.bundleId)")
                    .font(.system(size: 13.5, weight: .semibold))
                    .lineLimit(1)
                    .minimumScaleFactor(0.65)
            }
            .foregroundColor(store.paksDir == nil ? .orange : Mecha.ok)

            Text("游戏内 pak/sig \(store.gameFileCount) 个 · 待导入 \(store.importList.count) 个 · 已导入 \(activeImportCount) 个")
                .font(.system(size: 11.5))
                .foregroundColor(.white.opacity(0.42))
                .lineLimit(2)

            if let b = store.banner {
                Text(b)
                    .font(.system(size: 10.5))
                    .foregroundColor(.white.opacity(0.52))
                    .fixedSize(horizontal: false, vertical: true)
            }
        }
        .frame(maxWidth: .infinity, alignment: .leading)
        .padding(13)
        .mechaPanel(12)
    }

    // MARK: - 内核引擎

    private var kernelCard: some View {
        VStack(alignment: .leading, spacing: 9) {
            HStack(spacing: 7) {
                Image(systemName: kernel.ready ? "bolt.shield.fill" : "bolt.slash.fill")
                    .font(.system(size: 14, weight: .bold))
                    .foregroundColor(kernel.ready ? Mecha.ok
                                                  : Mecha.warn)
                Text("内核引擎")
                    .font(.system(size: 14.5, weight: .heavy))
                    .foregroundColor(.white)
                Spacer()
                Text(kernel.stageText)
                    .font(.system(size: 11.5, weight: .semibold))
                    .foregroundColor(kernel.ready ? Mecha.ok
                                                  : Mecha.warn)
            }

            Text(kernel.detailText)
                .font(.system(size: 11))
                .foregroundColor(.white.opacity(0.5))
                .fixedSize(horizontal: false, vertical: true)

            if kernel.running {
                ProgressView(value: max(0.02, kernel.progress))
                    .tint(Mecha.blue)
            }

            Button {
                kernel.activate()
            } label: {
                HStack(spacing: 6) {
                    Image(systemName: kernel.ready ? "arrow.triangle.2.circlepath" : "bolt.fill")
                        .font(.system(size: 12.5, weight: .bold))
                    Text(kernel.ready ? "已激活 · 点这里重跑一次"
                                      : (kernel.running ? "正在激活…" : "一键激活内核 · 全盘读写"))
                        .font(.system(size: 13.5, weight: .bold))
                }
                .foregroundColor(.white)
                .frame(maxWidth: .infinity)
                .padding(.vertical, 11)
                .background(
                    LinearGradient(colors: kernel.ready
                                   ? [Color(red: 0.16, green: 0.45, blue: 0.30), Color(red: 0.12, green: 0.36, blue: 0.26)]
                                   : [Color(red: 0.36, green: 0.24, blue: 0.72), Color(red: 0.24, green: 0.42, blue: 0.86)],
                                   startPoint: .leading, endPoint: .trailing)
                )
                .clipShape(ChamferedRect(cut: 11))
                .overlay(ChamferedRect(cut: 11).stroke(Mecha.cyan.opacity(0.55), lineWidth: 1))
            }
            .disabled(kernel.running)

            if !kernel.logLines.isEmpty {
                DisclosureGroup {
                    VStack(alignment: .leading, spacing: 2) {
                        ForEach(Array(kernel.logLines.suffix(40).enumerated()), id: \.offset) { _, line in
                            Text(line)
                                .font(.system(size: 9.5, design: .monospaced))
                                .foregroundColor(.white.opacity(0.45))
                                .frame(maxWidth: .infinity, alignment: .leading)
                        }
                    }
                    .padding(.top, 4)
                } label: {
                    Text("引擎日志（\(kernel.logLines.count) 行）")
                        .font(.system(size: 10.5, weight: .semibold))
                        .foregroundColor(.white.opacity(0.42))
                }
                .tint(.white.opacity(0.4))
            }
        }
        .frame(maxWidth: .infinity, alignment: .leading)
        .padding(13)
        .mechaPanel(12)
    }

    // MARK: - 四个大按钮

    private var actionGrid: some View {
        LazyVGrid(columns: [GridItem(.flexible(), spacing: 9),
                            GridItem(.flexible(), spacing: 9)], spacing: 9) {
            bigButton("① 导入文件", "arrow.down.doc.fill",
                      Mecha.mint,
                      store.importList.isEmpty ? "待导入 0 个" : "待导入 \(store.importList.count) 个") {
                store.importRun()
            }

            bigButton("② 修复", "trash.fill",
                      activeImportCount > 0 ? Mecha.amber : Mecha.amberDim,
                      activeImportCount > 0 ? "点一下修复（\(activeImportCount) 个）" : "还没导入过") {
                store.askDeleteImports()
            }

            bigButton("③ 从手机里选文件", "square.and.arrow.down",
                      Mecha.blue,
                      "选完自动进「待导入」") {
                store.openFilePicker()
            }

            bigButton("④ 全盘找 pak", "magnifyingglass",
                      Mecha.amber,
                      store.scanNote.isEmpty ? "看看游戏里都有啥" : store.scanNote) {
                tab = 2
                store.fullScan()
            }
        }
    }

    private func bigButton(_ title: String, _ icon: String, _ color: Color,
                           _ sub: String, _ action: @escaping () -> Void) -> some View {
        Button(action: action) {
            VStack(alignment: .leading, spacing: 4) {
                HStack(spacing: 5) {
                    Image(systemName: icon).font(.system(size: 13, weight: .bold))
                    Text(title)
                        .font(.system(size: 13, weight: .bold))
                        .lineLimit(1)
                        .minimumScaleFactor(0.65)
                }
                Text(sub)
                    .font(.system(size: 9.5))
                    .opacity(0.65)
                    .lineLimit(1)
            }
            .foregroundColor(.white)
            .frame(maxWidth: .infinity, alignment: .leading)
            .padding(.horizontal, 12)
            .padding(.vertical, 14)
            .background(
                ChamferedRect(cut: 12)
                    .fill(LinearGradient(colors: [color.opacity(0.95), color.opacity(0.38)],
                                         startPoint: .topLeading, endPoint: .bottomTrailing))
            )
            .overlay(
                ChamferedRect(cut: 12)
                    .stroke(color.opacity(0.80), lineWidth: 1)
            )
        }
        .disabled(store.busy)
    }

    // MARK: - 开关

    private var switchRow: some View {
        HStack(spacing: 9) {
            chip(store.undoKeepCopy ? "备份：开" : "备份：关",
                 "externaldrive.fill",
                 store.undoKeepCopy ? .green : .gray) {
                store.undoKeepCopy.toggle()
            }
            chip(store.undoRestoreBackup ? "还原原件：开" : "还原原件：关",
                 "arrow.uturn.backward",
                 store.undoRestoreBackup ? .green : .gray) {
                store.undoRestoreBackup.toggle()
            }
            chip("刷新", "arrow.clockwise", .cyan) {
                store.refresh()
            }
        }
    }

    private func chip(_ t: String, _ icon: String, _ c: Color,
                      _ act: @escaping () -> Void) -> some View {
        Button(action: act) {
            HStack(spacing: 5) {
                Image(systemName: icon).font(.system(size: 11, weight: .semibold))
                Text(t)
                    .font(.system(size: 11.5, weight: .medium))
                    .lineLimit(1)
                    .minimumScaleFactor(0.75)
            }
            .foregroundColor(c)
            .frame(maxWidth: .infinity)
            .padding(.vertical, 10)
            .mechaChip(10, accent: c)
        }
        .disabled(store.busy)
    }

    private func smallButton(_ t: String, _ icon: String, _ c: Color,
                             _ act: @escaping () -> Void) -> some View {
        Button(action: act) {
            HStack(spacing: 5) {
                Image(systemName: icon).font(.system(size: 11, weight: .semibold))
                Text(t).font(.system(size: 10.5)).lineLimit(1).minimumScaleFactor(0.75)
            }
            .foregroundColor(.white.opacity(0.8))
            .frame(maxWidth: .infinity)
            .padding(.vertical, 9)
            .mechaPanel(10)
        }
        .disabled(store.busy)
    }

    // MARK: - 待导入 / 已导入

    private var listCard: some View {
        VStack(alignment: .leading, spacing: 9) {
            HStack(spacing: 0) {
                tabButton("待导入 \(store.importList.count)", 0)
                tabButton("已导入 \(activeImportCount)", 1)
                tabButton("游戏里的包 \(store.scanFound.count)", 2)
            }
            .padding(3)
            .mechaPanel(10)

            if tab == 0 {
                if store.importList.isEmpty {
                    emptyHint("App 里还没有包。点「③ 从手机里选文件」选一次就存进 App，以后点「① 导入文件」直接导，不用再进去挑")
                } else {
                    ForEach(Array(store.importList.prefix(60)), id: \.id) { f in
                        rowWaiting(f)
                    }
                    if store.importList.count > 60 {
                        Text("…… 还有 \(store.importList.count - 60) 个")
                            .font(.system(size: 10))
                            .foregroundColor(.white.opacity(0.3))
                    }
                }
            } else if tab == 1 {
                if store.imported.isEmpty {
                    emptyHint("还没有导入记录。用「① 导入文件」导进去的会自动记账，这里就能撤")
                } else {
                    ForEach(Array(store.imported.prefix(60))) { r in
                        rowImported(r)
                    }
                    if store.imported.count > 60 {
                        Text("…… 还有 \(store.imported.count - 60) 条")
                            .font(.system(size: 10))
                            .foregroundColor(.white.opacity(0.3))
                    }
                }
            } else {
                if store.scanFound.isEmpty {
                    emptyHint("点「④ 全盘找 pak」扫一遍。扫出来的包都在这儿列着，一个个挑着删，不按关键字乱删")
                } else {
                    ForEach(Array(store.scanFound.prefix(80))) { it in
                        rowGame(it)
                    }
                    if store.scanFound.count > 80 {
                        Text("…… 还有 \(store.scanFound.count - 80) 个")
                            .font(.system(size: 10))
                            .foregroundColor(.white.opacity(0.3))
                    }
                }
            }

            HStack(spacing: 9) {
                smallButton("清掉失效记录", "bandage.fill", .orange) {
                    store.pruneRecords()
                }
            }
        }
        .padding(12)
        .mechaPanel(12)
    }

    private func tabButton(_ t: String, _ idx: Int) -> some View {
        Button(action: { tab = idx }) {
            Text(t)
                .font(.system(size: 12.5, weight: .semibold))
                .foregroundColor(tab == idx ? .white : .white.opacity(0.4))
                .frame(maxWidth: .infinity)
                .padding(.vertical, 8)
                .background(tab == idx ? Mecha.blue.opacity(0.22) : Color.clear)
                .clipShape(ChamferedRect(cut: 7))
        }
    }

    private func emptyHint(_ t: String) -> some View {
        Text(t)
            .font(.system(size: 10.5))
            .foregroundColor(.white.opacity(0.32))
            .frame(maxWidth: .infinity, alignment: .leading)
            .padding(.vertical, 8)
            .fixedSize(horizontal: false, vertical: true)
    }

    private func rowWaiting(_ f: PakItem) -> some View {
        HStack(spacing: 8) {
            Image(systemName: "doc.fill")
                .font(.system(size: 11))
                .foregroundColor(.white.opacity(0.3))
            VStack(alignment: .leading, spacing: 1) {
                Text(f.name)
                    .font(.system(size: 12.5, weight: .medium))
                    .foregroundColor(.white.opacity(0.9))
                    .lineLimit(1)
                    .truncationMode(.middle)
                Text("\(f.sizeText) · \(tailPath(f.id, "待导入"))")
                    .font(.system(size: 9.5))
                    .foregroundColor(.white.opacity(0.35))
                    .lineLimit(1)
                    .truncationMode(.middle)
            }
            Spacer()
            Image(systemName: "checkmark")
                .font(.system(size: 12, weight: .bold))
                .foregroundColor(.green)
        }
        .padding(.vertical, 5)
        .padding(.horizontal, 9)
        .mechaPanel(8)
    }

    private func rowImported(_ r: ImportRecord) -> some View {
        HStack(spacing: 8) {
            Image(systemName: r.deleted ? "xmark.square" : (r.statusOK ? "checkmark.square.fill" : "questionmark.square"))
                .font(.system(size: 11))
                .foregroundColor(r.deleted ? .white.opacity(0.25) : (r.statusOK ? .green : .orange))
            VStack(alignment: .leading, spacing: 1) {
                Text(r.name)
                    .font(.system(size: 12.5, weight: .medium))
                    .foregroundColor(.white.opacity(r.deleted ? 0.45 : 0.9))
                    .lineLimit(1)
                    .truncationMode(.middle)
                Text("\(r.sizeText) · \(r.statusText) · \(r.time)")
                    .font(.system(size: 9.5))
                    .foregroundColor(.white.opacity(0.35))
                    .lineLimit(1)
            }
            Spacer()
            if r.deleted {
                Button(action: { store.redoOne(r) }) {
                    Text("放回")
                        .font(.system(size: 10, weight: .semibold))
                        .foregroundColor(.cyan)
                        .padding(.horizontal, 9)
                        .padding(.vertical, 5)
                        .mechaChip(7, accent: Mecha.cyan)
                }
                .disabled(store.busy)
            } else {
                Button(action: { store.undoOne(r) }) {
                    Text("撤")
                        .font(.system(size: 10, weight: .semibold))
                        .foregroundColor(Mecha.bad)
                        .padding(.horizontal, 10)
                        .padding(.vertical, 5)
                        .mechaChip(7, accent: Mecha.bad)
                }
                .disabled(store.busy)
            }
        }
        .padding(.vertical, 5)
        .padding(.horizontal, 9)
        .mechaPanel(8)
    }

    private func rowGame(_ it: PakItem) -> some View {
        HStack(spacing: 8) {
            Image(systemName: it.ext == "sig" ? "signature" : "shippingbox.fill")
                .font(.system(size: 11))
                .foregroundColor(.white.opacity(0.3))
            VStack(alignment: .leading, spacing: 1) {
                Text(it.name)
                    .font(.system(size: 12.5, weight: .medium))
                    .foregroundColor(.white.opacity(0.9))
                    .lineLimit(1)
                    .truncationMode(.middle)
                Text("\(it.sizeText) · .\(it.ext) · \(tailPath(it.id, "Paks"))")
                    .font(.system(size: 9.5))
                    .foregroundColor(.white.opacity(0.35))
                    .lineLimit(1)
                    .truncationMode(.middle)
            }
            Spacer()
            Button(action: { store.askDeleteGameFile(it) }) {
                Text("删")
                    .font(.system(size: 10, weight: .semibold))
                    .foregroundColor(Mecha.bad)
                    .padding(.horizontal, 10)
                    .padding(.vertical, 5)
                    .mechaChip(7, accent: Mecha.bad)
            }
            .disabled(store.busy)
        }
        .padding(.vertical, 5)
        .padding(.horizontal, 9)
        .mechaPanel(8)
    }

    private func tailPath(_ p: String, _ marker: String) -> String {
        if let r = p.range(of: "/" + marker + "/") {
            return marker + "/" + String(p[r.upperBound...])
        }
        return (p as NSString).lastPathComponent
    }

    // MARK: - 进度

    @ViewBuilder
    private var progressCard: some View {
        if store.busy {
            VStack(alignment: .leading, spacing: 6) {
                ProgressView(value: store.progressValue)
                    .progressViewStyle(LinearProgressViewStyle(tint: .green))
                Text(store.progressText)
                    .font(.system(size: 10, design: .monospaced))
                    .foregroundColor(.white.opacity(0.5))
            }
            .padding(12)
            .mechaPanel(10)
        }
    }

    // MARK: - 改字（进阶，折叠）

    private var advancedCard: some View {
        VStack(alignment: .leading, spacing: 8) {
            Button(action: {
                withAnimation(.easeInOut(duration: 0.15)) { showAdvanced.toggle() }
            }) {
                HStack(spacing: 6) {
                    Image(systemName: "textformat")
                        .font(.system(size: 11, weight: .bold))
                        .foregroundColor(.white.opacity(0.55))
                    Text("改字（进阶 · 跟导入无关）")
                        .font(.system(size: 12, weight: .semibold))
                        .foregroundColor(.white.opacity(0.62))
                    Spacer()
                    Image(systemName: showAdvanced ? "chevron.up" : "chevron.down")
                        .font(.system(size: 11, weight: .bold))
                        .foregroundColor(.white.opacity(0.35))
                }
            }

            if showAdvanced {
                Text("等长替换：新字不能比原字长，不然包会坏。这里改的是游戏里的包本身")
                    .font(.system(size: 9.5))
                    .foregroundColor(.white.opacity(0.3))
                    .fixedSize(horizontal: false, vertical: true)

                ForEach(store.rules) { r in
                    HStack(spacing: 8) {
                        Button(action: { store.toggleRule(r) }) {
                            Image(systemName: r.enabled ? "checkmark.circle.fill" : "circle")
                                .font(.system(size: 16))
                                .foregroundColor(r.enabled ? .green : .white.opacity(0.22))
                        }
                        VStack(alignment: .leading, spacing: 1) {
                            Text(r.old)
                                .font(.system(size: 12, weight: .medium))
                                .foregroundColor(.white.opacity(0.88))
                                .lineLimit(1)
                            Text("改成：\(r.new)")
                                .font(.system(size: 9.5))
                                .foregroundColor(.white.opacity(0.4))
                                .lineLimit(1)
                        }
                        Spacer()
                        Button(action: { store.deleteRule(r) }) {
                            Image(systemName: "xmark.circle.fill")
                                .font(.system(size: 14))
                                .foregroundColor(.white.opacity(0.2))
                        }
                    }
                    .padding(.vertical, 5)
                    .padding(.horizontal, 9)
                    .mechaPanel(8)
                }

                HStack(spacing: 6) {
                    field("原文", $store.newOld)
                    field("新文", $store.newNew)
                    Button(action: { store.addRule() }) {
                        Image(systemName: "plus")
                            .font(.system(size: 13, weight: .bold))
                            .foregroundColor(.white)
                            .frame(width: 36, height: 32)
                            .mechaChip(8, accent: Mecha.blue)
                    }
                    .disabled(store.busy)
                }

                HStack(spacing: 9) {
                    smallButton("全自动改字", "bolt.fill", .green) { store.autoRun() }
                    smallButton("改本机的包", "doc.on.doc.fill", .blue) { store.localRun() }
                }
                HStack(spacing: 9) {
                    chip(store.previewMode ? "只看不改：开" : "只看不改：关",
                         store.previewMode ? "eye.fill" : "eye.slash",
                         store.previewMode ? .orange : .gray) { store.previewMode.toggle() }
                    chip(store.backupOn ? "改前备份：开" : "改前备份：关",
                         "externaldrive.fill",
                         store.backupOn ? .green : .gray) { store.backupOn.toggle() }
                }
                if let b = store.backups.first {
                    chip("还原最近一次备份（\(b.files.count) 个）",
                         "clock.arrow.circlepath",
                         .orange) { store.restore(b) }
                }
            }
        }
        .padding(12)
        .mechaPanel(12)
    }

    private func field(_ ph: String, _ binding: Binding<String>) -> some View {
        TextField(ph, text: binding)
            .font(.system(size: 12))
            .foregroundColor(.white)
            .padding(.horizontal, 9)
            .padding(.vertical, 8)
            .mechaPanel(8)
            .autocapitalization(.none)
            .disableAutocorrection(true)
    }

    // MARK: - 运行记录

    private var logCard: some View {
        VStack(alignment: .leading, spacing: 0) {
            HStack {
                Text("运行记录")
                    .font(.system(size: 12, weight: .semibold))
                    .foregroundColor(.white.opacity(0.55))
                Spacer()
                Button(action: { store.logs.removeAll() }) {
                    Text("清空").font(.system(size: 10)).foregroundColor(.white.opacity(0.35))
                }
            }
            .padding(.bottom, 5)

            ScrollViewReader { proxy in
                ScrollView {
                    VStack(alignment: .leading, spacing: 2) {
                        ForEach(Array(store.logs.indices), id: \.self) { idx in
                            Text(store.logs[idx])
                                .font(.system(size: 9.5, design: .monospaced))
                                .foregroundColor(color(for: store.logs[idx]))
                                .frame(maxWidth: .infinity, alignment: .leading)
                                .id(idx)
                        }
                    }
                    .padding(8)
                }
                .frame(height: 200)
                .mechaPanel(10)
                .onChange(of: store.logs.count) { _ in
                    if let last = store.logs.indices.last {
                        withAnimation(.easeOut(duration: 0.12)) {
                            proxy.scrollTo(last, anchor: .bottom)
                        }
                    }
                }
            }
        }
    }

    private func color(for line: String) -> Color {
        if line.contains("✗") || line.contains("⚠️") { return Mecha.bad }
        if line.contains("✓") || line.contains("完成") { return Mecha.ok }
        if line.contains("====") { return Mecha.cyan }
        return Color.white.opacity(0.55)
    }
}
