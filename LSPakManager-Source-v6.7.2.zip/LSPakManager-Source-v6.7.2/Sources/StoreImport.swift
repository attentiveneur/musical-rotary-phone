import Foundation

/// 两件事：① 导入文件 ② 删除导入的文件（按导入记录撤，不靠关键字乱猜）
extension Store {

    // MARK: - 点一下就删：先弹一次确认，确认完直接删

    /// 游戏里还在的导入文件
    func deletableImports() -> [ImportRecord] {
        let fm = FileManager.default
        return imported.filter { !$0.deleted && fm.fileExists(atPath: $0.gamePath) }
    }

    /// ② 号大按钮：不再要先跑一遍「认领/扫描」，点一下弹确认，点了就删
    func askDeleteImports() {
        guard !busy else { return }

        silentAdopt()
        let alive = deletableImports()
        guard !alive.isEmpty else {
            let stale = imported.filter { !$0.deleted }.count
            if stale > 0 {
                popup("没有要删的",
                      "记录里那 \(stale) 个文件，在游戏目录里已经找不到了。\n\n点「清掉失效记录」把账清干净就行。")
            } else {
                popup("还没导入过东西",
                      "先用「③ 从手机里选文件」挑包，再点「① 导入文件」写进游戏。\n\n导进去之后，这里点一下就能删。")
            }
            return
        }

        ui {
            self.pendingUndo = alive
            self.pendingGameDelete = []
            self.alertTitle = "修复游戏里的 \(alive.count) 个导入文件？"
            self.alertBody = "修复的是游戏 Paks 目录里那份。\n\n修复前自动备份原件，完事也能在「已导入」里点「放回」拿回来。"
            self.alertNeedsConfirm = true
            self.alertShown = true
        }
    }

    /// 列表里单个包点「删」：一样先确认
    func askDeleteGameFile(_ it: PakItem) {
        guard !busy else { return }
        ui {
            self.pendingUndo = []
            self.pendingGameDelete = [it]
            self.alertTitle = "修复这个包？"
            self.alertBody = "\(it.name)\n\n修复的是游戏目录里那份，动手前留副本，完事能在「已导入」里放回。"
            self.alertNeedsConfirm = true
            self.alertShown = true
        }
    }

    // MARK: - 删除导入的文件

    func undoRun() {
        guard !busy else { return }
        let targets = pendingUndo.isEmpty ? deletableImports() : pendingUndo
        guard !targets.isEmpty else {
            popup("没东西可删", "游戏目录里已经没有导入过的文件了。")
            return
        }

        busy = true
        let keep = undoKeepCopy
        let restoreBak = undoRestoreBackup
        let stamp = Fmt.stamp()
        let total = targets.count
        log("==== 修复开始：\(total) 个 · \(keep ? "动手前留副本" : "不留副本") · \(restoreBak ? "覆盖过原件的自动还原" : "不还原") ====")

        queue.async { [weak self] in
            guard let self = self else { return }

            let reports = AutoIO.undoImports(targets,
                                             backupRoot: LSPaths.backupRoot(),
                                             stamp: stamp,
                                             keepCopy: keep,
                                             restoreBackup: restoreBak) { i, all, name in
                self.setProgress(Double(i) / Double(max(all, 1)), "\(i + 1)/\(all)  \(name)")
            }

            var ok = 0
            for r in reports {
                if let e = r.error {
                    self.log("✗ \(r.name) 没撤成：\(e)")
                } else {
                    ok += 1
                    self.log("✓ \(r.name) — \(r.action)")
                    ImportLog.markDeleted(id: r.id, hold: r.holdPath)
                }
            }

            self.setProgress(1, "完成")
            self.log("==== 修复完：\(ok) / \(total) 个 ====")
            self.log("修复的是游戏目录里那份；App 库里那份原封没动，想再导回去点「① 导入文件」就行")
            if keep && ok > 0 {
                self.log("撤下来的那几份收在 Backups/删掉的-\(stamp)/，想放回去点那行右边的「放回」")
            }
            self.log("现在退掉游戏后台重新进，看是不是回到导入前的样子")

            let recs = ImportLog.load()
            self.ui {
                self.busy = false
                self.pendingUndo = []
                self.imported = recs
                self.banner = "已修复 \(ok) 个"
                self.backups = LSPaths.backupList()
            }

            if ok > 0 {
                var body = ok == total
                    ? "修复完成 ✅\n\n从游戏目录里撤掉了 \(ok) 个\n\n"
                    : "修复了 \(ok) 个，\(total - ok) 个没成（原因在下面运行记录里）\n\n"
                body += "App 里那份原封没动，想再导回去点「① 导入文件」。\n"
                if keep { body += "删下来的副本收在 Backups 里，能放回。\n" }
                body += "现在退掉游戏后台重新进，看是不是回到导入前的样子。"
                self.popup("修复成功 ✅", body)
            } else {
                self.popup("没修复成", "一个都没成，看下面运行记录里的原因。")
            }
            self.refreshGameOnly()
        }
    }

    /// 单条撤回
    func undoOne(_ r: ImportRecord) {
        guard !busy else { return }
        busy = true
        let keep = undoKeepCopy
        let restoreBak = undoRestoreBackup
        let stamp = Fmt.stamp()
        log("==== 撤回一条：\(r.name) ====")

        queue.async { [weak self] in
            guard let self = self else { return }
            let reports = AutoIO.undoImports([r],
                                             backupRoot: LSPaths.backupRoot(),
                                             stamp: stamp,
                                             keepCopy: keep,
                                             restoreBackup: restoreBak) { _, _, _ in }

            if let one = reports.first {
                if let e = one.error {
                    self.log("✗ \(one.name)：\(e)")
                } else {
                    self.log("✓ \(one.name) — \(one.action)")
                    ImportLog.markDeleted(id: one.id, hold: one.holdPath)
                }
            }

            let recs = ImportLog.load()
            let failedOne = reports.first?.error
            self.ui {
                self.busy = false
                self.imported = recs
                self.pendingUndo = self.pendingUndo.filter { $0.id != r.id }
            }
            if let e = failedOne {
                self.popup("没修复成", "\(r.name)\n\(e)")
            } else {
                self.popup("修复成功 ✅", "从游戏目录里撤掉了 1 个：\n\(r.name)\n\nApp 里那份还在，点「① 导入文件」能导回去。")
            }
            self.refreshGameOnly()
        }
    }

    /// 删错了，把它再放回游戏
    func redoOne(_ r: ImportRecord) {
        guard !busy else { return }
        guard let hold = r.holdPath else {
            log("· 这条当时没留副本，放不回去。用「① 导入文件」重新导一次吧")
            return
        }
        busy = true
        log("==== 放回游戏：\(r.name) ====")

        queue.async { [weak self] in
            guard let self = self else { return }
            let err = AutoIO.putBack(from: hold, to: r.gamePath) { _, _, _ in }
            if let e = err {
                self.log("✗ \(r.name) 没放回去：\(e)")
            } else {
                self.log("✓ \(r.name) 已放回游戏")
                ImportLog.markRestored(id: r.id)
            }
            let recs = ImportLog.load()
            self.ui {
                self.busy = false
                self.imported = recs
            }
            if let e = err {
                self.popup("没放回去", "\(r.name)\n\(e)")
            } else {
                self.popup("放回成功 ✅", "\(r.name) 已经写回游戏目录了。退掉游戏后台重新进。")
            }
            self.refreshGameOnly()
        }
    }

    /// 自动对账：App 库里有、游戏里同名同大小的，补记成一条导入记录。
    /// 以前要人点「认领已导入的」，现在删之前自己跑一遍，不用点了。
    @discardableResult
    func silentAdopt() -> Int {
        guard let pd = paksDir else { return 0 }
        let park = LSPaths.importedDir()
        let fm = FileManager.default
        guard let names = try? fm.contentsOfDirectory(atPath: park.path) else { return 0 }

        var known = Set(imported.filter { !$0.deleted }.map { $0.gamePath })
        var n = 0
        for name in names where !name.hasPrefix(".") {
            let src = park.appendingPathComponent(name)
            var isDir: ObjCBool = false
            guard fm.fileExists(atPath: src.path, isDirectory: &isDir), !isDir.boolValue else { continue }
            let dst = pd + "/" + name
            guard fm.fileExists(atPath: dst), !known.contains(dst) else { continue }

            let a1 = try? fm.attributesOfItem(atPath: src.path)
            let a2 = try? fm.attributesOfItem(atPath: dst)
            let s1 = (a1?[.size] as? NSNumber)?.int64Value ?? 0
            let s2 = (a2?[.size] as? NSNumber)?.int64Value ?? 0
            // 同名还同大小才算同一个包，免得把游戏自带的东西当成自己导进去的
            guard s1 > 0, s1 == s2 else { continue }

            ImportLog.add(ImportRecord(name: name,
                                       gamePath: dst,
                                       size: s2,
                                       time: Fmt.shortDate(),
                                       action: "自动对账",
                                       backupPath: nil))
            known.insert(dst)
            n += 1
            log("· 自动对账：\(name) 是这个 App 导进去的")
        }
        if n > 0 { imported = ImportLog.load() }
        return n
    }

    /// 清掉「游戏里文件已经不在了」的过期记录
    func pruneRecords() {
        let gone = ImportLog.pruneMissing()
        imported = ImportLog.load()
        pendingUndo = pendingUndo.filter { FileManager.default.fileExists(atPath: $0.gamePath) && !$0.deleted }
        log(gone > 0 ? "· 清掉 \(gone) 条失效记录" : "· 没有失效记录，账是干净的")
    }

    // MARK: - 从手机里选文件

    /// ③ 号大按钮：开面板挑文件（面板自己带 delegate，界面怎么刷都不影响「打开」）
    func openFilePicker() {
        guard !busy else { return }
        DocPicker.shared.open { [weak self] urls in
            guard let self = self else { return }
            if urls.isEmpty {
                self.log("· 选文件取消了")
                return
            }
            self.pickFiles(urls)
        }
    }

    func pickFiles(_ urls: [URL]) {
        guard !urls.isEmpty else { return }
        guard !busy else { return }

        busy = true
        setProgress(0.02, "正在存进 App…")

        let dest = LSPaths.dropDir()
        log("==== 收文件：\(urls.count) 个 ====")

        queue.async { [weak self] in
            guard let self = self else { return }
            let fm = FileManager.default
            var ok = 0
            var bad = 0
            var names: [String] = []

            for (i, u) in urls.enumerated() {
                self.setProgress(Double(i) / Double(max(urls.count, 1)),
                                 "\(i + 1)/\(urls.count)  \(u.lastPathComponent)")
                let scoped = u.startAccessingSecurityScopedResource()

                var isDir: ObjCBool = false
                if fm.fileExists(atPath: u.path, isDirectory: &isDir), isDir.boolValue {
                    if scoped { u.stopAccessingSecurityScopedResource() }
                    self.log("· \(u.lastPathComponent) 是文件夹，跳过（只收文件）")
                    continue
                }

                let to = dest.appendingPathComponent(u.lastPathComponent)
                try? fm.removeItem(at: to)
                do {
                    // 系统已经把选中的文件拷了一份到本 App 里，直接搬过来最快，大包不用拷两遍
                    do {
                        try fm.moveItem(at: u, to: to)
                    } catch {
                        try fm.copyItem(at: u, to: to)
                    }
                    let attrs = try? fm.attributesOfItem(atPath: to.path)
                    let size = (attrs?[.size] as? NSNumber)?.int64Value ?? 0
                    ok += 1
                    names.append(u.lastPathComponent)
                    self.log("✓ 已存进 App：\(u.lastPathComponent)   \(Fmt.size(size))")
                } catch {
                    bad += 1
                    self.log("✗ \(u.lastPathComponent) 存不进来：\(LSPaths.describe(error))")
                }
                if scoped { u.stopAccessingSecurityScopedResource() }
            }

            self.setProgress(1, "完成")
            self.log("==== 存进 App：\(ok) 个成功，\(bad) 个失败 · 这些包会一直留在这里 ====")
            if ok > 0 { self.log("点大绿按钮「① 导入文件」就写进游戏") }

            let list = LSPaths.listImportSources()
            self.ui {
                self.busy = false
                self.importList = list
            }

            if ok > 0 {
                var body = ok == 1
                    ? "已存进 App：\(names.first ?? "")\n\n"
                    : "\(ok) 个文件已存进 App，会一直留在里面\n\n"
                if bad > 0 { body += "\(bad) 个没存进来（原因在运行记录里）\n\n" }
                body += "下次想再导，直接点「① 导入文件」，不用再进「文件」里挑。"
                self.popup("导入成功 ✅", body, delay: 0.55)
            } else {
                self.popup("没存进来", "一个都没成功，原因写在下面的运行记录里。", delay: 0.4)
            }
        }
    }

    /// 手动挑游戏里的包删（给「以前用别的工具导进去、没有记录」的包用）
    /// 删前留副本，删完记一笔，随时能「放回」
    func deleteGameFiles(_ targets: [PakItem]) {
        guard !busy else { return }
        guard !targets.isEmpty else { return }
        busy = true
        let keep = undoKeepCopy
        let stamp = Fmt.stamp()
        log("==== 手动删游戏里的包：\(targets.count) 个 · \(keep ? "动手前留副本" : "不留副本") ====")

        queue.async { [weak self] in
            guard let self = self else { return }
            let reps = AutoIO.deleteAll(targets,
                                        backupRoot: LSPaths.backupRoot(),
                                        stamp: stamp,
                                        keepCopy: keep) { i, all, name in
                self.setProgress(Double(i) / Double(max(all, 1)), "\(i + 1)/\(all)  \(name)")
            }

            var ok = 0
            for r in reps {
                if let e = r.error {
                    self.log("✗ \(r.name)：\(e)")
                    continue
                }
                ok += 1
                self.log("✓ \(r.name) 已修复")
                var rec = ImportRecord(name: r.name,
                                       gamePath: r.path,
                                       size: r.size,
                                       time: Fmt.shortDate(),
                                       action: "手动删",
                                       backupPath: nil)
                rec.deleted = true
                rec.deletedAt = Fmt.shortDate()
                rec.holdPath = r.movedTo
                ImportLog.add(rec)
            }

            self.setProgress(1, "完成")
            self.log("==== 修复完：\(ok) / \(targets.count) 个 ====")
            if keep && ok > 0 {
                self.log("副本在 Backups/删掉的-\(stamp)/，「已导入」那页点「放回」能拿回来")
            }

            let recs = ImportLog.load()
            self.ui {
                self.busy = false
                self.imported = recs
                self.banner = "手动修复了 \(ok) 个"
                self.scanFound = self.scanFound.filter { fm in
                    !targets.contains(where: { $0.id == fm.id })
                }
            }

            if ok > 0 {
                var body = "修复完成 ✅\n\n从游戏目录里撤掉了 \(ok) 个\n\n"
                if keep { body += "副本收在 Backups 里，「已导入」那页点「放回」能拿回来。\n" }
                body += "退掉游戏后台重新进看看。"
                self.popup("修复成功 ✅", body)
            } else {
                self.popup("没修复成", "一个都没成，看运行记录里的原因。")
            }
            self.refreshGameOnly()
        }
    }

    // MARK: - 全盘找 pak

    func fullScan() {
        guard !busy else { return }
        busy = true
        let gp = gamePath
        let pd = paksDir
        log("==== 全盘找 pak / sig ====")

        queue.async { [weak self] in
            guard let self = self else { return }
            var found: [PakItem] = []
            var seen = Set<String>()

            func absorb(_ list: [PakItem]) {
                for it in list {
                    if seen.contains(it.id) { continue }
                    seen.insert(it.id)
                    found.append(it)
                }
            }

            if let p = pd { absorb(LSPaths.scanDeep(p, depth: 8, limit: 5000)) }
            if let c = gp { absorb(LSPaths.scanDeep(c, depth: 10, limit: 5000)) }

            // 游戏目录扫得太少，就把其他 App 的容器也翻一遍（有全盘权限才翻得动）
            if found.count < 3 {
                if let names = try? FileManager.default.contentsOfDirectory(atPath: LSPaths.containerRoot) {
                    for n in names where !n.hasPrefix(".") {
                        let base = LSPaths.containerRoot + "/" + n
                        if let c = gp, base == c { continue }
                        absorb(LSPaths.scanDeep(base, depth: 8, limit: 300))
                        if found.count > 8000 { break }
                    }
                }
            }

            let pakN = found.filter { $0.ext == "pak" }.count
            let sigN = found.filter { $0.ext == "sig" }.count
            self.log("扫到 \(found.count) 个：pak \(pakN) 个 · sig \(sigN) 个")
            for it in found.prefix(30) {
                self.log("   · \(it.name)   \(it.sizeText)")
            }
            if found.count > 30 { self.log("   …… 还有 \(found.count - 30) 个") }

            if found.isEmpty {
                self.log("· 一个都没扫到：先确认游戏装过、至少进过一次游戏")
            } else {
                self.log("· 这份清单只给你看清游戏里都有啥，一个字节都没动")
            }

            self.ui {
                self.busy = false
                self.scanFound = found
                self.scanNote = "pak \(pakN) · sig \(sigN)"
                self.banner = "全盘扫到 \(found.count) 个 pak/sig"
            }
        }
    }
}
