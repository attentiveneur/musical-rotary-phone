//
//  DirPicker.swift
//  v15.0
//
//  在 Filza 的文件树里挑一个文件夹当中转站。
//  一次点完就记住，以后不用再挑。
//

import SwiftUI

private let dpHUD = Color(red: 0.20, green: 0.86, blue: 0.60)

struct DirPicker: View {

    @EnvironmentObject private var store: Store
    @Environment(\.dismiss) private var dismiss

    let initial: String
    let onPick: (String) -> Void

    @State private var path: String = "/"
    @State private var entries: [RemoteEntry] = []
    @State private var loading = false
    @State private var err = ""

    var body: some View {
        NavigationView {
            VStack(spacing: 0) {
                HStack {
                    Text(path)
                        .font(.system(size: 10.5, design: .monospaced))
                        .foregroundColor(.white.opacity(0.7))
                        .lineLimit(2)
                        .truncationMode(.head)
                    Spacer()
                }
                .padding(.horizontal, 12)
                .padding(.vertical, 8)

                if !err.isEmpty {
                    Text(err)
                        .font(.system(size: 11))
                        .foregroundColor(.orange)
                        .frame(maxWidth: .infinity, alignment: .leading)
                        .padding(.horizontal, 12)
                        .padding(.bottom, 6)
                }

                List {
                    if path != "/" && !path.isEmpty {
                        Button {
                            goUp()
                        } label: {
                            HStack(spacing: 8) {
                                Image(systemName: "arrow.up")
                                    .foregroundColor(.white.opacity(0.7))
                                Text("上一级")
                                    .foregroundColor(.white.opacity(0.85))
                                Spacer()
                            }
                        }
                    }

                    ForEach(dirs) { e in
                        Button {
                            Task { await load(e.path) }
                        } label: {
                            HStack(spacing: 8) {
                                Image(systemName: "folder.fill")
                                    .foregroundColor(dpHUD)
                                Text(e.name)
                                    .foregroundColor(.white)
                                    .lineLimit(1)
                                Spacer()
                                Image(systemName: "chevron.right")
                                    .font(.system(size: 10, weight: .bold))
                                    .foregroundColor(.white.opacity(0.25))
                            }
                        }
                    }
                }
                .listStyle(.plain)
                .overlay {
                    if loading { ProgressView().tint(dpHUD) }
                }
            }
            .navigationTitle("选中转文件夹")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .navigationBarLeading) {
                    Button("取消") { dismiss() }
                }
                ToolbarItem(placement: .navigationBarTrailing) {
                    Button("就这") {
                        onPick(path)
                        dismiss()
                    }
                    .font(.system(size: 14, weight: .bold))
                    .foregroundColor(dpHUD)
                }
            }
        }
        .preferredColorScheme(.dark)
        .task {
            var start = initial
            if start.isEmpty { start = "/" }
            await load(start)
        }
    }

    private var dirs: [RemoteEntry] {
        entries.filter { $0.isDir }.sorted { $0.name < $1.name }
    }

    private func goUp() {
        var p = path
        while p.count > 1 && p.hasSuffix("/") { p.removeLast() }
        guard let i = p.lastIndex(of: "/") else { return }
        let up = i == p.startIndex ? "/" : String(p[p.startIndex..<i])
        Task { await load(up) }
    }

    @MainActor
    private func load(_ p: String) async {
        loading = true
        defer { loading = false }

        let target = p.isEmpty ? "/" : p
        let (list, msg) = await store.remoteList(target)
        if msg.isEmpty {
            path = target
            entries = list
            err = ""
        } else {
            err = msg
        }
    }
}
