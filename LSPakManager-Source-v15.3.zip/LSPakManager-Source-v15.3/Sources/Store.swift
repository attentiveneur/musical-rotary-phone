//
//  Store.swift
//  v15.3
//
//  这一版只有两个动作，全都手点：
//
//  1)「导入文件」——点一下，才把中转站里的包写进游戏 Paks，同名直接覆盖原文件
//  2)「移出导入的文件」——点一下，把导进去的那些包搬回中转站，不还原游戏原文件
//
//  没有自动巡逻、没有定时扫描、没有自动撤出。
//  删除只在最不得已的时候兜底，正常全程只用 PUT / MOVE。
//

import Foundation
import SwiftUI
import Combine

@MainActor
final class Store: ObservableObject {

    // ── 界面状态 ──
    @Published var logLines: [String] = []
    @Published var connected = false
    @Published var busy = false
    @Published var busyText = ""
    @Published var statusText = "未连接"
    @Published var gamePath: String? = nil
    @Published var records: [TransferRecord] = []

    // ── 中转站 ──
    @Published var transitPath: String = ""
    @Published var lastScanText = "还没扫"
    @Published var pendingCount = 0       // 中转站里还没导进去的
    @Published var importedCount = 0      // 我导进游戏里的

    // ── 连接参数 ──
    @Published var host: String = "127.0.0.1"
    @Published var port: Int = 8888

    let bridge = FilzaBridge.shared

    /// 我导进游戏里的那些包名 —— 移出只认这些，别人放的一概不动
    private var importedNames: Set<String> = []
    private var pulling = false

    private let kHost = "ls15.host"
    private let kPort = "ls15.port"
    private let kBase = "ls15.base"
    private let kGame = "ls15.game"
    private let kTransit = "ls15.transit"
    private let kRecords = "ls15.records"
    private let kImported = "ls15.imported"

    init() {
        LSPaths.ensureDirs()
        let d = UserDefaults.standard

        if let h = d.string(forKey: kHost), !h.isEmpty { host = h }
        let p = d.integer(forKey: kPort)
        if p > 0 { port = p }
        bridge.host = host
        bridge.port = port
        bridge.basePath = d.string(forKey: kBase) ?? ""

        if let g = d.string(forKey: kGame), !g.isEmpty { gamePath = g }
        if let t = d.string(forKey: kTransit), !t.isEmpty { transitPath = t }

        if let data = d.data(forKey: kRecords),
           let r = try? JSONDecoder().decode([TransferRecord].self, from: data) {
            records = r
        }
        if let arr = d.array(forKey: kImported) as? [String] {
            importedNames = Set(arr)
            importedCount = importedNames.count
        }
    }

    // MARK: - 日志

    func log(_ s: String) {
        logLines.append("\(Fmt.clock())  \(s)")
        if logLines.count > 200 { logLines.removeFirst(logLines.count - 200) }
    }

    func clearLog() { logLines.removeAll() }

    // MARK: - 连接

    func connect(autoprobe: Bool = true) async {
        guard !busy else { return }
        busy = true
        busyText = "正在连 Filza 服务"
        defer { busy = false }

        host = host.trimmingCharacters(in: .whitespaces)
        if host.isEmpty { host = "127.0.0.1" }
        bridge.host = host
        bridge.port = port

        log("连 \(host):\(port) …")
        let (ok, msg) = await bridge.ping(host: host, port: port)
        if ok {
            connected = true
            statusText = "已连上 Filza"
            saveConn()
            log("✓ \(msg)")
            if gamePath == nil { await locate(silent: true) }
            return
        }

        if autoprobe {
            log("这个端口没通，自动找一下别的端口…")
            busyText = "正在找 Filza 的端口"
            if let p = await bridge.probePorts() {
                port = p
                let (ok2, msg2) = await bridge.ping(host: host, port: p)
                if ok2 {
                    connected = true
                    statusText = "已连上 \(host):\(p)"
                    saveConn()
                    log("✓ 在 \(p) 端口找到服务")
                    log("✓ \(msg2)")
                    if gamePath == nil { await locate(silent: true) }
                    return
                }
            }
        }

        connected = false
        statusText = "没连上"
        log("✗ \(msg)")
        log("· 先确认 Filza 里的网络 / WiFi 服务开关是开的")
    }

    /// 要用的时候如果没连上，先自己连一次
    private func ensureConnected() async -> Bool {
        if connected { return true }
        await connect(autoprobe: true)
        return connected
    }

    private func saveConn() {
        let d = UserDefaults.standard
        d.set(host, forKey: kHost)
        d.set(port, forKey: kPort)
        d.set(bridge.basePath, forKey: kBase)
    }

    // MARK: - 找游戏目录

    func locate(silent: Bool = false) async {
        guard connected else {
            if !silent { log("✗ 先连上 Filza 服务") }
            return
        }
        if !silent { busyText = "正在找游戏的 Paks 目录" }
        let r = await bridge.locateGame()
        switch r {
        case .success(let loc):
            gamePath = loc.paksRel
            UserDefaults.standard.set(loc.paksRel, forKey: kGame)
            log("✓ 找到游戏目录")
        case .failure(let why):
            gamePath = nil
            if !silent { log("✗ \(why.message)") }
        }
    }

    private func ensureGame() async -> String? {
        if let g = gamePath, !g.isEmpty { return g }
        let r = await bridge.locateGame()
        if case .success(let loc) = r {
            gamePath = loc.paksRel
            UserDefaults.standard.set(loc.paksRel, forKey: kGame)
            log("✓ 找到游戏目录")
            return loc.paksRel
        }
        if case .failure(let why) = r { log("✗ \(why.message)") }
        return nil
    }

    // MARK: - 中转站

    func setTransit(_ p: String) {
        var s = p.trimmingCharacters(in: .whitespaces)
        while s.count > 1 && s.hasSuffix("/") { s.removeLast() }
        transitPath = s
        UserDefaults.standard.set(s, forKey: kTransit)
        pendingCount = 0
        log("· 中转站定为 \(s)")
        Task { await prepareTransit() }
    }

    /// 中转站不存在就建出来
    func prepareTransit() async {
        guard connected, !transitPath.isEmpty else { return }
        do {
            try await bridge.ensureDir(transitPath)
        } catch {
            log("· 中转站建不出来（可能已经有了）：\(LSPaths.describe(error))")
        }
        await refreshTransitCount()
    }

    func refreshTransitCount() async {
        guard connected, !transitPath.isEmpty else {
            pendingCount = 0
            importedCount = importedNames.count
            return
        }
        let list = (try? await bridge.list(transitPath)) ?? []
        let files = list.filter {
            !$0.isDir && !$0.name.hasPrefix(".") &&
            LSPaths.pakExts.contains(($0.name as NSString).pathExtension.lowercased())
        }
        pendingCount = files.filter { !importedNames.contains($0.name) }.count
        importedCount = importedNames.count
        lastScanText = Fmt.clock()
    }

    // MARK: - 导入（点一下才动）

    /// 「导入文件」：中转站里的包，全部写进游戏 Paks，同名直接覆盖
    func importAll() async {
        guard !busy else { return }
        let linked = await ensureConnected()
        guard linked else {
            log("✗ 还没连上 Filza，点右上角「连接」先")
            return
        }
        guard !transitPath.isEmpty else { log("✗ 先选中转文件夹"); return }
        guard let paks = await ensureGame() else { return }

        busy = true
        busyText = "正在读中转站"
        defer { busy = false }

        var files: [RemoteEntry] = []
        do {
            files = try await bridge.list(transitPath)
        } catch {
            log("✗ 中转站打不开：\(LSPaths.describe(error))")
            return
        }

        let targets = files.filter {
            !$0.isDir && !$0.name.hasPrefix(".") &&
            LSPaths.pakExts.contains(($0.name as NSString).pathExtension.lowercased())
        }

        guard !targets.isEmpty else {
            log("· 中转站里没有包，先放个 .pak 进去")
            return
        }

        log("开始导入 \(targets.count) 个包（同名覆盖游戏原文件）")

        var ok = 0
        var failed = 0

        for (i, f) in targets.enumerated() {
            busyText = "导入 \(i + 1)/\(targets.count)  \(f.name)"
            let src = "\(transitPath)/\(f.name)"
            let dst = "\(paks)/\(f.name)"
            do {
                try await overwriteInto(name: f.name, from: src, paks: paks)
                ok += 1
                importedNames.insert(f.name)
                persistImported()
                addRecord(name: f.name, size: f.size, direction: "导入",
                          remote: dst, ok: true, note: "覆盖写入 Paks")
                log("↑ \(f.name)  \(Fmt.size(f.size))  → 已覆盖进游戏")
            } catch {
                failed += 1
                let msg = LSPaths.describe(error)
                log("✗ \(f.name)：\(msg)")
                addRecord(name: f.name, size: f.size, direction: "导入",
                          remote: dst, ok: false, note: msg)
            }
        }

        log("导入结束：成 \(ok) · 败 \(failed) · 现在游戏里由我导入 \(importedNames.count) 个")
        await refreshTransitCount()
    }

    /// 把一个包写进 Paks；目标已有同名就覆盖
    private func overwriteInto(name: String, from src: String, paks: String) async throws {
        let tmp = LSPaths.tempDir().appendingPathComponent(name)
        try? FileManager.default.removeItem(at: tmp)
        try await bridge.download(src, to: tmp)
        defer { try? FileManager.default.removeItem(at: tmp) }

        let dst = "\(paks)/\(name)"

        // 直接 PUT —— WebDAV 对已存在的资源就是覆盖
        do {
            try await bridge.upload(tmp, to: dst)
            return
        } catch {
            // 有的服务不许直接覆盖：先把旧的挪去 _zaka_old（挪，不删），再传一次
            let keep = "\(paks)/_zaka_old"
            try? await bridge.mkcol(keep)
            try? await bridge.move(dst, to: "\(keep)/\(Fmt.stamp())-\(name)")
            try await bridge.upload(tmp, to: dst)
        }
    }

    // MARK: - 移出（只搬我导进去的，不还原原文件）

    /// 「移出导入的文件」：把导进去的包搬回中转站，游戏里那份拿走，不补回原文件
    func exportImported() async {
        guard !busy else { return }
        let linked = await ensureConnected()
        guard linked else {
            log("✗ 还没连上 Filza，点右上角「连接」先")
            return
        }
        guard !transitPath.isEmpty else { log("✗ 先选中转文件夹"); return }
        guard let paks = await ensureGame() else { return }

        let list = (try? await bridge.list(paks)) ?? []
        let inPaks = Set(list.filter { !$0.isDir }.map { $0.name })

        var targets = importedNames.intersection(inPaks)

        // 名单丢了（重装 / 换机）就退一步，用记录里导入成功的那些名字
        if targets.isEmpty {
            let fromRecords = records.filter { $0.direction == "导入" && $0.ok }
                .map { ($0.remotePath as NSString).lastPathComponent }
            targets = Set(fromRecords).intersection(inPaks)
        }

        guard !targets.isEmpty else {
            log("· 游戏里现在没有我导进去的包")
            return
        }

        await pull(names: Array(targets).sorted())
    }

    private func pull(names: [String]) async {
        guard !pulling else { return }
        pulling = true
        busy = true
        busyText = "正在移出"
        defer {
            busy = false
            pulling = false
        }

        guard let paks = await ensureGame() else { return }
        try? await bridge.ensureDir(transitPath)
        let hide = "\(paks)/_zaka_out"
        try? await bridge.mkcol(hide)

        var ok = 0
        var failed = 0

        for (i, name) in names.enumerated() {
            busyText = "移出 \(i + 1)/\(names.count)  \(name)"
            do {
                try await pullOne(name: name, paks: paks, hide: hide)
                ok += 1
                importedNames.remove(name)
                persistImported()
                log("↓ \(name)  → 已移出（原文件不还原）")
                addRecord(name: name, size: 0, direction: "移出",
                          remote: "\(paks)/\(name)", ok: true,
                          note: "回到 \(transitPath)，未还原原文件")
            } catch {
                failed += 1
                let msg = LSPaths.describe(error)
                log("✗ \(name)：\(msg)")
                addRecord(name: name, size: 0, direction: "移出",
                          remote: "\(paks)/\(name)", ok: false, note: msg)
            }
        }

        log("移出结束：成 \(ok) · 败 \(failed) · 游戏里还剩我导入的 \(importedNames.count) 个")
        await refreshTransitCount()
    }

    private func pullOne(name: String, paks: String, hide: String) async throws {
        let remote = "\(paks)/\(name)"

        // 中转站里已经有同名（我自己那份），就让开，不覆盖它
        var target = "\(transitPath)/\(name)"
        let occupied = await bridge.exists(target)
        if occupied {
            target = "\(transitPath)/\(Fmt.stamp())-\(name)"
        }

        // 一步到位：整个文件从 Paks 挪回中转站
        do {
            try await bridge.move(remote, to: target)
            return
        } catch {
            // 跨容器不让 MOVE：先下载，再传到中转站
        }

        let tmp = LSPaths.tempDir().appendingPathComponent(name)
        try? FileManager.default.removeItem(at: tmp)
        try await bridge.download(remote, to: tmp)
        defer { try? FileManager.default.removeItem(at: tmp) }

        try await bridge.upload(tmp, to: target)

        // 本地也留一份，文件 App → 本 App →「② 已移出」里能直接看见
        let local = LSPaths.uniqueURL(LSPaths.outDir(), name: name)
        try? FileManager.default.copyItem(at: tmp, to: local)

        // 游戏里那份拿走：先挪进 _zaka_out，绝不调用删除
        do {
            try await bridge.move(remote, to: "\(hide)/\(name)")
        } catch {
            try await bridge.move(remote, to: "\(hide)/\(Fmt.stamp())-\(name)")
        }
    }

    // MARK: - 给选择器用

    func remoteList(_ path: String) async -> ([RemoteEntry], String) {
        guard connected else { return ([], "还没连上 Filza") }
        do {
            return (try await bridge.list(path), "")
        } catch {
            return ([], LSPaths.describe(error))
        }
    }

    // MARK: - 导入名单

    private func persistImported() {
        importedCount = importedNames.count
        if importedNames.count > 800 {
            importedNames = Set(Array(importedNames).suffix(800))
        }
        UserDefaults.standard.set(Array(importedNames), forKey: kImported)
    }

    func resetImported() {
        importedNames.removeAll()
        importedCount = 0
        UserDefaults.standard.removeObject(forKey: kImported)
        log("· 导入名单已清空。中转站里的包会被当成新包，可以再导一次")
        Task { await refreshTransitCount() }
    }

    // MARK: - 记录

    private func addRecord(name: String, size: Int64, direction: String,
                           remote: String, ok: Bool, note: String = "") {
        records.append(TransferRecord(name: name,
                                      direction: direction,
                                      remotePath: remote,
                                      size: size,
                                      time: Fmt.shortDate(),
                                      ok: ok,
                                      note: note))
        if records.count > 300 { records.removeFirst(records.count - 300) }
        if let data = try? JSONEncoder().encode(records) {
            UserDefaults.standard.set(data, forKey: kRecords)
        }
    }

    func clearRecords() {
        records.removeAll()
        UserDefaults.standard.removeObject(forKey: kRecords)
    }

    // MARK: - 自检

    func diagnose() async {
        guard !busy else { return }
        busy = true
        busyText = "正在自检"
        defer { busy = false }

        log("── 自检 ──")
        log("系统 \(Compatibility.shortSystem()) · \(Compatibility.hardwareModel())")
        log("服务 \(bridge.endpoint)  根 \(bridge.basePath.isEmpty ? "/" : bridge.basePath)")
        log("中转站 \(transitPath.isEmpty ? "（没选）" : transitPath)")
        log("我导入的包 \(importedNames.count) 个")

        guard connected else {
            log("· 服务没连上，先点「连接」")
            return
        }

        if !transitPath.isEmpty {
            if let l = try? await bridge.list(transitPath) {
                log("中转站里 \(l.count) 项")
                for e in l.prefix(10) { log("  \(e.isDir ? "📁" : "📄") \(e.name)  \(e.sizeText)") }
            } else {
                log("中转站打不开")
            }
        }

        if let g = gamePath {
            if let l = try? await bridge.list(g) {
                log("Paks 里 \(l.count) 项")
                for e in l.prefix(10) { log("  \(e.isDir ? "📁" : "📄") \(e.name)  \(e.sizeText)") }
            } else {
                log("Paks 列不出")
            }
        }
    }
}
