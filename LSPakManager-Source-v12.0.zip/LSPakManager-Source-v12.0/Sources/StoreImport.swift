import Foundation

/// 两件事：① 导入文件 ② 删除导入的文件（按导入记录撤，不靠关键字乱猜）
extension Store {

    // MARK: - 只看不动：列出要撤哪些

    func undoScan() {
        guard !busy else { return }
        let recs = imported.filter { !$0.deleted }
        guard !recs.isEmpty else {
            log("· 导入记录还是空的")
            log("  用这个 App 导进去的文件会自动记账。以前用别的版本导的，点「认领已导入的」让它对一遍")
            ui { self.pendingUndo = [] }
            return
        }

        let fm = FileManager.default
        let alive = recs.filter { fm.fileExists(atPath: $0.gamePath) }
        let gone = recs.count - alive.count

        ui { self.pendingUndo = alive }

        log("—— 看看要撤哪些（一个都还没动）——")
        var head = "记录 \(recs.count) 条，其中 \(alive.count) 个还在游戏里"
        if gone > 0 { head += "，\(gone) 个已经不在了" }
        log(head)
        for r in alive.prefix(40) {
            log("   · \(r.name)   \(r.sizeText)   \(r.time)")
        }
        if alive.count > 40 { log("   …… 还有 \(alive.count - 40) 个") }

        if alive.isEmpty {
            log("· 没有还在游戏里的导入文件。要清掉那些过期记录，点「清掉失效记录」")
        } else {
            log("对的话点红色「确认删 \(alive.count) 个」：删之前把游戏里那份收进 Backups，覆盖过原件的自动还原")
        }
    }

    // MARK: - 删除导入的文件

    func undoRun() {
        guard !busy else { return }
        let targets = pendingUndo
        guard !targets.isEmpty else {
            log("✗ 先点「看看要撤哪些」，清单看对了再删")
            return
        }

        busy = true
        let keep = undoKeepCopy
        let restoreBak = undoRestoreBackup
        let stamp = Fmt.stamp()
        let total = targets.count
        log("==== 删除导入的文件：\(total) 个 · \(keep ? "删前留副本" : "不留副本") · \(restoreBak ? "覆盖过原件的自动还原" : "不还原") ====")

        queue.async { [weak self] in
            guard let self = self else { return }

            let reports = AutoIO.undoImports(targets,
                                             backupRoot: LSPaths.backupRoot(),
                                             stamp: stamp,
                                             keepCopy: keep,
                                             restoreBackup: restoreBak,
                                             vaultDir: LSPaths.vaultDir()) { i, all, name in
                self.setProgress(Double(i) / Double(max(all, 1)), "\(i + 1)/\(all)  \(name)")
            }

            var ok = 0
            for r in reports {
                if let e = r.error {
                    self.log("✗ \(r.name) 没撤成：\(e)")
                } else {
                    ok += 1
                    self.log("✓ \(r.name) — \(r.action)")
                    ImportLog.markDeleted(id: r.id, hold: r.holdPath)
                }
            }

            self.setProgress(1, "完成")
            self.log("==== 删完：\(ok) / \(total) 个 ====")
            if keep && ok > 0 {
                self.log("素材库那份没动，随时点那行右边的「再导入」就能放回来，不用再选文件")
            }
            self.log("现在退掉游戏后台重新进，看是不是回到导入前的样子")

            let recs = ImportLog.load()
            self.ui {
                self.busy = false
                self.pendingUndo = []
                self.imported = recs
                self.banner = "已删掉 \(ok) 个导入文件"
                self.backups = LSPaths.backupList()
            }
            self.refreshGameOnly()
        }
    }

    /// 单条撤回
    func undoOne(_ r: ImportRecord) {
        guard !busy else { return }
        busy = true
        let keep = undoKeepCopy
        let restoreBak = undoRestoreBackup
        let stamp = Fmt.stamp()
        log("==== 撤回一条：\(r.name) ====")

        queue.async { [weak self] in
            guard let self = self else { return }
            let reports = AutoIO.undoImports([r],
                                             backupRoot: LSPaths.backupRoot(),
                                             stamp: stamp,
                                             keepCopy: keep,
                                             restoreBackup: restoreBak,
                                             vaultDir: LSPaths.vaultDir()) { _, _, _ in }

            if let one = reports.first {
                if let e = one.error {
                    self.log("✗ \(one.name)：\(e)")
                } else {
                    self.log("✓ \(one.name) — \(one.action)")
                    ImportLog.markDeleted(id: one.id, hold: one.holdPath)
                }
            }

            let recs = ImportLog.load()
            self.ui {
                self.busy = false
                self.imported = recs
                self.pendingUndo = self.pendingUndo.filter { $0.id != r.id }
            }
            self.refreshGameOnly()
        }
    }

    /// 删掉了想再导回来：优先从素材库拿，不用再碰「文件」App
    func redoOne(_ r: ImportRecord) {
        guard !busy else { return }

        // ① 素材库里有同名的 → 一键导回去（最主要的路子）
        if let v = LSPaths.vaultURL(for: r.name) {
            let attrs = try? FileManager.default.attributesOfItem(atPath: v.path)
            let size = (attrs?[.size] as? NSNumber)?.int64Value ?? r.size
            log("· 素材库里有这个文件，直接导回去，不用再选一次")
            importFromVault([PakItem(id: v.path, url: v, size: size)])
            return
        }

        // ② 素材库没有 → 用删前留的那份副本
        guard let hold = r.holdPath, FileManager.default.fileExists(atPath: hold) else {
            log("· 「\(r.name)」素材库里没找到，删前的副本也没留")
            log("  点「③ 添加文件」重新选一次就行，之后就能反复导了")
            return
        }
        busy = true
        log("==== 放回游戏：\(r.name) ====")

        queue.async { [weak self] in
            guard let self = self else { return }
            let err = AutoIO.putBack(from: hold, to: r.gamePath) { _, _, _ in }
            if let e = err {
                self.log("✗ \(r.name) 没放回去：\(e)")
            } else {
                self.log("✓ \(r.name) 已放回游戏")
                ImportLog.markRestored(id: r.id)
            }
            let recs = ImportLog.load()
            self.ui {
                self.busy = false
                self.imported = recs
            }
            self.refreshGameOnly()
        }
    }

    /// 认领：把「已导入」文件夹里、游戏里也确实存在同名的文件补记成账
    /// 专门对付以前用别的版本导进去、现在想撤掉的情况
    func adoptParked() {
        guard !busy else { return }
        guard let pd = paksDir else {
            log("✗ 还没拿到游戏 Paks 目录，认领不了")
            return
        }
        busy = true
        let park = LSPaths.importedDir()
        log("==== 认领：App 的「已导入」文件夹 ↔ 游戏 Paks ====")

        queue.async { [weak self] in
            guard let self = self else { return }
            let fm = FileManager.default
            guard let names = try? fm.contentsOfDirectory(atPath: park.path) else {
                self.log("· 「已导入」文件夹读不到，没东西可认领")
                self.ui { self.busy = false }
                return
            }

            var n = 0
            for name in names where !name.hasPrefix(".") {
                let src = park.appendingPathComponent(name)
                var isDir: ObjCBool = false
                guard fm.fileExists(atPath: src.path, isDirectory: &isDir), !isDir.boolValue else { continue }
                let dst = pd + "/" + name
                guard fm.fileExists(atPath: dst) else { continue }
                let attrs = try? fm.attributesOfItem(atPath: dst)
                let size = (attrs?[.size] as? NSNumber)?.int64Value ?? 0
                ImportLog.add(ImportRecord(name: name,
                                           gamePath: dst,
                                           size: size,
                                           time: Fmt.shortDate(),
                                           action: "新增",
                                           backupPath: nil))
                n += 1
                self.log("✓ 记上了：\(name)")
            }

            if n == 0 {
                self.log("· 没有能认领的（「已导入」里的文件在游戏里找不到同名的）")
            } else {
                self.log("==== 认领了 \(n) 个，现在点「② 删除导入的」就能撤 ====")
            }

            let recs = ImportLog.load()
            self.ui {
                self.busy = false
                self.imported = recs
                self.banner = "认领了 \(n) 个导入文件"
            }
            self.refreshGameOnly()
        }
    }

    /// 清掉「游戏里文件已经不在了」的过期记录
    func pruneRecords() {
        let gone = ImportLog.pruneMissing()
        imported = ImportLog.load()
        pendingUndo = pendingUndo.filter { FileManager.default.fileExists(atPath: $0.gamePath) && !$0.deleted }
        log(gone > 0 ? "· 清掉 \(gone) 条失效记录" : "· 没有失效记录，账是干净的")
    }

    // MARK: - 从手机里选文件（选一次，永久进素材库）

    func pickFiles(_ urls: [URL]) {
        guard !urls.isEmpty else { return }
        guard !busy else {
            log("· 正在忙，等这次跑完再点「添加文件」")
            return
        }

        let dest = LSPaths.vaultDir()
        let fm = FileManager.default
        if !fm.fileExists(atPath: dest.path) {
            try? fm.createDirectory(at: dest, withIntermediateDirectories: true)
        }

        busy = true
        let total = urls.count
        log("==== 收进素材库：\(total) 个 ====")

        queue.async { [weak self] in
            guard let self = self else { return }

            var ok = 0
            var bad: [URL] = []

            for (i, u) in urls.enumerated() {
                let scoped = u.startAccessingSecurityScopedResource()
                defer { if scoped { u.stopAccessingSecurityScopedResource() } }

                self.setProgress(Double(i) / Double(max(total, 1)), "\(i + 1)/\(total)  \(u.lastPathComponent)")

                var isDir: ObjCBool = false
                if !fm.fileExists(atPath: u.path, isDirectory: &isDir) {
                    bad.append(u)
                    continue
                }
                if isDir.boolValue {
                    self.log("· \(u.lastPathComponent) 是文件夹，跳过")
                    continue
                }

                let to = dest.appendingPathComponent(u.lastPathComponent)
                try? fm.removeItem(at: to)

                // 先复制到临时名，成功了再改名，避免留下半个文件
                let tmp = dest.appendingPathComponent(".ls_in_\(u.lastPathComponent)")
                try? fm.removeItem(at: tmp)
                do {
                    let name = u.lastPathComponent
                    try AutoIO.copyWithProgress(from: u, to: tmp) { p in
                        self.setProgress((Double(i) + p) / Double(max(total, 1)), "\(i + 1)/\(total)  \(name)")
                    }
                    try fm.moveItem(at: tmp, to: to)
                    let size = (try? fm.attributesOfItem(atPath: to.path))?[.size] as? NSNumber
                    ok += 1
                    self.log("✓ \(u.lastPathComponent) 已存进素材库  \(Fmt.size(size?.int64Value ?? 0))")
                } catch {
                    try? fm.removeItem(at: tmp)
                    self.log("· \(u.lastPathComponent) 读不出来：\(LSPaths.describe(error))")
                    bad.append(u)
                }
            }

            self.setProgress(1, "完成")

            if ok > 0 {
                self.log("==== 收了 \(ok) 个进素材库 ====")
                self.log("这份会一直留着：游戏里删多少次，点「再导入」都能从这儿拿回去，不用再选文件")
            }

            let list = LSPaths.listImportSources()
            self.ui {
                self.busy = false
                self.importList = list
                if ok > 0 {
                    self.banner = "素材库 +\(ok) 个"
                }
            }

            // 有读不出来的 → 自动换「先复制」模式再弹一次，等于兜底
            if !bad.isEmpty && ok == 0 {
                self.ui {
                    self.log("· 换个方式再试一次：让系统先复制一份过来")
                    DispatchQueue.main.asyncAfter(deadline: .now() + 0.35) {
                        FilePicker.shared.presentCopyMode(onPick: { urls2 in
                            if !urls2.isEmpty { self.pickFiles(urls2) }
                        }, onFail: { msg in
                            self.log("✗ \(msg)")
                        })
                    }
                }
            } else if !bad.isEmpty {
                self.ui {
                    self.log("· 有 \(bad.count) 个没读出来，其余都进库了")
                }
            }
        }
    }

    func pickFailed(_ msg: String) {
        log("✗ \(msg)")
    }

    // MARK: - 从素材库导进游戏（不需要再碰文件 App）

    /// 一键：素材库里全部导进游戏
    func importFromVaultAll() {
        importFromVault(LSPaths.listImportSources())
    }

    /// 把指定的这几个（素材库里的）导进游戏
    func importFromVault(_ items: [PakItem]) {
        guard !busy else { return }
        guard let pd = paksDir else {
            log("✗ 还没拿到游戏 Paks 目录，导不进去")
            log("  先回主界面点「一键打通游戏目录」，打通了再回来导")
            log("  打不通就看「通道诊断.txt」，把它发我")
            return
        }
        guard !items.isEmpty else {
            log("✗ 素材库是空的。点「③ 添加文件」从手机里选一次，选完就永久留着了")
            return
        }

        busy = true
        let overwrite = overwriteOn
        let stamp = Fmt.stamp()
        let total = items.count

        log("==== 从素材库导进游戏：\(total) 个 ====")
        log(overwrite ? "同名会在覆盖前备份原件" : "同名一律跳过（覆盖没开）")

        queue.async { [weak self] in
            guard let self = self else { return }

            // clearSource 固定为 false：素材库那份只复制、绝不挪走
            let reports = AutoIO.importAll(items: items,
                                           into: pd,
                                           backupRoot: LSPaths.backupRoot(),
                                           stamp: stamp,
                                           overwrite: overwrite,
                                           clearSource: false,
                                           sourcePark: LSPaths.vaultDir(),
                                           skipIdentical: true) { i, all, name in
                self.setProgress(Double(i) / Double(max(all, 1)), "\(i + 1)/\(all)  \(name)")
            }

            var ok = 0
            var skip = 0
            var bad = 0
            for r in reports {
                if let e = r.error {
                    if r.action.hasPrefix("跳过") {
                        skip += 1
                        self.log("· \(r.name) — \(r.action)：\(e)")
                    } else {
                        bad += 1
                        self.log("✗ \(r.name) — \(r.action)：\(e)")
                    }
                } else {
                    ok += 1
                    let bak = r.backedUp ? "（原件已备份）" : ""
                    self.log("✓ \(r.name) — \(r.action)，\(Fmt.size(r.size))\(bak)")
                    if let dp = r.dstPath {
                        ImportLog.touch(gamePath: dp,
                                        name: r.name,
                                        size: r.size,
                                        action: r.action.contains("覆盖") ? "覆盖" : "新增",
                                        backupPath: r.backupPath)
                    }
                }
            }

            self.setProgress(1, "完成")
            self.log("==== 导入结束：成功 \(ok) / 跳过 \(skip) / 失败 \(bad)，共 \(total) 个 ====")
            if ok > 0 {
                self.log("素材库那份还留着，以后想删想再导，随时点，不用再选文件")
                self.log("现在退掉游戏后台重新进，看效果")
            }

            let list = LSPaths.listImportSources()
            let recs = ImportLog.load()
            self.ui {
                self.busy = false
                self.importList = list
                self.imported = recs
                self.banner = "导入：成功 \(ok) / 共 \(total)"
                self.backups = LSPaths.backupList()
            }
            self.refreshGameOnly()
        }
    }


    /// 手动挑游戏里的包删（给「以前用别的工具导进去、没有记录」的包用）
    /// 删前留副本，删完记一笔，随时能「放回」
    func deleteGameFiles(_ targets: [PakItem]) {
        guard !busy else { return }
        guard !targets.isEmpty else { return }
        busy = true
        let keep = undoKeepCopy
        let stamp = Fmt.stamp()
        log("==== 手动删游戏里的包：\(targets.count) 个 · \(keep ? "删前留副本" : "不留副本") ====")

        queue.async { [weak self] in
            guard let self = self else { return }
            let reps = AutoIO.deleteAll(targets,
                                        backupRoot: LSPaths.backupRoot(),
                                        stamp: stamp,
                                        keepCopy: keep) { i, all, name in
                self.setProgress(Double(i) / Double(max(all, 1)), "\(i + 1)/\(all)  \(name)")
            }

            var ok = 0
            for r in reps {
                if let e = r.error {
                    self.log("✗ \(r.name)：\(e)")
                    continue
                }
                ok += 1
                self.log("✓ \(r.name) 已删")
                var rec = ImportRecord(name: r.name,
                                       gamePath: r.path,
                                       size: r.size,
                                       time: Fmt.shortDate(),
                                       action: "手动删",
                                       backupPath: nil)
                rec.deleted = true
                rec.deletedAt = Fmt.shortDate()
                rec.holdPath = r.movedTo
                ImportLog.add(rec)
            }

            self.setProgress(1, "完成")
            self.log("==== 删完：\(ok) / \(targets.count) 个 ====")
            if keep && ok > 0 {
                self.log("副本在 Backups/删掉的-\(stamp)/，「已导入」那页点「再导入」能拿回来")
            }

            let recs = ImportLog.load()
            self.ui {
                self.busy = false
                self.imported = recs
                self.banner = "手动删了 \(ok) 个"
                self.scanFound = self.scanFound.filter { fm in
                    !targets.contains(where: { $0.id == fm.id })
                }
            }
            self.refreshGameOnly()
        }
    }

    // MARK: - 全盘找 pak

    func fullScan() {
        guard !busy else { return }
        busy = true
        let gp = gamePath
        let pd = paksDir
        log("==== 全盘找 pak / sig ====")

        queue.async { [weak self] in
            guard let self = self else { return }
            var found: [PakItem] = []
            var seen = Set<String>()

            func absorb(_ list: [PakItem]) {
                for it in list {
                    if seen.contains(it.id) { continue }
                    seen.insert(it.id)
                    found.append(it)
                }
            }

            if let p = pd { absorb(LSPaths.scanDeep(p, depth: 8, limit: 5000)) }
            if let c = gp { absorb(LSPaths.scanDeep(c, depth: 10, limit: 5000)) }

            // 游戏目录扫得太少，就把其他 App 的容器也翻一遍（有全盘权限才翻得动）
            if found.count < 3 {
                if let names = try? FileManager.default.contentsOfDirectory(atPath: LSPaths.containerRoot) {
                    for n in names where !n.hasPrefix(".") {
                        let base = LSPaths.containerRoot + "/" + n
                        if let c = gp, base == c { continue }
                        absorb(LSPaths.scanDeep(base, depth: 8, limit: 300))
                        if found.count > 8000 { break }
                    }
                }
            }

            let pakN = found.filter { $0.ext == "pak" }.count
            let sigN = found.filter { $0.ext == "sig" }.count
            self.log("扫到 \(found.count) 个：pak \(pakN) 个 · sig \(sigN) 个")
            for it in found.prefix(30) {
                self.log("   · \(it.name)   \(it.sizeText)")
            }
            if found.count > 30 { self.log("   …… 还有 \(found.count - 30) 个") }

            if found.isEmpty {
                self.log("· 一个都没扫到：先确认游戏装过、至少进过一次游戏")
            } else {
                self.log("· 这份清单只给你看清游戏里都有啥，一个字节都没动")
            }

            self.ui {
                self.busy = false
                self.scanFound = found
                self.scanNote = "pak \(pakN) · sig \(sigN)"
                self.banner = "全盘扫到 \(found.count) 个 pak/sig"
            }
        }
    }
}
