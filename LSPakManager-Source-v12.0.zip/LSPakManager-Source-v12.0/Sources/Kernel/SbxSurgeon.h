//
//  SbxSurgeon.h
//  最小补丁：只改本进程的沙盒扩展链，动之前先备份，验不过立刻回滚。
//
//  设计原则（v9.1）：
//   1. 门诊（sxs_probe）只读，一个字节都不写。结构对不上就停，不进写路径。
//   2. 补丁分三级，一级一级往上加，每级都验证；一级通了就不再往上写。
//   3. 每次写之前把原值存进备份表，验不过 sxs_rollback() 原样写回。
//

#ifndef SBX_SURGEON_H
#define SBX_SURGEON_H

#include <stdint.h>

#ifdef __cplusplus
extern "C" {
#endif

#define SXS_LEVEL_MAX 3

typedef struct {
    int      ok;        // 1 = 结构自洽，可以往下走
    int      slots;     // ext_set 里读到有效 hdr 的槽数
    int      nodes;     // 链上有效的 sandbox extension 节点数
    int      dataok;    // 其中 data 指针也有效的节点数
    uint64_t ucred;
    uint64_t label;
    uint64_t sandbox;
    uint64_t extset;
    char     note[1024]; // 人话结论，直接进哨兵
} sxs_probe_t;

/// 内核读写是否已经就绪（没就绪时门诊会直接拒绝）
int sxs_ready(void);

/// 只读门诊：把 ucred → label → sandbox → ext_set → 每个 extension 走一遍，
/// 全部校验通过才算 ok。不写一个字节。
int sxs_probe(sxs_probe_t *out);

/// 门诊结论的指针（Swift 侧直接 String(cString:) 读）
const char *sxs_note(const sxs_probe_t *p);

/// 分级补丁。level: 1 / 2 / 3。返回改动次数，<0 失败。
///   1 = 只把扩展的权限类别改成 read-write（最小改动）
///   2 = 再把扩展的数据区放开（路径 + 标志位）
///   3 = 再把空的哈希槽补上（原版做法，最激进）
int sxs_patch(int level);

/// 把本次改过的所有字节按原值写回（倒序）
int sxs_rollback(void);

/// 已经改过的字节条数
int sxs_patch_count(void);

/// 真去 opendir 数条目；能列返回 >=0 的条目数，打不开返回负 errno
int sxs_open_count(const char *path);

/// 真去试写权限（不建文件，只查 access）
int sxs_writable(const char *path);

/// 最近一次文件操作的 errno
int sxs_errno(void);

/// 最近一次操作的结论，一句话
const char *sxs_verdict(void);

// MARK: - v9.8 凭证路线（不再改沙盒扩展链）

/// 把本进程凭证里的沙盒指针摘掉（指向 0）。
/// 只写 8 字节，只写内核堆，绝不碰任何字符串常量区。
/// 返回改动次数：1 = 写进去了，0 = 本来就没有沙盒，<0 = 没走成（原因见 sxs_cred_note）。
int sxs_cred_patch(void);

/// 把凭证路线写过的字节原样写回
int sxs_cred_rollback(void);

/// 凭证路线已经改过的条数
int sxs_cred_count(void);

/// 凭证路线最近一次结论，一句话
const char *sxs_cred_note(void);

/// 这个内核地址让不让写：1 = 可写（kalloc 堆），0 = 拒绝（只读映射 / 非法）
/// 写内核前必须先过这一关 —— 上一版就是写着写着写到只读的字符串常量区上。
int sxs_addr_writable(uint64_t addr);

// MARK: - v9.9 判定透明化 + 沙盒自检

/// 最近一次「可写区判定」的原话：允许 / 拒绝 + 具体地址和原因
const char *sxs_gate_note(void);

/// 沙盒自检：动手前后各问系统一次 file-read-data 能不能过
const char *sxs_sandbox_selfcheck(void);

/// 同一个沙盒结构除了凭证 label，还被 proc / proc_ro 里哪些位置指着（只读扫出来的）
const char *sxs_sandbox_refs(void);

// MARK: - v10.0 实证识别

/// 凭证 label 十六个槽的扫描结果：哪个槽最像沙盒、分多少、读到什么证据
const char *sxs_label_scan(void);

#ifdef __cplusplus
}
#endif

#endif /* SBX_SURGEON_H */
