//
//  CrashGuard.c
//
//  只做三件事：步骤落盘、崩溃取证、内存水位。
//  信号处理器里只用 open/write/fsync/close/_exit（都是 async-signal-safe），
//  字符串拼接也全部手写，不碰 printf / malloc。
//

#include "CrashGuard.h"

#include <signal.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <fcntl.h>
#include <stdio.h>
#include <limits.h>
#include <sys/sysctl.h>
#include <mach/mach.h>
#include <mach/task_info.h>
#include <time.h>

static char g_path[PATH_MAX];
static char g_stage[256];
static int  g_installed = 0;
static volatile uint64_t g_beat_ms = 0;
static char g_altstack[64 * 1024];

static long cg_append(char *buf, long pos, long cap, const char *s) {
    while (s && *s && pos < cap - 1) buf[pos++] = *s++;
    return pos;
}

static long cg_append_u64(char *buf, long pos, long cap, uint64_t v) {
    char tmp[24];
    int i = 0;
    if (v == 0) { if (pos < cap - 1) buf[pos++] = '0'; return pos; }
    while (v > 0 && i < 20) { tmp[i++] = (char)('0' + (int)(v % 10)); v /= 10; }
    while (i > 0 && pos < cap - 1) buf[pos++] = tmp[--i];
    return pos;
}

static long cg_append_hex(char *buf, long pos, long cap, uint64_t v) {
    const char *hx = "0123456789abcdef";
    int started = 0;
    if (pos < cap - 2) { buf[pos++] = '0'; buf[pos++] = 'x'; }
    for (int i = 15; i >= 0; i--) {
        int d = (int)((v >> (i * 4)) & 0xF);
        if (d || started || i == 0) {
            if (pos < cap - 1) buf[pos++] = hx[d];
            started = 1;
        }
    }
    return pos;
}

static void cg_write_now(const char *data, long len) {
    if (!g_path[0] || len <= 0) return;
    int fd = open(g_path, O_WRONLY | O_CREAT | O_TRUNC, 0644);
    if (fd < 0) return;
    long off = 0;
    while (off < len) {
        long n = write(fd, data + off, (size_t)(len - off));
        if (n <= 0) break;
        off += n;
    }
    fsync(fd);
    close(fd);
}

static uint64_t cg_now_ms(void) {
    struct timespec ts;
    if (clock_gettime(CLOCK_MONOTONIC, &ts) != 0) return 0;
    return (uint64_t)ts.tv_sec * 1000ULL + (uint64_t)ts.tv_nsec / 1000000ULL;
}

void cg_beat(void) {
    g_beat_ms = cg_now_ms();
}

uint64_t cg_beat_age_ms(void) {
    uint64_t t = g_beat_ms;
    if (t == 0) return 0;
    uint64_t n = cg_now_ms();
    return (n < t) ? 0 : (n - t);
}

const char *cg_current_stage(void) {
    return g_stage;
}

static void cg_handler(int sig, siginfo_t *info, void *ucontext) {
    (void)ucontext;
    char buf[640];
    long cap = (long)sizeof(buf);
    long p = 0;
    p = cg_append(buf, p, cap, "CRASH signal=");
    p = cg_append_u64(buf, p, cap, (uint64_t)sig);
    p = cg_append(buf, p, cap, " addr=");
    p = cg_append_hex(buf, p, cap, (uint64_t)(uintptr_t)(info ? info->si_addr : 0));
    p = cg_append(buf, p, cap, " stage=");
    p = cg_append(buf, p, cap, g_stage);
    p = cg_append(buf, p, cap, "\n");
    cg_write_now(buf, p);
    _exit(0);
}

void cg_install(const char *dirPath) {
    if (g_installed || !dirPath) return;
    snprintf(g_path, sizeof(g_path), "%s/内核哨兵.txt", dirPath);

    stack_t ss;
    memset(&ss, 0, sizeof(ss));
    ss.ss_sp = g_altstack;
    ss.ss_size = sizeof(g_altstack);
    ss.ss_flags = 0;
    sigaltstack(&ss, NULL);

    struct sigaction sa;
    memset(&sa, 0, sizeof(sa));
    sa.sa_sigaction = cg_handler;
    sa.sa_flags = SA_SIGINFO | SA_ONSTACK | SA_RESETHAND;
    sigemptyset(&sa.sa_mask);

    int sigs[] = { SIGSEGV, SIGBUS, SIGILL, SIGABRT, SIGFPE, SIGTRAP, SIGSYS };
    for (size_t i = 0; i < sizeof(sigs) / sizeof(sigs[0]); i++) {
        sigaction(sigs[i], &sa, NULL);
    }
    g_installed = 1;
}

void cg_mark(const char *stage) {
    if (!stage) return;
    cg_beat();
    long n = 0;
    while (stage[n] && n < (long)sizeof(g_stage) - 1) { g_stage[n] = stage[n]; n++; }
    g_stage[n] = 0;

    char buf[512];
    long cap = (long)sizeof(buf);
    long p = 0;
    p = cg_append(buf, p, cap, "RUNNING stage=");
    p = cg_append(buf, p, cap, g_stage);
    p = cg_append(buf, p, cap, "\n");
    cg_write_now(buf, p);
}

void cg_finish(void) {
    g_stage[0] = 0;
    cg_write_now("OK\n", 3);
}

char *cg_take_last_record(void) {
    if (!g_path[0]) return NULL;
    int fd = open(g_path, O_RDONLY);
    if (fd < 0) return NULL;
    char buf[768];
    long n = read(fd, buf, sizeof(buf) - 1);
    close(fd);
    if (n <= 0) return NULL;
    buf[n] = 0;
    if (strncmp(buf, "OK", 2) == 0) return NULL;
    char *out = malloc((size_t)n + 1);
    if (!out) return NULL;
    memcpy(out, buf, (size_t)n + 1);
    return out;
}

uint64_t cg_available_mb(void) {
    task_vm_info_data_t info;
    mach_msg_type_number_t count = TASK_VM_INFO_COUNT;
    kern_return_t kr = task_info(mach_task_self(), TASK_VM_INFO, (task_info_t)&info, &count);
    if (kr != KERN_SUCCESS) return 0;
    return (uint64_t)(info.limit_bytes_remaining >> 20);
}

uint64_t cg_physical_mb(void) {
    uint64_t mem = 0;
    size_t sz = sizeof(mem);
    if (sysctlbyname("hw.memsize", &mem, &sz, NULL, 0) != 0) return 0;
    return mem >> 20;
}
