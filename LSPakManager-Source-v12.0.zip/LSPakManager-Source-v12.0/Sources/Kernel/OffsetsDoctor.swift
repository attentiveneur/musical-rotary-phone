//
//  OffsetsDoctor.swift
//  内核布局自检 / 自校准
//
//  26.x 系列里，Apple 会在小版本间挪动 proc / thread 结构里的个别字段。
//  硬编码表在 26.0 上是对的，到 26.6.1 就可能差几十个字节。
//  这里在拿到内核读写能力之后、动任何文件之前，先用只读探测把关键偏移
//  按本机内核实测校准一遍：
//
//    - proc：p_pid 必须是 0（kernel_task）、p_name 必须是 "kernel_task"
//    - proc_ro：p_proc_ro_pr_task 必须指向一个内核对象
//    - thread：tro_proc 必须指回本进程的 proc_ro
//
//  全程只读，不往内核写任何东西。对不上就明确报错停下，绝不硬来。
//

import Foundation

struct OffsetsVerdict {
    var ok: Bool
    var notes: [String]
    var adjusted: Int
}

enum OffsetsDoctor {

    private static func isKernelPointer(_ a: UInt64) -> Bool {
        a >= 0xFFFF000000000000 && a != 0xFFFFFFFFFFFFFFFF
    }

    private static func readU32(_ addr: UInt64) -> UInt32 {
        ds_kread32(addr)
    }

    private static func readU64(_ addr: UInt64) -> UInt64 {
        ds_kread64(addr)
    }

    /// 读内核里的内联 C 字符串（p_name 是 char 数组，不是指针）
    private static func readCString(_ addr: UInt64, max: Int = 32) -> String? {
        guard addr != 0 else { return nil }
        var buf = [UInt8](repeating: 0, count: max)
        buf.withUnsafeMutableBytes { raw in
            guard let base = raw.baseAddress else { return }
            ds_kreadbuf(addr, base, UInt64(max))
        }
        guard let zero = buf.firstIndex(of: 0), zero > 0 else { return nil }
        let bytes = Array(buf[0..<zero])
        guard bytes.count <= 24 else { return nil }
        for b in bytes where b < 0x20 || b > 0x7E { return nil }
        return String(bytes: bytes, encoding: .utf8)
    }

    /// 在 [from, to] 里按 step 找一个值为 0 的 u32
    private static func scanForZero(_ base: UInt64, from: Int, to: Int, step: Int) -> [Int] {
        var hits: [Int] = []
        var off = from
        while off <= to {
            cg_beat()
            if readU32(base + UInt64(off)) == 0 { hits.append(off) }
            off += step
        }
        return hits
    }

    /// 扫描 "kernel_task" 内联字符串的位置
    private static func scanProcName(_ kernproc: UInt64, hint: Int) -> Int? {
        let target = "kernel_task"

        func at(_ off: Int) -> Bool {
            guard off >= 0x100, off <= 0x900 else { return false }
            return readCString(kernproc + UInt64(off)) == target
        }

        if at(hint) { return hint }

        // 先在已知位置附近细扫，命中率最高、最省时间
        let lo = max(0x100, hint - 0x100)
        let hi = min(0x900, hint + 0x100)
        var off = lo
        while off <= hi {
            cg_beat()
            if at(off) { return off }
            off += 1
        }

        // 再整段扫一遍（只在提示位置彻底失准时才会走到这里）
        off = 0x100
        while off <= 0x900 {
            cg_beat()
            if at(off) { return off }
            off += 1
        }
        return nil
    }

    /// 激活成功后、抓内核缓存之前先跑一次。
    /// 用本进程的 proc 当锚点：pid 一定等于 getpid()，这个不用猜。
    /// 26.x 上 proc 布局若漂了，这一步就能发现并挪回来，后面的抓取才站得住。
    static func preflight(log: @escaping (String) -> Void) -> OffsetsVerdict {
        var notes: [String] = []
        var adjusted = 0

        guard ds_is_ready() else {
            return OffsetsVerdict(ok: false, notes: ["内核读写还没就位"], adjusted: 0)
        }

        let ourProc = ds_get_our_proc()
        guard isKernelPointer(ourProc) else {
            return OffsetsVerdict(ok: false, notes: ["拿不到本进程的 proc 地址，先不往下走"], adjusted: 0)
        }

        let expected = UInt32(bitPattern: Int32(getpid()))

        var pidOff = Int(off_proc_p_pid)
        if readU32(ourProc + UInt64(pidOff)) != expected {
            var found: Int? = nil
            var cand = 0x40
            while cand <= 0x100 {
                if readU32(ourProc + UInt64(cand)) == expected {
                    found = cand
                    break
                }
                cand += 4
            }
            if let f = found {
                log("p_pid 偏移对不上（原 0x\(String(pidOff, radix: 16)) → 实测 0x\(String(f, radix: 16))），已按本机校准")
                pidOff = f
                off_proc_p_pid = UInt32(f)
                adjusted += 1
            } else {
                notes.append("本进程的 pid 字段没找到，proc 布局可能和已知差得较远")
            }
        } else {
            notes.append("p_pid 对上了（0x\(String(pidOff, radix: 16))）")
        }

        var procROOff = Int(off_proc_p_proc_ro)
        var procRO = readU64(ourProc + UInt64(procROOff))
        if !isKernelPointer(procRO) || readU64(procRO + UInt64(off_proc_ro_pr_task)) == 0 {
            var found: Int? = nil
            var cand = 0x0
            while cand <= 0x60 {
                let v = readU64(ourProc + UInt64(cand))
                if isKernelPointer(v) && isKernelPointer(readU64(v + UInt64(off_proc_ro_pr_task))) {
                    found = cand
                    break
                }
                cand += 8
            }
            if let f = found {
                log("p_proc_ro 偏移对不上（原 0x\(String(procROOff, radix: 16)) → 实测 0x\(String(f, radix: 16))），已按本机校准")
                procROOff = f
                procRO = readU64(ourProc + UInt64(f))
                off_proc_p_proc_ro = UInt32(f)
                adjusted += 1
            } else {
                notes.append("p_proc_ro 没校准出来")
            }
        } else {
            notes.append("p_proc_ro 对上了（0x\(String(procROOff, radix: 16))）")
        }

        let ok = isKernelPointer(procRO) && isKernelPointer(readU64(procRO + UInt64(off_proc_ro_pr_task)))
        return OffsetsVerdict(ok: ok, notes: notes, adjusted: adjusted)
    }

    /// 主入口：kernelBase 来自 darksword，kernproc 偏移来自 xpf 解析结果
    static func verify(kernelBase: UInt64, log: @escaping (String) -> Void) -> OffsetsVerdict {
        var notes: [String] = []
        var adjusted = 0

        guard ds_is_ready(), kernelBase != 0 else {
            return OffsetsVerdict(ok: false, notes: ["内核读写还没就位"], adjusted: 0)
        }

        let defaults = UserDefaults.standard
        guard let kernprocOff = defaults.object(forKey: "lara.kernprocoff") as? NSNumber else {
            return OffsetsVerdict(ok: false, notes: ["内核符号没解析出来，拿不到 kernel_task 的位置"], adjusted: 0)
        }

        let kernproc = kernelBase + kernprocOff.uint64Value
        guard isKernelPointer(kernproc) else {
            return OffsetsVerdict(ok: false, notes: ["kernel_task 地址看着不像内核空间，解析结果不可信"], adjusted: 0)
        }
        log(String(format: "kernel_task 0x%llx", kernproc))

        // ── 1. p_name：先认人，别的都好说
        var nameOff = Int(off_proc_p_name)
        var name = readCString(kernproc + UInt64(nameOff))
        if name != "kernel_task" {
            if let found = scanProcName(kernproc, hint: nameOff) {
                log("p_name 偏移对不上（原 0x\(String(nameOff, radix: 16)) → 实测 0x\(String(found, radix: 16))），按本机内核校准")
                nameOff = found
                off_proc_p_name = UInt32(found)
                name = "kernel_task"
                adjusted += 1
            } else {
                notes.append("找不到 kernel_task 的名字字段，这台机器的 proc 结构和已知布局差得太远")
            }
        } else {
            notes.append("p_name 对上了（0x\(String(nameOff, radix: 16))）")
        }

        // ── 2. p_pid：kernel_task 的 pid 恒为 0
        var pidOff = Int(off_proc_p_pid)
        if readU32(kernproc + UInt64(pidOff)) != 0 {
            var picked: Int? = nil
            for cand in scanForZero(kernproc, from: 0x40, to: 0xC0, step: 4) {
                // 附近 id 字段一般紧跟 pid：确认 +4 是 0（p_ppid 对 kernel_task 也是 0）
                if readU32(kernproc + UInt64(cand) + 4) == 0 {
                    picked = cand
                    break
                }
            }
            if let found = picked {
                log("p_pid 偏移对不上（原 0x\(String(pidOff, radix: 16)) → 实测 0x\(String(found, radix: 16))），已校准")
                pidOff = found
                off_proc_p_pid = UInt32(found)
                adjusted += 1
            } else {
                notes.append("p_pid 偏移没校准出来")
            }
        } else {
            notes.append("p_pid 对上了（0x\(String(pidOff, radix: 16))）")
        }

        // ── 3. proc → proc_ro → task，整条链要能走通
        var procROOff = Int(off_proc_p_proc_ro)
        var procRO = readU64(kernproc + UInt64(procROOff))
        if !isKernelPointer(procRO) {
            var fixed = false
            var cand = 0x0
            while cand <= 0x60 {
                let v = readU64(kernproc + UInt64(cand))
                if isKernelPointer(v) {
                    let task = readU64(v + UInt64(off_proc_ro_pr_task))
                    if isKernelPointer(task) {
                        log("p_proc_ro 偏移对不上（原 0x\(String(procROOff, radix: 16)) → 实测 0x\(String(cand, radix: 16))），已校准")
                        procROOff = cand
                        procRO = v
                        off_proc_p_proc_ro = UInt32(cand)
                        adjusted += 1
                        fixed = true
                        break
                    }
                }
                cand += 8
            }
            if !fixed { notes.append("p_proc_ro 没校准出来") }
        } else {
            notes.append("p_proc_ro 对上了（0x\(String(procROOff, radix: 16))）")
        }

        var chainOK = false
        if isKernelPointer(procRO) {
            let task = readU64(procRO + UInt64(off_proc_ro_pr_task))
            if isKernelPointer(task) {
                let itk = readU64(task + UInt64(off_task_itk_space))
                if isKernelPointer(itk) {
                    chainOK = true
                    notes.append("proc → proc_ro → task 链路通")
                } else {
                    notes.append("task 里读不到 itk_space，task 结构偏移可能变了")
                }
            } else {
                notes.append("proc_ro 里读不到 pr_task")
            }
        }

        // ── 4. thread：tro 链要指回本进程的 proc_ro（沙盒逃逸要用）
        let ourProc = ds_get_our_proc()
        let ourTask = ds_get_our_task()
        if ourProc != 0, ourTask != 0, isKernelPointer(procRO) {
            let ourProcRO = readU64(ourProc + UInt64(procROOff))
            let thread0 = readU64(ourTask + UInt64(off_task_threads_next))
            if isKernelPointer(thread0) && isKernelPointer(ourProcRO) {
                var troOff = Int(off_thread_t_tro)
                let tro = readU64(thread0 + UInt64(troOff))
                func troPointsBack(_ t: UInt64) -> Bool {
                    guard isKernelPointer(t) else { return false }
                    return readU64(t + UInt64(off_thread_ro_tro_proc)) == ourProcRO
                }
                if !troPointsBack(tro) {
                    var fixed = false
                    var cand = 0x300
                    while cand <= 0x480 {
                        let t = readU64(thread0 + UInt64(cand))
                        if troPointsBack(t) {
                            log("thread_ro 偏移对不上（原 0x\(String(troOff, radix: 16)) → 实测 0x\(String(cand, radix: 16))），已校准")
                            troOff = cand
                            off_thread_t_tro = UInt32(cand)
                            adjusted += 1
                            fixed = true
                            break
                        }
                        cand += 8
                    }
                    if !fixed { notes.append("thread_ro 偏移没校准出来（沙盒逃逸可能受影响）") }
                } else {
                    notes.append("thread_ro 对上了（0x\(String(troOff, radix: 16))）")
                }
            } else {
                notes.append("线程链表没走通，跳过 thread 校准")
            }
        }

        let fatal = (name != "kernel_task") || !chainOK
        return OffsetsVerdict(ok: !fatal, notes: notes, adjusted: adjusted)
    }
}
