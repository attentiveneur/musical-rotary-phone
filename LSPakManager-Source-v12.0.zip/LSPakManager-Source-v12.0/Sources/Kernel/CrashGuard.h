//
//  CrashGuard.h
//  崩溃哨兵
//
//  内核这一步如果失败，进程是被系统直接拿掉的，界面上什么都留不下。
//  所以每走一步都把「现在在哪一步」落盘（带 fsync），并在进程里装好
//  异常信号处理，真崩了也先把崩在哪一步写进文件，下次打开 App 能看到。
//

#ifndef CRASH_GUARD_H
#define CRASH_GUARD_H

#include <stdint.h>
#include <stddef.h>

/// 安装哨兵。dirPath 是用来放记录文件的目录（App 的 Documents）。
void cg_install(const char *dirPath);

/// 标记当前步骤，立即落盘。
void cg_mark(const char *stage);

/// 正常走完，清掉进行中的标记。
void cg_finish(void);

/// 取出上次运行留下的记录（malloc 出来，调用方 free）。
/// 没有记录返回 NULL。
char *cg_take_last_record(void);

/// 把当下进程的内存水位写进日志用（返回 MB）。
uint64_t cg_available_mb(void);
uint64_t cg_physical_mb(void);

/// 心跳：内核那段 C 代码每走一小步调一次（只写内存，不落盘，开销极小）。
/// 界面侧据此判断「是不是卡死了」——超过预算没心跳就是卡住，直接报超时，
/// 不再让用户对着一个永远转圈的按钮干等。
void cg_beat(void);

/// 距离上次心跳多少毫秒。从没跳过返回 0。
uint64_t cg_beat_age_ms(void);

/// 当前步骤名（只读，给诊断用）。
const char *cg_current_stage(void);

#endif /* CRASH_GUARD_H */
