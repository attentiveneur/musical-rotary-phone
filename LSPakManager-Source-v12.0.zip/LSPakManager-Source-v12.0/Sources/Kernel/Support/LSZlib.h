//
//  LSZlib.h
//  解压 pak 包里的 zlib 数据块（游戏包里每个条目的内容都是 zlib 压缩的）
//

#ifndef LS_ZLIB_H
#define LS_ZLIB_H

#include <stdint.h>
#include <stddef.h>

#ifdef __cplusplus
extern "C" {
#endif

/// 把 src 开头的 zlib 流完整解开。
/// 成功返回 0，并通过 outPtr(malloc 出来的缓冲，用完调 ls_zlib_free)/outLen/consumed 回传；
/// 失败返回 -1。
int ls_zlib_inflate(const unsigned char *src,
                    size_t srcLen,
                    unsigned char **outPtr,
                    size_t *outLen,
                    size_t *consumed,
                    size_t maxOut);

/// 释放 ls_zlib_inflate 给出的缓冲
void ls_zlib_free(void *p);

#ifdef __cplusplus
}
#endif

#endif
