//
//  LSZlib.c
//  增量解压，输出不够就自己长，最多长到 maxOut，超了就按失败处理（防止被坏数据撑爆内存）
//

#include "LSZlib.h"
#include <stdlib.h>
#include <string.h>
#include <zlib.h>

int ls_zlib_inflate(const unsigned char *src,
                    size_t srcLen,
                    unsigned char **outPtr,
                    size_t *outLen,
                    size_t *consumed,
                    size_t maxOut)
{
    if (!src || srcLen == 0 || !outPtr || !outLen || !consumed) return -1;
    *outPtr = NULL;
    *outLen = 0;
    *consumed = 0;
    if (maxOut == 0) return -1;

    z_stream s;
    memset(&s, 0, sizeof(s));
    if (inflateInit(&s) != Z_OK) return -1;

    size_t cap = srcLen * 3;
    if (cap < 65536) cap = 65536;
    if (cap > maxOut) cap = maxOut;
    if (cap > (size_t)0x40000000) cap = (size_t)0x40000000;   /* uInt 上限内 */

    unsigned char *buf = (unsigned char *)malloc(cap);
    if (!buf) { inflateEnd(&s); return -1; }

    s.next_in  = (Bytef *)src;
    s.avail_in = (uInt)(srcLen > 0x7FFFFFFF ? 0x7FFFFFFF : srcLen);

    size_t total = 0;
    int ok = 0;

    for (;;) {
        if (total >= cap) {
            if (cap >= maxOut) break;          /* 超过上限，放弃 */
            size_t ncap = cap * 2;
            if (ncap > maxOut) ncap = maxOut;
            if (ncap <= cap) break;
            unsigned char *nb = (unsigned char *)realloc(buf, ncap);
            if (!nb) break;
            buf = nb;
            cap = ncap;
        }

        s.next_out  = buf + total;
        s.avail_out = (uInt)(cap - total);

        int r = inflate(&s, Z_NO_FLUSH);
        total = cap - (size_t)s.avail_out;

        if (r == Z_STREAM_END) {
            *consumed = (size_t)(s.next_in - (Bytef *)src);
            ok = 1;
            break;
        }
        if (r != Z_OK) break;
        if (s.avail_in == 0 && s.avail_out != 0) break;   /* 数据不够，流没结束 */
    }

    inflateEnd(&s);

    if (!ok || *consumed == 0) {
        free(buf);
        return -1;
    }
    *outPtr = buf;
    *outLen = total;
    return 0;
}

void ls_zlib_free(void *p)
{
    if (p) free(p);
}
