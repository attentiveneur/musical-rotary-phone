//
//  FilePicker.swift
//  v8.5
//
//  v6.x 用的是 SwiftUI 自带的 .fileImporter(allowedContentTypes: [.data])，
//  那个东西遇到 .pak / .sig 这种没在系统里登记过的后缀，会直接把「打开」按钮变灰，
//  表现就是「选好文件了点打开没反应」。8.x 换成 UIKit 的选择器就没这毛病了。
//
//  v8.5 再补两件事：
//  1) 默认用「不复制」模式：点「打开」立刻把地址交回来，马上有反应，
//     复制到大文件（几百兆的 pak）由我们自己后台做，界面显示进度条，不假死。
//  2) 万一某个文件读不出来（权限/云盘没下载完），自动换「先复制」模式再弹一次，
//     等于一个兜底，不会再出现「点了跟没点一样」。
//

import UIKit
import UniformTypeIdentifiers

final class FilePicker: NSObject, UIDocumentPickerDelegate {

    static let shared = FilePicker()

    private var onPick: (([URL]) -> Void)?
    private var onFail: ((String) -> Void)?

    /// 允许选择的文件类型。
    /// 只放「文件类型」，不放 .item / .folder —— 文件夹会自己变灰，不会误选一整个文件夹。
    /// .data 打头是关键：所有以 public.data 为基础的（包括 .pak 这种动态类型）都能选中、
    /// 「打开」按钮一直可用。
    private static var pickTypes: [UTType] {
        var t: [UTType] = [.data, .content, .archive, .zip, .text, .image, .movie]
        // 游戏资源包常用后缀，明确登记一遍，选择器里显示正常名、正常可点
        for ext in ["pak", "sig", "uasset", "ucas", "utoc", "ini", "json", "obb"] {
            if let u = UTType(filenameExtension: ext) {
                t.append(u)
            }
        }
        return t
    }

    /// 标准模式：不预复制，点「打开」立刻返回地址（大数据包也不会卡）
    func present(onPick: @escaping ([URL]) -> Void,
                 onFail: @escaping (String) -> Void) {
        presentPicker(asinCopy: false, onPick: onPick, onFail: onFail)
    }

    /// 兜底模式：让系统先复制一份到 App 的临时目录再返回。
    /// 读不了原文件的（iCloud 没下完、别的 App 目录受限）走这条能成。
    func presentCopyMode(onPick: @escaping ([URL]) -> Void,
                         onFail: @escaping (String) -> Void) {
        presentPicker(asinCopy: true, onPick: onPick, onFail: onFail)
    }

    private func presentPicker(asinCopy: Bool,
                               onPick: @escaping ([URL]) -> Void,
                               onFail: @escaping (String) -> Void) {
        guard let host = FilePicker.topViewController() else {
            // 关键：找不到能弹窗的界面时要明说，不能静默什么都没发生
            onFail("刚才界面还没准备好，再点一次「添加文件」就行")
            return
        }
        self.onPick = onPick
        self.onFail = onFail

        let picker = UIDocumentPickerViewController(forOpeningContentTypes: FilePicker.pickTypes,
                                                    asCopy: asinCopy)
        picker.delegate = self
        picker.allowsMultipleSelection = true
        picker.shouldShowFileExtensions = true
        // iPhone 上是全屏，iPad 上是居中小窗；用 .formSheet 两边都正常弹
        picker.modalPresentationStyle = .formSheet

        DispatchQueue.main.async {
            host.present(picker, animated: true) {
                // present 完成后再确认一次，被别的弹窗挤掉就报出来
                if host.presentedViewController !== picker {
                    let f = self.onFail
                    self.onPick = nil
                    self.onFail = nil
                    f?("选择器没能弹出来，退出重进 App 再试一次")
                }
            }
        }
    }

    // MARK: - 回调

    func documentPicker(_ controller: UIDocumentPickerViewController,
                        didPickDocumentsAt urls: [URL]) {
        let cb = onPick
        onPick = nil
        onFail = nil
        if urls.isEmpty {
            cb?([])
            return
        }
        cb?(urls)
    }

    func documentPickerWasCancelled(_ controller: UIDocumentPickerViewController) {
        let cb = onPick
        onPick = nil
        onFail = nil
        cb?([])
    }

    // MARK: - 找到最上面那层界面，用来弹选择器

    private static func topViewController() -> UIViewController? {
        var root: UIViewController?
        let scenes = UIApplication.shared.connectedScenes
        for s in scenes {
            guard let ws = s as? UIWindowScene else { continue }
            if let w = ws.windows.first(where: { $0.isKeyWindow }) ?? ws.windows.first {
                root = w.rootViewController
                break
            }
        }
        var vc = root
        while let p = vc?.presentedViewController {
            // 已经有一层在选择器了，就别再叠一层
            if p is UIDocumentPickerViewController { return nil }
            // 系统弹的（比如权限提示）先等它关掉
            if p.isBeingDismissed { return nil }
            vc = p
        }
        return vc
    }
}
