import Foundation

/// 导入记录簿：谁被导进游戏了，一条一条记下来
/// 「删除导入的文件」就是照这本账来撤，不靠关键字乱猜
enum ImportLog {

    static func fileURL() -> URL {
        LSPaths.docDir().appendingPathComponent("import_log.json")
    }

    static func load() -> [ImportRecord] {
        let fm = FileManager.default
        let u = fileURL()
        guard fm.fileExists(atPath: u.path) else { return [] }
        guard let data = try? Data(contentsOf: u) else { return [] }
        guard let list = try? JSONDecoder().decode([ImportRecord].self, from: data) else { return [] }
        return list
    }

    @discardableResult
    static func save(_ list: [ImportRecord]) -> Bool {
        var capped = list
        if capped.count > 600 { capped = Array(capped.prefix(600)) }
        guard let data = try? JSONEncoder().encode(capped) else { return false }
        do {
            try data.write(to: fileURL(), options: .atomic)
            return true
        } catch {
            return false
        }
    }

    /// 新导进去一条：同一个目标位置只留最新一条有效记录
    static func add(_ r: ImportRecord) {
        var list = load()
        list.removeAll { $0.gamePath == r.gamePath && !$0.deleted }
        list.insert(r, at: 0)
        save(list)
    }

    /// 导入成功时记账：
    /// 这个位置以前导过、后来删了的，就把那条旧记录复用回来（标回「在游戏里」），
    /// 不再往上叠新记录，账不会越攒越乱。
    static func touch(gamePath: String,
                      name: String,
                      size: Int64,
                      action: String,
                      backupPath: String?) {
        var list = load()
        // 先按同一个目标位置找；找不到就按文件名找那条以前删掉的（换过目录也能对上）
        var idx = list.firstIndex(where: { $0.gamePath == gamePath })
        if idx == nil {
            idx = list.firstIndex(where: { $0.name == name && $0.deleted })
        }
        if let i = idx {
            list[i].gamePath = gamePath
            list[i].name = name
            list[i].size = size
            list[i].time = Fmt.shortDate()
            list[i].action = action
            list[i].backupPath = backupPath ?? list[i].backupPath
            list[i].deleted = false
            list[i].deletedAt = nil
            list[i].holdPath = nil
            let one = list.remove(at: i)
            list.insert(one, at: 0)
            save(list)
        } else {
            list.insert(ImportRecord(name: name,
                                     gamePath: gamePath,
                                     size: size,
                                     time: Fmt.shortDate(),
                                     action: action,
                                     backupPath: backupPath), at: 0)
            save(list)
        }
    }

    static func markDeleted(id: String, hold: String?) {
        var list = load()
        for i in list.indices where list[i].id == id {
            list[i].deleted = true
            list[i].deletedAt = Fmt.shortDate()
            list[i].holdPath = hold
        }
        save(list)
    }

    static func markRestored(id: String) {
        var list = load()
        for i in list.indices where list[i].id == id {
            list[i].deleted = false
            list[i].deletedAt = nil
            list[i].holdPath = nil
        }
        save(list)
    }

    static func remove(id: String) {
        var list = load()
        list.removeAll { $0.id == id }
        save(list)
    }

    /// 清掉「文件已经不在了」的旧记录，别让账越攒越乱
    static func pruneMissing() -> Int {
        let list = load()
        let fm = FileManager.default
        let keep = list.filter { fm.fileExists(atPath: $0.gamePath) || $0.deleted }
        let gone = list.count - keep.count
        if gone > 0 { save(keep) }
        return gone
    }
}
