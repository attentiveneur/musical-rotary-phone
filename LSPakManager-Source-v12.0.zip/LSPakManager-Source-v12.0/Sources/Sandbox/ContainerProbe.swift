//
//  ContainerProbe.swift
//  权限体检：把「为什么拿不到游戏目录」查到确定，不留猜的空间
//
//  v8.8 之前只报一句「没有容器」，看不出是：
//    ① 签名没带容器管理权限（普通证书签的都这样）
//    ② 系统上压根没有容器查询接口
//    ③ 游戏没装 / bundle id 对不上
//    ④ 路径拿到了但沙盒不让读写
//  这版把四件事分开测，全部写进「通道探测.txt」，一看就知道卡哪一类。
//
//  只读探测：不写内核、不改任何系统文件、不尝试提权。
//

import Foundation
import UIKit
import Darwin
import CoreFoundation
import Security

enum ProbeVerdict: String {
    case containerAccessGranted   = "容器访问权已拿到"
    case signatureLacksPrivilege  = "签名不带容器权限"
    case serviceUnavailable       = "系统没有容器接口"
    case gameNotFound             = "找不到这个 App"
    case readOnly                 = "能读不能写"
    case unknown                  = "情况不明"
}

struct ProbeReport {
    var verdict: ProbeVerdict = .unknown
    /// 给界面用的一句话结论
    var headline: String = "还没测"
    /// 给用户看的建议（怎么才对这件事有用）
    var advice: String = ""
    var text: String = ""
    var containerPath: String?
    var mcmPath: String?
    var proxyPath: String?
}

final class ContainerProbe {

    static let shared = ContainerProbe()
    private init() {}

    // 这些是「能管别人容器」的签名权限，普通个人/企业证书签出来都不会有
    private let privilegeKeys = [
        "com.apple.private.mobilecontainer.management",
        "com.apple.private.security.container-manager",
        "com.apple.private.sandbox.container-token",
        "com.apple.private.security.storage.AppDataContainers",
        "com.apple.private.sandbox.extension",
        "com.apple.private.sandbox.extension.issue",
        "platform-application"
    ]

    private let containerSymbols = [
        "container_query_create",
        "container_query_set_identifiers",
        "container_query_set_class",
        "container_query_set_part_identifier",
        "container_query_set_transient",
        "container_query_get_single_result",
        "container_query_get_single_result_with_error",
        "container_query_get_result",
        "container_query_free",
        "container_get_path",
        "container_copy_path",
        "container_copy_sandbox_token",
        "container_retain",
        "container_release",
        "container_free_object",
        "container_get_class"
    ]

    private let sandboxSymbols = [
        "sandbox_extension_consume",
        "sandbox_extension_release",
        "sandbox_extension_issue_file",
        "sandbox_container_path",
        "sandbox_check"
    ]

    // MARK: - 入口

    func run(bundleId: String) -> ProbeReport {
        var r = ProbeReport()
        var lines: [String] = []

        func put(_ s: String) { lines.append(s) }

        put("浪神文件管理器 · 权限探测")
        put("时间：\(Date())")
        put("设备：\(Compatibility.deviceSummary())")
        put("系统：\(Compatibility.shortSystem())")
        put("目标 App：\(bundleId)")
        put("")

        // ① 自身签名权限
        let ents = selfEntitlements()
        put("── ① 本 App 的签名权限（决定能不能管别人的容器）──")
        if ents.isEmpty {
            put("· 读不到签名权限表")
        } else {
            for k in ents.keys.sorted() {
                put("· \(k) = \(ents[k] ?? "")")
            }
        }
        var missing: [String] = []
        for k in privilegeKeys where ents[k] == nil {
            missing.append(k)
        }
        put("· 缺少的关键权限：\(missing.isEmpty ? "无（这台机器给了容器管理权限）" : missing.joined(separator: "、"))")
        put("")

        // ② 容器接口
        put("── ② 系统的容器查询接口 ──")
        let ch = openLib(["/usr/lib/system/libsystem_containermanager.dylib",
                          "/usr/lib/libsystem_containermanager.dylib",
                          "/System/Library/PrivateFrameworks/MobileContainerManager.framework/MobileContainerManager"])
        if let ch = ch {
            for s in containerSymbols {
                put("· \(s)：\(dlsym(ch, s) != nil ? "有" : "没有")")
            }
        } else {
            put("· 容器服务库加载不起来")
        }
        put("")

        put("── ③ 沙盒接口 ──")
        let sh = openLib(["/usr/lib/system/libsystem_sandbox.dylib",
                          "/usr/lib/libsystem_sandbox.dylib"])
        if let sh = sh {
            for s in sandboxSymbols {
                put("· \(s)：\(dlsym(sh, s) != nil ? "有" : "没有")")
            }
        } else {
            put("· 沙盒库加载不起来")
        }
        put("")

        // ④ 按每个容器类别问一次，把结果和错误码都记下来
        put("── ④ 按容器类别逐个问（看系统怎么回）──")
        var hitContainer = false
        if let ch = ch,
           let create = symFn(ch, "container_query_create"),
           let setIds = symFn(ch, "container_query_set_identifiers") {
            let identArray = NSArray(object: bundleId)
            let boxed = Unmanaged.passUnretained(identArray).toOpaque()
            let setClass = symFn(ch, "container_query_set_class")
            let getOne = symFn(ch, "container_query_get_single_result")
            let getOneErr = symFn(ch, "container_query_get_single_result_with_error")
            let getPathFn = symFn(ch, "container_get_path")
            let copyPathFn = symFn(ch, "container_copy_path")

            let queryCreate = unsafeBitCast(create, to: (@convention(c) () -> UnsafeMutableRawPointer?).self)
            let querySetIds = unsafeBitCast(setIds, to: (@convention(c) (UnsafeMutableRawPointer?, UnsafeRawPointer?) -> Void).self)

            for cls in UInt32(0)...UInt32(16) {
                guard let q = queryCreate() else { continue }
                if cls > 0, let sc = setClass {
                    unsafeBitCast(sc, to: (@convention(c) (UnsafeMutableRawPointer?, UInt32) -> Void).self)(q, cls)
                }
                querySetIds(q, boxed)

                var c: UnsafeMutableRawPointer? = nil
                if let ge = getOne {
                    c = unsafeBitCast(ge, to: (@convention(c) (UnsafeMutableRawPointer?) -> UnsafeMutableRawPointer?).self)(q)
                }
                var errCode = "—"
                if c == nil, let gee = getOneErr {
                    var err: UnsafeRawPointer? = nil
                    c = unsafeBitCast(gee, to: (@convention(c) (UnsafeMutableRawPointer?, UnsafeMutablePointer<UnsafeRawPointer?>?) -> UnsafeMutableRawPointer?).self)(q, &err)
                    if let e = err {
                        errCode = describeContainerError(e)
                    }
                }
                if let c = c {
                    var p = "—"
                    if let gp = getPathFn {
                        let raw = unsafeBitCast(gp, to: (@convention(c) (UnsafeMutableRawPointer?) -> UnsafeRawPointer?).self)(c)
                        p = cstr(raw) ?? "—"
                    }
                    if p == "—", let cp = copyPathFn {
                        let raw = unsafeBitCast(cp, to: (@convention(c) (UnsafeMutableRawPointer?) -> UnsafeRawPointer?).self)(c)
                        p = cstr(raw) ?? "—"
                    }
                    let isData = (p != "—") && SandboxBridge.isDataContainer(p)
                    if p == "—" {
                        put("· 类别 \(cls)：命中 · 路径读不到")
                    } else {
                        put("· 类别 \(cls)：命中 · \(p)\(isData ? "（数据容器·Paks 在这里面）" : "（非数据容器·Paks 不在这里）")")
                    }
                    if r.mcmPath == nil, p != "—", isData { r.mcmPath = p }
                    if isData { hitContainer = true }
                } else {
                    put("· 类别 \(cls)：空 · \(errCode)")
                }
            }
        } else {
            put("· 接口取不到，跳过逐个问")
        }
        put("")

        // ⑤ 走 App 清单服务问路径（不需要容器权限，但拿到了也未必能读）
        put("── ⑤ 走 App 清单服务问容器路径（LSApplicationProxy）──")
        let proxyPath = lsProxyContainerPath(bundleId)
        if let p = proxyPath {
            r.proxyPath = p
            put("· 路径：\(p)")
            let fm = FileManager.default
            let exists = fm.fileExists(atPath: p)
            let listable = (try? fm.contentsOfDirectory(atPath: p)) != nil
            put("· 目录存在：\(exists ? "是" : "否") · 列得出来：\(listable ? "是" : "否")")
            let sub = p + "/Documents/ShadowTrackerExtra"
            put("· 游戏数据目录存在：\(fm.fileExists(atPath: sub) ? "是" : "否")")
        } else {
            put("· 这个接口没给路径（可能没这个 App，或系统不放行）")
        }
        put("")

        // ⑤b 核对 bundle id：机器上装着的同类 App 有哪些
        put("── ⑤b 机器上装着的同类 App（核对 bundle id 对不对）──")
        let cands = installedCandidates()
        if cands.isEmpty {
            put("· 列不出来（这个接口也要权限，正常）")
        } else {
            for b in cands.prefix(20) {
                put("· " + b + (b == bundleId ? "  ← 就是要找的这个" : ""))
            }
            if !cands.contains(bundleId) {
                put("· 注意：上面没有 \(bundleId)，说明这台机器上装的可能是别的版本/别的包名")
            }
        }
        put("")

        // ⑥ 直接摸文件系统，记 errno
        put("── ⑥ 直接摸目录（带系统错误码）──")
        let probes = ["/var/mobile/Containers/Data/Application",
                      "/private/var/mobile/Containers/Data/Application",
                      "/var/containers/Bundle/Application",
                      "/private/var/containers/Bundle/Application",
                      "/var/mobile/Library/MobileContainerManager",
                      "/var/mobile"]
        for p in probes {
            let (e, n) = listErrno(p)
            var state = "能列，\(n) 项"
            if e != 0 { state = "列不了（" + errnoText(e) + "）" }
            put("· \(p)：" + state)
        }
        put("")

        // ⑥b 直接按元数据找数据容器（有权限时这条路一定通，也不受容器类别影响）
        put("── ⑥b 直接按元数据找 \(bundleId) 的数据容器 ──")
        let fm2 = FileManager.default
        if let list = try? fm2.contentsOfDirectory(atPath: LSPaths.containerRoot) {
            var metaReadable = 0
            for d in list.prefix(400) {
                let meta = LSPaths.containerRoot + "/" + d + "/.com.apple.mobile_container_manager.metadata.plist"
                if fm2.contents(atPath: meta) != nil { metaReadable += 1 }
            }
            put("· 数据容器根可列：\(list.count) 个 · 其中元数据能读：\(metaReadable) 个")
        } else {
            put("· 数据容器根列不出来（沙盒拒绝，普通签名就是这样）")
        }
        if let found = LSPaths.scanGameContainer() {
            put("· 精确命中：\(found)")
        } else {
            put("· 没找到这个 App 的数据容器")
        }
        put("")

        // ⑦ 写权限测试（只在自己沙盒里做个对照，不动别人目录）
        put("── ⑦ 写权限对照 ──")
        let own = LSPaths.docDir()
        let testName = "._probe_write_test"
        let testURL = own.appendingPathComponent(testName)
        do {
            try Data([0x31]).write(to: testURL)
            try? FileManager.default.removeItem(at: testURL)
            put("· 自己的沙盒：可写（对照正常）")
        } catch {
            put("· 自己的沙盒：写不了（\(LSPaths.describe(error))）")
        }
        if let p = r.proxyPath {
            put("· 游戏数据目录可读：\(canRead(p + "/Documents") ? "是" : "否") · 可写：\(canWrite(p + "/Documents") ? "是" : "否")")
        }
        put("")

        // ⑧ 结论
        r.verdict = decide(ents: ents, missing: missing, hitContainer: hitContainer, service: ch != nil, proxy: r.proxyPath)
        r.headline = headlineText(r.verdict)
        r.advice = adviceText(r.verdict)
        r.containerPath = r.mcmPath ?? r.proxyPath

        put("── 结论 ──")
        put(r.verdict.rawValue)
        put(r.headline)
        if !r.advice.isEmpty { put(r.advice) }

        r.text = lines.joined(separator: "\n")
        return r
    }

    // MARK: - 结论判定

    private func decide(ents: [String: String], missing: [String], hitContainer: Bool, service: Bool, proxy: String?) -> ProbeVerdict {
        if hitContainer { return .containerAccessGranted }
        if !service { return .serviceUnavailable }
        // 容器接口在，但一个类别都问不出来：最常见就是签名没带权限
        if !missing.isEmpty { return .signatureLacksPrivilege }
        if proxy == nil { return .gameNotFound }
        let readable = canRead(proxy! + "/Documents")
        let writable = canWrite(proxy! + "/Documents")
        if readable && !writable { return .readOnly }
        if readable && writable { return .containerAccessGranted }
        return .signatureLacksPrivilege
    }

    private func canRead(_ path: String) -> Bool {
        return path.withCString { access($0, R_OK) == 0 }
    }

    private func canWrite(_ path: String) -> Bool {
        return path.withCString { access($0, W_OK) == 0 }
    }

    private func headlineText(_ v: ProbeVerdict) -> String {
        switch v {
        case .containerAccessGranted:
            return "这台机器放行了容器访问，能直接读写游戏目录。"
        case .signatureLacksPrivilege:
            return "系统和接口都在，是签名没带「容器管理」权限——普通证书签出来的 App 都这样，系统不会给，也骗不过去。"
        case .serviceUnavailable:
            return "这个系统上没有容器查询接口，这条路走不通。"
        case .gameNotFound:
            return "系统里查不到这个 App，先确认游戏装在这台机器上。"
        case .readOnly:
            return "路径拿到了、能读，但写不进去（系统只给了只读）。"
        case .unknown:
            return "还没定位清楚，看上面逐项结果。"
        }
    }

    private func adviceText(_ v: ProbeVerdict) -> String {
        switch v {
        case .containerAccessGranted:
            return "直接点「一键打通游戏目录」就能用。"
        case .signatureLacksPrivilege, .serviceUnavailable, .readOnly:
            return "这条纯沙盒路线在普通签名的机器上到这就到底了：要真写进游戏目录，只能靠内核级权限（越狱环境 / 带内核通道的工具），没有别的绕法。"
        case .gameNotFound:
            return "装上游戏、进一次大厅，再点一次。"
        case .unknown:
            return "把「通道探测.txt」和「通道诊断.txt」一起发我。"
        }
    }

    // MARK: - 工具

    private func openLib(_ paths: [String]) -> UnsafeMutableRawPointer? {
        for p in paths {
            if let h = dlopen(p, RTLD_NOW) { return h }
        }
        return nil
    }

    private func symFn(_ h: UnsafeMutableRawPointer, _ name: String) -> UnsafeMutableRawPointer? {
        return dlsym(h, name)
    }

    private func cstr(_ raw: UnsafeRawPointer?, limit: Int = 4096) -> String? {
        return SandboxBridge.cString(raw, limit: limit)
    }

    /// 容器的错误对象转成人看得懂的码
    private func describeContainerError(_ err: UnsafeRawPointer) -> String {
        guard let h = dlopen("/usr/lib/system/libsystem_containermanager.dylib", RTLD_NOW) else { return "有错误对象" }
        if let p = dlsym(h, "container_error_get_posix_errno") {
            let fn = unsafeBitCast(p, to: (@convention(c) (UnsafeRawPointer?) -> Int32).self)
            let e = fn(err)
            return "posix \(e)（\(errnoText(e))）"
        }
        if let p = dlsym(h, "container_error_copy_description") {
            let fn = unsafeBitCast(p, to: (@convention(c) (UnsafeRawPointer?) -> UnsafeRawPointer?).self)
            if let s = cstr(fn(err)) { return s }
        }
        return "有错误对象（取不到码）"
    }

    /// 列目录并拿 errno
    private func listErrno(_ path: String) -> (Int32, Int) {
        errno = 0
        let d = path.withCString { opendir($0) }
        guard let dir = d else { return (errno == 0 ? EACCES : errno, 0) }
        var n = 0
        while readdir(dir) != nil { n += 1 }
        closedir(dir)
        return (0, max(0, n - 2))
    }

    private func errnoText(_ e: Int32) -> String {
        switch e {
        case 0: return "无错误"
        case 1: return "EPERM 系统不让（沙盒拒绝）"
        case 2: return "ENOENT 路径不存在"
        case 13: return "EACCES 权限不足"
        default: return "errno \(e)"
        }
    }

    /// 读自己进程的签名权限（只读自己的，不碰系统）
    private func selfEntitlements() -> [String: String] {
        var out: [String: String] = [:]
        guard let h = dlopen("/System/Library/Frameworks/Security.framework/Security", RTLD_NOW),
              let createP = dlsym(h, "SecTaskCreateFromSelf"),
              let copyP = dlsym(h, "SecTaskCopyValueForEntitlement") else {
            return out
        }
        typealias Create = @convention(c) (CFAllocator?) -> UnsafeMutableRawPointer?
        typealias Copy = @convention(c) (UnsafeMutableRawPointer?, CFString?, UnsafeMutablePointer<Unmanaged<CFError>?>?) -> Unmanaged<CFTypeRef>?
        let create = unsafeBitCast(createP, to: Create.self)
        let copy = unsafeBitCast(copyP, to: Copy.self)
        guard let task = create(kCFAllocatorDefault) else { return out }

        // ① 先整表拿一次（能拿到就一次看全）
        if let all = copy(task, "com.apple.entitlements.all" as CFString, nil)?.takeRetainedValue(),
           let dict = all as? NSDictionary {
            for (k, v) in dict {
                guard let key = k as? String else { continue }
                if let b = v as? Bool {
                    out[key] = b ? "true" : "false"
                } else {
                    out[key] = "\(v)"
                }
            }
            if !out.isEmpty { return out }
        }

        // ② 逐个问关键权限
        var keys = privilegeKeys
        keys.append("application-identifier")
        keys.append("get-task-allow")
        for k in keys {
            guard let v = copy(task, k as CFString, nil)?.takeRetainedValue() else { continue }
            if let b = v as? Bool {
                out[k] = b ? "true" : "false"
            } else {
                out[k] = "\(v)"
            }
        }
        return out
    }

    /// 列出机器上装着的同类 App 的 bundle id（只读，列不出来就算了）
    private func installedCandidates() -> [String] {
        _ = openLib(["/System/Library/Frameworks/MobileCoreServices.framework/MobileCoreServices",
                     "/usr/lib/libls.dylib"])
        guard let cls = NSClassFromString("LSApplicationWorkspace") else { return [] }
        let clsObj = cls as AnyObject
        let wsSel = NSSelectorFromString("defaultWorkspace")
        guard clsObj.responds(to: wsSel),
              let wsAny = clsObj.perform(wsSel)?.takeUnretainedValue() else { return [] }
        let ws = wsAny as AnyObject

        let listSel = NSSelectorFromString("allInstalledApplications")
        guard ws.responds(to: listSel),
              let listAny = ws.perform(listSel)?.takeUnretainedValue(),
              let list = listAny as? [AnyObject] else { return [] }

        let bidSel = NSSelectorFromString("bundleIdentifier")
        var out: [String] = []
        for app in list.prefix(3000) {
            guard app.responds(to: bidSel),
                  let bid = app.perform(bidSel)?.takeUnretainedValue() as? String else { continue }
            let low = bid.lowercased()
            if low.contains("pubg") || low.contains("tmgp") || low.contains("tencent") || low.contains("pjdz") {
                out.append(bid)
            }
        }
        return Array(Set(out)).sorted()
    }

    /// 走 App 清单服务问路径（不依赖容器权限）
    private func lsProxyContainerPath(_ bundleId: String) -> String? {        _ = openLib(["/System/Library/Frameworks/MobileCoreServices.framework/MobileCoreServices",
                     "/usr/lib/libls.dylib",
                     "/System/Library/PrivateFrameworks/MobileCoreServices.framework/MobileCoreServices"])

        guard let cls = NSClassFromString("LSApplicationProxy") else { return nil }
        let makeSel = NSSelectorFromString("applicationProxyForIdentifier:")
        let clsObj = cls as AnyObject
        guard clsObj.responds(to: makeSel) else { return nil }
        guard let made = clsObj.perform(makeSel, with: bundleId)?.takeUnretainedValue() else { return nil }

        let proxy = made as AnyObject
        for key in ["dataContainerURL", "containerURL", "dataContainerPath"] {
            let sel = NSSelectorFromString(key)
            guard proxy.responds(to: sel), let v = proxy.perform(sel)?.takeUnretainedValue() else { continue }
            if let u = v as? URL, !u.path.isEmpty { return u.path }
            if let s = v as? String, !s.isEmpty { return s }
        }
        return nil
    }
}
