//
//  MCMPeek.h
//  容器租约：让系统的容器服务主动给一份可读写的访问权。
//
//  和 3105 用同一条通道，区别只在封装方式（它 Swift 直调，这里 ObjC 直调）。
//  全程只读探测 + 接收系统主动给的权限：不写内核、不改系统文件、不提权。
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

/// 走 MCMRetainedLease 拿租约。返回数据容器路径（能列出内容才算成功），失败返回 nil。
/// notes 里逐条写清每一步的结果，界面和报告直接用它。
NSString * _Nullable LSMCMLeaseOpen(NSString *bundleId, NSMutableArray<NSString *> *notes);

/// 走 MCMAppContainer 直取容器对象。部分系统上它比租约宽松。
NSString * _Nullable LSMCMAppContainerOpen(NSString *bundleId, NSMutableArray<NSString *> *notes);

NS_ASSUME_NONNULL_END
