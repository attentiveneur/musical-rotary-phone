//
//  MCMPeek.m
//  容器租约的 ObjC 实现。
//
//  为什么单独用 ObjC：
//    这条通道全靠对私有类发消息（MCMRetainedLease / MCMAppContainer）。
//    ObjC 的 runtime 调用是原生的，不用在 Swift 里绕 C 函数指针，
//    签名对不上也不会在编译期就挂。
//
//  这个文件按 -fno-objc-arc 编译（project.yml 里单独给的编译开关），
//  所以对象持有／释放全部手写，别在这里加 ARC 才有的写法。
//

#import "MCMPeek.h"
#import <objc/runtime.h>
#import <objc/message.h>
#import <dlfcn.h>

// 租约对象一释放，它给的那份访问权当场就没了，所以必须一直持有。
static NSMutableArray *gHeld = nil;

static void LSHold(id obj) {
    if (!obj) return;
    if (!gHeld) gHeld = [[NSMutableArray alloc] init];
    [gHeld addObject:obj];
}

static void LSLoadFramework(void) {
    static dispatch_once_t once;
    dispatch_once(&once, ^{
        dlopen("/System/Library/PrivateFrameworks/MobileContainerManager.framework/MobileContainerManager", RTLD_NOW);
        dlopen("/usr/lib/system/libsystem_containermanager.dylib", RTLD_NOW);
    });
}

/// 私有类返回的可能是 NSString 也可能直接是 NSURL，统一成路径字符串
static NSString *LSPathOf(id obj) {
    if (!obj) return nil;
    if ([obj isKindOfClass:[NSString class]]) return (NSString *)obj;
    if ([obj isKindOfClass:[NSURL class]]) return [(NSURL *)obj path];
    return nil;
}

/// 只认数据容器：/var/mobile/Containers/Data/Application/<uuid>
/// 安装包容器（/var/containers/Bundle/Application/...）里没有 Paks。
static BOOL LSIsDataContainer(NSString *p) {
    if (p.length == 0) return NO;
    NSString *q = p;
    if ([q hasPrefix:@"/private/"]) q = [q substringFromIndex:8];
    return [q containsString:@"/Containers/Data/Application/"];
}

/// 「列得出来」才算真通——能拿到路径不等于能读
static BOOL LSListable(NSString *p) {
    if (p.length == 0) return NO;
    return [[NSFileManager defaultManager] contentsOfDirectoryAtPath:p error:NULL] != nil;
}

NSString * _Nullable LSMCMLeaseOpen(NSString *bundleId, NSMutableArray<NSString *> *notes) {
    LSLoadFramework();

    Class cls = NSClassFromString(@"MCMRetainedLease");
    if (!cls) {
        [notes addObject:@"租约：这台机器上没有 MCMRetainedLease 这个类"];
        return nil;
    }
    SEL leaseSel = NSSelectorFromString(@"leaseForClass:identifier:group:error:");
    Method meta = class_getClassMethod(cls, leaseSel);
    if (!meta) {
        [notes addObject:@"租约：MCMRetainedLease 上没有 leaseForClass:identifier:group:error:"];
        return nil;
    }

    typedef id (*LeaseFn)(id, SEL, unsigned long long, NSString *, NSString *, NSError **);
    LeaseFn leaseFn = (LeaseFn)method_getImplementation(meta);

    SEL actSel  = NSSelectorFromString(@"activate:");
    SEL rootSel = NSSelectorFromString(@"rootPath");
    SEL onSel   = NSSelectorFromString(@"activated");

    // 容器类别：2 是 App 数据容器（Paks 在这里面），1 是安装包。
    // 不同系统上编号可能不一致，所以按「最可能」的顺序全试一遍，谁开出数据目录谁算数。
    unsigned long long classes[6] = {2, 3, 4, 1, 5, 6};

    for (int i = 0; i < 6; i++) {
        unsigned long long cv = classes[i];
        NSError *err = nil;
        id lease = leaseFn((id)cls, leaseSel, cv, bundleId, nil, &err);
        if (!lease) {
            [notes addObject:[NSString stringWithFormat:@"租约·类别 %llu：拿不到（%@）",
                              cv, err.localizedDescription ?: @"没给错误对象"]];
            continue;
        }
        LSHold(lease);
        [notes addObject:[NSString stringWithFormat:@"租约·类别 %llu：对象已拿到", cv]];

        Method am = class_getInstanceMethod(cls, actSel);
        if (am) {
            typedef BOOL (*ActFn)(id, SEL, NSError **);
            NSError *aerr = nil;
            BOOL ok = ((ActFn)method_getImplementation(am))(lease, actSel, &aerr);
            NSString *why = aerr.localizedDescription;
            [notes addObject:[NSString stringWithFormat:@"租约·类别 %llu：激活%@%@",
                              cv, ok ? @"成功" : @"失败",
                              why.length ? [NSString stringWithFormat:@"（%@）", why] : @""]];
        } else {
            [notes addObject:[NSString stringWithFormat:@"租约·类别 %llu：没有 activate:，直接读路径", cv]];
        }

        NSString *root = nil;
        Method rm = class_getInstanceMethod(cls, rootSel);
        if (rm) {
            typedef id (*ObjFn)(id, SEL);
            root = LSPathOf(((ObjFn)method_getImplementation(rm))(lease, rootSel));
        }
        [notes addObject:[NSString stringWithFormat:@"租约·类别 %llu：%@",
                          cv, root.length ? [NSString stringWithFormat:@"路径 %@", root] : @"没读到路径"]];

        if (LSIsDataContainer(root)) {
            BOOL ok = LSListable(root);
            [notes addObject:[NSString stringWithFormat:@"租约·类别 %llu：目录%@",
                              cv, ok ? @"列得出来 ✅" : @"列不出来 ❌"]];
            if (ok) return root;
        }

        Method om = class_getInstanceMethod(cls, onSel);
        if (om) {
            typedef BOOL (*BoolFn)(id, SEL);
            BOOL on = ((BoolFn)method_getImplementation(om))(lease, onSel);
            [notes addObject:[NSString stringWithFormat:@"租约·类别 %llu：activated=%@",
                              cv, on ? @"是" : @"否"]];
        }
    }

    return nil;
}

NSString * _Nullable LSMCMAppContainerOpen(NSString *bundleId, NSMutableArray<NSString *> *notes) {
    LSLoadFramework();

    Class cls = NSClassFromString(@"MCMAppContainer");
    if (!cls) {
        [notes addObject:@"容器类：这台机器上没有 MCMAppContainer"];
        return nil;
    }
    SEL sel = NSSelectorFromString(@"containerWithIdentifier:createIfNecessary:existed:error:");
    Method meta = class_getClassMethod(cls, sel);
    if (!meta) {
        [notes addObject:@"容器类：MCMAppContainer 上没有 containerWithIdentifier:createIfNecessary:existed:error:"];
        return nil;
    }

    typedef id (*MakeFn)(id, SEL, NSString *, BOOL, BOOL *, NSError **);
    NSError *err = nil;
    id container = ((MakeFn)method_getImplementation(meta))((id)cls, sel, bundleId, NO, NULL, &err);
    if (!container) {
        [notes addObject:[NSString stringWithFormat:@"容器类：拿不到（%@）",
                          err.localizedDescription ?: @"没给错误对象"]];
        return nil;
    }
    LSHold(container);
    [notes addObject:@"容器类：对象已拿到"];

    // 不同系统上暴露的属性名不一样，逐个试，拿到路径就验能不能列
    NSArray *props = @[@"url", @"dataContainerURL", @"containerURL", @"urlNoSandbox", @"containerPath"];
    for (NSString *name in props) {
        SEL s = NSSelectorFromString(name);
        Method m = class_getInstanceMethod(cls, s);
        if (!m) continue;
        typedef id (*ObjFn)(id, SEL);
        NSString *p = LSPathOf(((ObjFn)method_getImplementation(m))(container, s));
        if (p.length == 0) continue;
        [notes addObject:[NSString stringWithFormat:@"容器类.%@：%@", name, p]];
        if (LSIsDataContainer(p) && LSListable(p)) return p;
    }

    return nil;
}
