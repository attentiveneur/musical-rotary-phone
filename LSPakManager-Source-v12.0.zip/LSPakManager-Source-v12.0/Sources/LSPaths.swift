import Foundation
import Darwin

enum LSPaths {
    static let bundleId = "com.tencent.tmgp.pubgmhd"
    static let containerRoot = "/var/mobile/Containers/Data/Application"
    static let extSet: Set<String> = ["pak", "sig", "utoc", "ucas"]

    /// 游戏里 pak 可能出现的几个位置，按优先级找
    static let pakSubPaths: [String] = [
        "/Documents/ShadowTrackerExtra/Saved/Paks",
        "/Documents/ShadowTrackerExtra/Saved/Paks/Paks",
        "/Documents/ShadowTrackerExtra/Saved/Paks/pak",
        "/Library/Caches/ShadowTrackerExtra/Saved/Paks"
    ]

    // MARK: - App 自己的沙盒

    static func docDir() -> URL {
        FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)[0]
    }

    static func backupRoot() -> URL {
        docDir().appendingPathComponent("Backups", isDirectory: true)
    }

    /// 改好的包放这里，方便从「文件」App 或别的工具拖走
    static func fixedDir() -> URL {
        docDir().appendingPathComponent("改好的", isDirectory: true)
    }

    /// 要把文件导进游戏，先把包丢这里
    static func dropDir() -> URL {
        docDir().appendingPathComponent("待导入", isDirectory: true)
    }

    /// 导成功的源文件挪到这里，避免下次重复导
    static func importedDir() -> URL {
        docDir().appendingPathComponent("已导入", isDirectory: true)
    }

    /// 素材库：从手机里选进来的包，永久存这一份，谁也不挪、谁也不删。
    /// 游戏里那份删多少次，这里都还在，随时一键再导回去，不用再碰「文件」App。
    static func vaultDir() -> URL {
        docDir().appendingPathComponent("素材库", isDirectory: true)
    }

    /// 从游戏里导出来的包放这里
    static func exportDir() -> URL {
        docDir().appendingPathComponent("导出的", isDirectory: true)
    }

    static func ensureDirs() {
        let fm = FileManager.default
        for u in [backupRoot(), fixedDir(), dropDir(), importedDir(), exportDir(), vaultDir()] {
            if !fm.fileExists(atPath: u.path) {
                try? fm.createDirectory(at: u, withIntermediateDirectories: true)
            }
        }
    }

    // MARK: - 定位游戏容器

    static func canListContainer() -> Bool {
        let fm = FileManager.default
        if let list = try? fm.contentsOfDirectory(atPath: containerRoot), !list.isEmpty {
            return true
        }
        return false
    }

    /// 定位游戏容器：先看通道层拿到的路径（v8.7 主路），没有再退回自己扫目录
    static func gameContainer() -> String? {
        if let cached = SandboxBridge.shared.cachedPath,
           FileManager.default.fileExists(atPath: cached) {
            return cached
        }
        return scanGameContainer()
    }

    /// 只扫 /var/mobile/Containers/Data/Application（直连环境 / 已被赋予权限时有效）
    static func scanGameContainer() -> String? {
        let fm = FileManager.default
        guard let list = try? fm.contentsOfDirectory(atPath: containerRoot) else { return nil }

        // 1) 元数据精确匹配
        for d in list where !d.hasPrefix(".") {
            let base = containerRoot + "/" + d
            let meta = base + "/.com.apple.mobile_container_manager.metadata.plist"
            if let data = fm.contents(atPath: meta),
               let obj = try? PropertyListSerialization.propertyList(from: data, options: [], format: nil),
               let dict = obj as? [String: Any],
               let ident = dict["MCMMetadataIdentifier"] as? String,
               ident == bundleId {
                return base
            }
        }

        // 2) 目录特征兜底
        for d in list where !d.hasPrefix(".") {
            let base = containerRoot + "/" + d
            if fm.fileExists(atPath: base + "/Documents/ShadowTrackerExtra") {
                return base
            }
        }
        return nil
    }

    /// 找到真正放 pak 的那个目录
    static func paksDir(container: String) -> String? {
        let fm = FileManager.default
        for sub in pakSubPaths {
            let p = container + sub
            var isDir: ObjCBool = false
            if fm.fileExists(atPath: p, isDirectory: &isDir), isDir.boolValue {
                return p
            }
        }
        // 兜底：在 ShadowTrackerExtra 里按名字找 Paks（有界扫描，不会死等）
        let saved = container + "/Documents/ShadowTrackerExtra"
        var isDir: ObjCBool = false
        if fm.fileExists(atPath: saved, isDirectory: &isDir), isDir.boolValue {
            return searchPaksDir(under: saved, depth: 5, maxNodes: 1500)
        }
        return nil
    }

    // MARK: - v9.0 证据工具（只读，全部把结果写成一句话）

    /// errno 说成人话，写进哨兵一眼能看懂
    static func errnoName(_ e: Int32) -> String {
        switch e {
        case 0:   return "OK"
        case 1:   return "EPERM(1·系统拒绝)"
        case 2:   return "ENOENT(2·不存在)"
        case 13:  return "EACCES(13·没权限)"
        case 20:  return "ENOTDIR(20·不是目录)"
        case 30:  return "EROFS(30·只读)"
        default:  return "errno(\(e))"
        }
    }

    /// 一个目录现在什么状态：能列、不存在、还是被拒（用 POSIX 取准确的 errno）
    static func dirState(_ path: String) -> String {
        errno = 0
        guard let d = opendir(path) else {
            let e = errno
            if e == 0 || e == ENOENT { return "可列=否 不存在" }
            return "可列=否 \(errnoName(e))"
        }
        var n = 0
        while readdir(d) != nil { n += 1 }
        closedir(d)
        return "可列=是 项=\(max(0, n - 2))"
    }

    /// 往下一层层找 Paks：先认名字，再认里面有没有 .pak
    /// 有界扫描：只走 depth 层、最多看 maxNodes 个目录，绝不无限递归
    static func searchPaksDir(under root: String, depth: Int = 4, maxNodes: Int = 1200) -> String? {
        let fm = FileManager.default
        var queue: [(String, Int)] = [(root, 0)]
        var visited = 0
        while !queue.isEmpty {
            let (path, level) = queue.removeFirst()
            visited += 1
            if visited > maxNodes { return nil }
            guard let names = try? fm.contentsOfDirectory(atPath: path) else { continue }
            for n in names where !n.hasPrefix(".") {
                let full = path + "/" + n
                var isDir: ObjCBool = false
                guard fm.fileExists(atPath: full, isDirectory: &isDir), isDir.boolValue else { continue }
                if n.lowercased() == "paks" {
                    if hasPakFile(full) { return full }
                    if level < depth { queue.append((full, level + 1)) }
                    continue
                }
                if level < depth { queue.append((full, level + 1)) }
            }
        }
        return nil
    }

    /// 这个目录（只看一层）里有没有 .pak
    static func hasPakFile(_ dir: String) -> Bool {
        guard let names = try? FileManager.default.contentsOfDirectory(atPath: dir) else { return false }
        for n in names where n.lowercased().hasSuffix(".pak") { return true }
        return false
    }

    /// 全盘找一个游戏资源目录：数据容器 → 安装包容器 → 共享容器
    /// 返回 (路径, 来源)。三层都有界，扫不完也不会卡死。
    static func searchPaksGlobal() -> (String, String)? {
        let roots: [(String, String)] = [
            ("/var/mobile/Containers/Data/Application", "数据容器"),
            ("/var/containers/Bundle/Application", "安装包容器"),
            ("/var/mobile/Containers/Shared/AppGroup", "共享容器")
        ]
        let fm = FileManager.default
        for (root, name) in roots {
            guard let subs = try? fm.contentsOfDirectory(atPath: root) else { continue }
            var looked = 0
            for s in subs where !s.hasPrefix(".") {
                looked += 1
                if looked > 160 { break }
                let base = root + "/" + s
                if let p = searchPaksDir(under: base, depth: 5, maxNodes: 500) {
                    return (p, name)
                }
            }
        }
        return nil
    }

    /// 这台机器上装了什么游戏类 App（核对 bundle id 用，写进哨兵）
    static func gameBundleIds(limit: Int = 12) -> [(String, String)] {
        let fm = FileManager.default
        var out: [(String, String)] = []
        guard let subs = try? fm.contentsOfDirectory(atPath: containerRoot) else { return out }
        for s in subs where !s.hasPrefix(".") {
            if out.count >= limit { break }
            let base = containerRoot + "/" + s
            let meta = base + "/.com.apple.mobile_container_manager.metadata.plist"
            guard let data = fm.contents(atPath: meta),
                  let obj = try? PropertyListSerialization.propertyList(from: data, options: [], format: nil),
                  let dict = obj as? [String: Any],
                  let ident = dict["MCMMetadataIdentifier"] as? String else { continue }
            let low = ident.lowercased()
            if low.contains("tencent") || low.contains("pubg") || low.contains("tmgp") || low.contains("game") {
                out.append((ident, base))
            }
        }
        return out
    }

    // MARK: - 列文件

    static func listFiles(in dir: String, exts: Set<String>? = nil, depth: Int = 1) -> [PakItem] {
        let fm = FileManager.default
        let set = exts ?? extSet
        var out: [PakItem] = []
        var seen = Set<String>()

        func walk(_ path: String, _ d: Int) {
            guard let names = try? fm.contentsOfDirectory(atPath: path) else { return }
            for n in names where !n.hasPrefix(".") {
                let full = path + "/" + n
                var isDir: ObjCBool = false
                guard fm.fileExists(atPath: full, isDirectory: &isDir) else { continue }
                if isDir.boolValue {
                    if d < depth { walk(full, d + 1) }
                } else if set.contains((n as NSString).pathExtension.lowercased()) {
                    if seen.contains(full) { continue }
                    seen.insert(full)
                    let attrs = try? fm.attributesOfItem(atPath: full)
                    let size = (attrs?[.size] as? NSNumber)?.int64Value ?? 0
                    out.append(PakItem(id: full, url: URL(fileURLWithPath: full), size: size))
                }
            }
        }
        walk(dir, 0)
        return out.sorted { $0.name < $1.name }
    }

    static func listGamePaks(container: String) -> [PakItem] {
        guard let dir = paksDir(container: container) else { return [] }
        return listFiles(in: dir, exts: ["pak"], depth: 1)
    }

    /// 深扫一个目录，把里面所有 pak / sig 都翻出来（「全盘找 pak」用）
    static func scanDeep(_ root: String, depth: Int = 8, limit: Int = 3000) -> [PakItem] {
        let fm = FileManager.default
        var out: [PakItem] = []
        var hits = 0

        func walk(_ path: String, _ level: Int) {
            if hits >= limit { return }
            guard let names = try? fm.contentsOfDirectory(atPath: path) else { return }
            for n in names where !n.hasPrefix(".") {
                if hits >= limit { return }
                let full = path + "/" + n
                var isDir: ObjCBool = false
                guard fm.fileExists(atPath: full, isDirectory: &isDir) else { continue }
                if isDir.boolValue {
                    if level < depth { walk(full, level + 1) }
                } else if extSet.contains((n as NSString).pathExtension.lowercased()) {
                    hits += 1
                    let attrs = try? fm.attributesOfItem(atPath: full)
                    let size = (attrs?[.size] as? NSNumber)?.int64Value ?? 0
                    out.append(PakItem(id: full, url: URL(fileURLWithPath: full), size: size))
                }
            }
        }

        walk(root, 0)
        return out
    }

    /// App 沙盒里能被改的包（Documents 根 + 子目录一层）
    static func listLocalPaks() -> [PakItem] {
        let items = listFiles(in: docDir().path, exts: ["pak"], depth: 2)
        return items.filter { !$0.id.contains("/Backups/") && !$0.id.contains("/改好的/") }
    }

    /// 待导入 = 素材库。选一次文件就永久存这儿，反复导入/删除都从这儿取
    static func listImportSources() -> [PakItem] {
        let fm = FileManager.default
        let dir = vaultDir()
        guard let names = try? fm.contentsOfDirectory(atPath: dir.path) else { return [] }
        var out: [PakItem] = []
        for n in names where !n.hasPrefix(".") {
            let full = dir.path + "/" + n
            var isDir: ObjCBool = false
            guard fm.fileExists(atPath: full, isDirectory: &isDir), !isDir.boolValue else { continue }
            guard extSet.contains((n as NSString).pathExtension.lowercased()) else { continue }
            let attrs = try? fm.attributesOfItem(atPath: full)
            let size = (attrs?[.size] as? NSNumber)?.int64Value ?? 0
            out.append(PakItem(id: full, url: URL(fileURLWithPath: full), size: size))
        }
        return out.sorted { $0.name < $1.name }
    }

    /// 素材库里找同名的那个文件
    static func vaultURL(for name: String) -> URL? {
        let u = vaultDir().appendingPathComponent(name)
        return FileManager.default.fileExists(atPath: u.path) ? u : nil
    }

    /// 素材库占了多少空间
    static func vaultSize() -> Int64 {
        listImportSources().reduce(0) { $0 + $1.size }
    }

    /// 删文件时扫的范围：整个 ShadowTrackerExtra（没有就退回 Paks 目录）
    static func deleteScanRoot(container: String?) -> String? {
        guard let container = container else { return nil }
        let base = container + "/Documents/ShadowTrackerExtra"
        var isDir: ObjCBool = false
        if FileManager.default.fileExists(atPath: base, isDirectory: &isDir), isDir.boolValue {
            return base
        }
        return paksDir(container: container)
    }

    // MARK: - 备份 / 还原

    struct BackupSet: Identifiable, Hashable {
        var id: String { stamp }
        let stamp: String
        let dir: URL
        let files: [String]
    }

    static func backupList() -> [BackupSet] {
        let fm = FileManager.default
        let root = backupRoot()
        guard let names = try? fm.contentsOfDirectory(atPath: root.path) else { return [] }
        var out: [BackupSet] = []
        for n in names.sorted(by: >) {
            let d = root.appendingPathComponent(n)
            var isDir: ObjCBool = false
            guard fm.fileExists(atPath: d.path, isDirectory: &isDir), isDir.boolValue else { continue }
            let files = (try? fm.contentsOfDirectory(atPath: d.path)) ?? []
            out.append(BackupSet(stamp: n, dir: d, files: files))
        }
        return out
    }

    static func describe(_ error: Error) -> String {
        let ns = error as NSError
        var s = "\(ns.localizedDescription) (errno \(ns.code))"
        if ns.domain == NSPOSIXErrorDomain {
            switch ns.code {
            case 1: s += " = Operation not permitted（权限被系统拒绝）"
            case 2: s += " = No such file or directory"
            case 13: s += " = Permission denied（沙盒/签名权限不足）"
            case 28: s += " = No space left on device（空间不足）"
            default: break
            }
        }
        return s
    }

    static func freeSpaceText() -> String {
        let url = docDir()
        if let v = try? url.resourceValues(forKeys: [.volumeAvailableCapacityForImportantUsageKey]),
           let bytes = v.volumeAvailableCapacityForImportantUsage {
            return Fmt.size(bytes)
        }
        return "未知"
    }
}
