# 第三方组件与许可声明

本文件随 **浪神文件管理器（LSPakManager）** 一起分发。
对外分发（发 IPA、发安装包、放下载页）时，必须和 `LICENSE` 一起附上。

---

## 1. 内核引擎（DarkSword / kexploit）

| 项目 | 内容 |
|---|---|
| 文件 | `Sources/Kernel/kexploit/darksword.{h,m}`、`offsets.*`、`persistence.*`、`ota.*`、`decrypt.*`、`utils.*`、`screentime.*`、`pe/*`、`compat.h` |
| 来源 | rooootdev/lara — https://github.com/rooootdev/lara （作者 ruter） |
| 上游 | TaskRop 部分标注 "Ported from darksword-kexploit-fun"；原始内核利用参考 opa334/darksword-kexploit |
| 许可 | **AGPL-3.0**（以 lara 仓库 LICENSE 为准） |
| 我方改动 | 剥掉了原 App 外壳，改由 Swift 桥接调用（`KernelEngine.swift`），并按本项目流程串联「内核读写 → 取内核 → 解析偏移 → 沙盒逃逸」四步 |

## 2. TaskRop 远程调用

| 项目 | 内容 |
|---|---|
| 文件 | `Sources/Kernel/kexploit/TaskRop/*` |
| 来源 | rooootdev/lara（"Ported from darksword-kexploit-fun"） |
| 许可 | **AGPL-3.0** |

## 3. Mach-O / dyld 解析辅助头文件

| 项目 | 内容 |
|---|---|
| 文件 | `Sources/Kernel/Support/*.h` |
| 来源 | rooootdev/lara 仓库 |
| 特别说明 | `dyld_cache_format.h` 版权归 **Apple Inc.**，按 **Apple Public Source License 2.0 (APSL-2.0)** 使用，原版权头已保留 |
| 许可 | AGPL-3.0（主体）＋ APSL-2.0（Apple 部分） |

## 4. 预编译动态库

| 项目 | 内容 |
|---|---|
| 文件 | `Sources/Libs/libxpf.dylib`、`Sources/Libs/libgrabkernel2.dylib` |
| 形态 | 通用二进制（arm64 + arm64e） |
| 来源 | 随 rooootdev/lara 发布 |
| 许可 | 随 lara 分发，**AGPL-3.0** |

## 5. 本项目原创部分

| 项目 | 内容 |
|---|---|
| 文件 | `Sources/*.swift`（界面、导入、删除、路径扫描、改字引擎、设备闸门） |
| 作者 | 浪神 |
| 许可 | **AGPL-3.0**（与上述 AGPL 代码链接为同一程序，整体同一许可） |

---

## 分发义务（AGPL-3.0 要点，非法律意见）

1. **发二进制就要给源码。** 任何人拿到你的 IPA，你都必须给他完整对应源码（同一页面挂源码包，或给公开仓库地址即可）。
2. **整体同许可。** 你的工程（含界面部分）必须以 AGPL-3.0 授权，不得附加额外限制 —— 例如「禁止转载」「禁止商用」「禁止二次修改」这类条款都与 AGPL 冲突。
3. **保留署名。** 保留原作者版权声明与本许可文本，并说明你改了什么（本文件第 1 节的「我方改动」就是干这个用的）。
4. **网络服务条款（AGPL 第 13 条）。** 本 App 目前不含服务端，不触发。若以后加「云端代签 / 云端改包」这类联网服务，必须在该服务里提供源码获取入口。

## 发布前请再核对一次

- `lara` 的许可证以该仓库**当时的 LICENSE 文件**为准。本文件依据的是 GitHub 上标注的 `AGPL-3.0`。上游若改许可，你要跟着改。
- 上游 `opa334/darksword-kexploit` 仓库未标注许可证，**不要**把它的代码单独当自己的作品再发布；通过 lara 使用时按 lara 的 AGPL 条款走。
- 本项目**不包含、也不分发** `3105` 的任何二进制内容。
