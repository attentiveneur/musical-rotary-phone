import Foundation

/// 导入记录簿：谁被导进游戏了，一条一条记下来
/// 「删除导入的文件」就是照这本账来撤，不靠关键字乱猜
enum ImportLog {

    static func fileURL() -> URL {
        LSPaths.docDir().appendingPathComponent("import_log.json")
    }

    static func load() -> [ImportRecord] {
        let fm = FileManager.default
        let u = fileURL()
        guard fm.fileExists(atPath: u.path) else { return [] }
        guard let data = try? Data(contentsOf: u) else { return [] }
        guard let list = try? JSONDecoder().decode([ImportRecord].self, from: data) else { return [] }
        return list
    }

    @discardableResult
    static func save(_ list: [ImportRecord]) -> Bool {
        var capped = list
        if capped.count > 600 { capped = Array(capped.prefix(600)) }
        guard let data = try? JSONEncoder().encode(capped) else { return false }
        do {
            try data.write(to: fileURL(), options: .atomic)
            return true
        } catch {
            return false
        }
    }

    /// 新导进去一条：同一个目标位置只留最新一条有效记录
    static func add(_ r: ImportRecord) {
        var list = load()
        list.removeAll { $0.gamePath == r.gamePath && !$0.deleted }
        list.insert(r, at: 0)
        save(list)
    }

    static func markDeleted(id: String, hold: String?) {
        var list = load()
        for i in list.indices where list[i].id == id {
            list[i].deleted = true
            list[i].deletedAt = Fmt.shortDate()
            list[i].holdPath = hold
        }
        save(list)
    }

    static func markRestored(id: String) {
        var list = load()
        for i in list.indices where list[i].id == id {
            list[i].deleted = false
            list[i].deletedAt = nil
            list[i].holdPath = nil
        }
        save(list)
    }

    static func remove(id: String) {
        var list = load()
        list.removeAll { $0.id == id }
        save(list)
    }

    /// 清掉「文件已经不在了」的旧记录，别让账越攒越乱
    static func pruneMissing() -> Int {
        let list = load()
        let fm = FileManager.default
        let keep = list.filter { fm.fileExists(atPath: $0.gamePath) || $0.deleted }
        let gone = list.count - keep.count
        if gone > 0 { save(keep) }
        return gone
    }
}
