//
//  KernelEngine.swift
//  一键内核激活：内核读写 → 取本机内核 → 解析偏移 → 沙盒逃逸 → 全盘读写
//

import Foundation
import UIKit
import Darwin
import Combine

private let engineLogCallback: @convention(c) (UnsafePointer<CChar>?) -> Void = { msg in
    guard let msg = msg else { return }
    let s = String(cString: msg)
    DispatchQueue.main.async { KernelEngine.shared.appendLog("· " + s) }
}

private let engineProgressCallback: @convention(c) (Double) -> Void = { p in
    DispatchQueue.main.async { KernelEngine.shared.setProgress(p) }
}

private let engineSbxLogCallback: @convention(c) (UnsafePointer<CChar>?) -> Void = { msg in
    guard let msg = msg else { return }
    let s = String(cString: msg)
    DispatchQueue.main.async { KernelEngine.shared.appendLog("· " + s) }
}

final class KernelEngine: ObservableObject {

    static let shared = KernelEngine()

    enum Phase: Equatable {
        case idle
        case running
        case ready
        case failed
    }

    @Published private(set) var phase: Phase = .idle
    @Published private(set) var stageText: String = "未激活"
    @Published private(set) var detailText: String = "点一下，自动完成内核读写和沙盒逃逸"
    @Published private(set) var progress: Double = 0
    @Published private(set) var logLines: [String] = []
    @Published private(set) var kernelBase: UInt64 = 0
    @Published private(set) var offsetsReady: Bool = false

    private var inFlight = false

    var running: Bool { phase == .running }
    var ready: Bool { phase == .ready }

    var deviceLine: String {
        let d = UIDevice.current
        return "\(d.model) · iOS \(d.systemVersion)"
    }

    // MARK: - 对外动作

    func activate() {
        guard !inFlight else { return }

        // 设备闸门：系统版本不在支持范围就先拦住，不放它去碰内核
        let compat = Compatibility.check()
        if !compat.ok {
            phase = .failed
            progress = 0
            kernelBase = 0
            offsetsReady = false
            stageText = compat.title
            detailText = compat.reason
            logLines.removeAll()
            appendLog("设备：\(Compatibility.deviceSummary())")
            appendLog("已拦截：\(compat.reason)")
            return
        }

        inFlight = true
        phase = .running
        progress = 0
        kernelBase = 0
        offsetsReady = false
        stageText = "正在启动"
        detailText = "别退出 App，全程大概半分钟到两分钟"
        logLines.removeAll()
        appendLog("设备：\(Compatibility.deviceSummary())")

        ds_set_log_callback(engineLogCallback)
        ds_set_progress_callback(engineProgressCallback)
        sbx_setlogcallback(engineSbxLogCallback)

        DispatchQueue.global(qos: .userInitiated).async { [weak self] in
            self?.runPipeline()
        }
    }

    // MARK: - 主流程

    private func runPipeline() {
        // 1. 载入偏移基础值
        offsets_init()

        // 2. 内核读写
        update(stage: "内核读写", detail: "这一步最慢，可能要几十秒")
        let r = ds_run()
        guard r == 0, ds_is_ready() else {
            fail("内核读写没成功", detail: "杀掉 App 重开再点一次；连点几次都不行就是这台机器还没覆盖到")
            return
        }
        kernelBase = ds_get_kernel_base()
        appendLog(String(format: "内核基址：0x%llx", kernelBase))

        // 3. 取本机内核，解析偏移
        update(stage: "读取内核配置", detail: "从本机抓一份，抓不到就联网下载")
        var ok = fetchLocalKernelCache()
        if !ok {
            appendLog("本机那份没抓到，改成联网下载")
            ok = dlkcache()
        }
        offsetsReady = ok
        if !ok {
            fail("内核配置文件没拿到", detail: "检查一下网络，或者换个时间再点")
            return
        }

        // 4. 沙盒逃逸
        update(stage: "沙盒逃逸", detail: "成功后就能读写游戏目录")
        let e = sbx_escape(ds_get_our_proc())
        guard e == 0 else {
            fail("沙盒逃逸没成功", detail: "内核读写是好的，退出 App 重开再点一次")
            return
        }

        DispatchQueue.main.async {
            self.phase = .ready
            self.stageText = "已激活"
            self.detailText = "全盘读写已就位，可以导入和删除游戏文件了"
            self.progress = 1
            self.inFlight = false
            self.appendLog("全部完成：全盘读写已就位")
        }
    }

    // MARK: - 本机内核抓取

    private func fetchLocalKernelCache() -> Bool {
        guard ds_is_ready(),
              ds_get_our_proc() != 0,
              ds_get_our_task() != 0,
              off_proc_p_fd != 0,
              off_filedesc_fd_ofiles != 0,
              off_fileproc_fp_glob != 0,
              off_fileglob_fg_data != 0,
              off_vnode_v_data != 0,
              off_namecache_nc_vp != 0,
              off_namecache_nc_child_tqe_next != 0 else {
            appendLog("偏移还没备齐，走下载那条路")
            return false
        }

        guard let hash = bootManifestHash() else {
            appendLog("没找到本机系统分区标识")
            return false
        }

        let sysPath = "/private/preboot/\(hash)/System/Library/Caches/com.apple.kernelcaches/kernelcache"

        let docs = LSPaths.docDir()
        let outPath = docs.appendingPathComponent("kernelcache").path

        let fakeRead = "/private/preboot/Cryptexes/OS/System/Library/CoreServices/RestoreVersion.plist"

        unlink(outPath)

        var origVnode: UInt64 = 0
        var origData: UInt64 = 0

        let redirected = fakeRead.withCString { fakeC in
            sysPath.withCString { sysC in
                vn_fileredirect(fakeC, sysC, &origVnode, &origData)
            }
        }
        guard redirected else {
            appendLog("重定向没成")
            return false
        }

        let src = open(fakeRead, O_RDONLY)
        guard src >= 0 else {
            _ = vn_fileunredirect(origVnode, origData)
            return false
        }

        let dst = open(outPath, O_WRONLY | O_CREAT | O_TRUNC, 0o644)
        guard dst >= 0 else {
            close(src)
            _ = vn_fileunredirect(origVnode, origData)
            return false
        }

        defer {
            close(src)
            close(dst)
            _ = vn_fileunredirect(origVnode, origData)
        }

        var buffer = [UInt8](repeating: 0, count: 0x4000)
        let bufSize = buffer.count
        var total = 0

        while true {
            let n = buffer.withUnsafeMutableBytes { raw -> Int in
                guard let base = raw.baseAddress else { return -1 }
                return read(src, base, bufSize)
            }
            if n < 0 {
                appendLog("读内核出错了")
                return false
            }
            if n == 0 { break }

            var written = 0
            while written < n {
                let w = buffer.withUnsafeBytes { raw -> Int in
                    guard let base = raw.baseAddress else { return -1 }
                    return write(dst, base.advanced(by: written), n - written)
                }
                if w <= 0 {
                    appendLog("写内核出错了")
                    return false
                }
                written += w
            }
            total += n
        }

        guard total > 0, FileManager.default.fileExists(atPath: outPath) else {
            appendLog("抓出来的文件是空的")
            return false
        }

        // 校验前两字节 0x30 0x84
        if let h = FileHandle(forReadingAtPath: outPath) {
            let magic = h.readData(ofLength: 2)
            h.closeFile()
            if magic.count == 2, magic[0] == 0x30, magic[1] == 0x84 {
                appendLog(String(format: "本机内核抓到了：%.1f MB", Double(total) / 1048576.0))
                return dlkcache()
            }
        }
        unlink(outPath)
        appendLog("抓到的不是内核文件")
        return false
    }

    private func bootManifestHash() -> String? {
        let root = "/private/preboot"
        let fm = FileManager.default
        let pattern = try! NSRegularExpression(pattern: "^[A-Fa-f0-9]{64,128}$")

        guard let en = fm.enumerator(atPath: root) else { return nil }
        for case let item as String in en {
            let name = (item as NSString).lastPathComponent
            let range = NSRange(name.startIndex..<name.endIndex, in: name)
            if pattern.firstMatch(in: name, range: range) != nil {
                return name
            }
        }
        return nil
    }

    // MARK: - 状态

    func appendLog(_ s: String) {
        logLines.append(s)
        if logLines.count > 200 {
            logLines.removeFirst(logLines.count - 200)
        }
    }

    func setProgress(_ p: Double) {
        progress = max(0, min(1, p))
    }

    private func update(stage: String, detail: String) {
        DispatchQueue.main.async {
            self.stageText = stage
            self.detailText = detail
        }
    }

    private func fail(_ what: String, detail: String) {
        DispatchQueue.main.async {
            self.phase = .failed
            self.stageText = what
            self.detailText = detail
            self.inFlight = false
            self.appendLog("✗ " + what)
        }
    }
}
