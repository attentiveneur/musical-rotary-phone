import Foundation

/// 一条规则在某个编码下展开后的字节对
struct RulePattern {
    let ruleText: String       // "Core → 浪神"
    let oldData: Data
    let newData: Data
    let encoding: String       // "UTF-8" / "UTF-16LE" / "UTF-16BE"

    /// 新文字节数超过原文 → 塞不进去
    var fits: Bool { newData.count <= oldData.count }

    var paddedNew: Data {
        PakEngine.pad(newData, to: oldData.count, encoding: encoding)
    }
}

/// 命中位置
struct Hit {
    let offset: Int64
    let patternIndex: Int
}

enum PakEngine {

    // MARK: - 编码展开

    static func patterns(for rules: [Rule], autoShorten: Bool = true) -> [RulePattern] {
        var out: [RulePattern] = []
        for r in rules where r.enabled {
            let o = r.old, n = r.new
            guard !o.isEmpty else { continue }
            let label = "\(o) → \(n)"

            func add(_ od: Data?, _ nd: Data?, _ enc: String) {
                guard let od = od, let nd = nd else { return }
                if nd.count <= od.count {
                    out.append(RulePattern(ruleText: label, oldData: od, newData: nd, encoding: enc))
                } else if autoShorten, let cut = fit(n, encoding: enc, maxBytes: od.count) {
                    out.append(RulePattern(ruleText: label + "（自动截短）", oldData: od, newData: cut, encoding: enc))
                }
                // 塞不下且没开自动截短：这条编码直接不生成
            }

            add(o.data(using: .utf8), n.data(using: .utf8), "UTF-8")
            add(o.data(using: .utf16LittleEndian), n.data(using: .utf16LittleEndian), "UTF-16LE")
            add(o.data(using: .utf16BigEndian), n.data(using: .utf16BigEndian), "UTF-16BE")
        }
        return out
    }

    /// 按字符边界截断，保证不超过 maxBytes
    static func fit(_ text: String, encoding: String, maxBytes: Int) -> Data? {
        let codec: String.Encoding
        switch encoding {
        case "UTF-16LE": codec = .utf16LittleEndian
        case "UTF-16BE": codec = .utf16BigEndian
        default: codec = .utf8
        }
        var acc = ""
        var accData = Data()
        for ch in text {
            let trial = acc + String(ch)
            guard let d = trial.data(using: codec) else { break }
            if d.count > maxBytes { break }
            acc = trial
            accData = d
        }
        if accData.isEmpty { return nil }
        return accData
    }

    /// 一条规则到底能不能改，给界面用的人话说明
    static func feasibility(_ r: Rule) -> (text: String, ok: Bool) {
        var okCount = 0
        var detail: [String] = []
        if let od = r.old.data(using: .utf8), let nd = r.new.data(using: .utf8) {
            let fits = nd.count <= od.count
            if fits { okCount += 1 }
            detail.append("UTF-8 \(nd.count)/\(od.count)\(fits ? "✓" : "✗")")
        }
        if let od = r.old.data(using: .utf16LittleEndian), let nd = r.new.data(using: .utf16LittleEndian) {
            let fits = nd.count <= od.count
            if fits { okCount += 1 }
            detail.append("U16 \(nd.count)/\(od.count)\(fits ? "✓" : "✗")")
        }
        if okCount > 0 {
            return (detail.joined(separator: "  "), true)
        }
        // 一个都塞不下：告诉最多能放几个字
        let maxU8 = r.old.data(using: .utf8)?.count ?? 0
        let maxU16 = (r.old.data(using: .utf16LittleEndian)?.count ?? 0) / 2
        let cut8 = fit(r.new, encoding: "UTF-8", maxBytes: maxU8).flatMap { String(data: $0, encoding: .utf8) } ?? ""
        return ("新文太长，最多只能放 \(maxU8) 字节（UTF-8 约 \(maxU8 / 3) 个汉字）/ UTF-16 下 \(maxU16) 个字符；可自动截成「\(cut8)」", false)
    }

    /// 补齐到指定字节数，保证文件长度一个字节都不变
    static func pad(_ data: Data, to length: Int, encoding: String) -> Data {
        guard data.count < length else { return data }
        var d = data
        let need = length - data.count
        if encoding == "UTF-8" {
            d.append(contentsOf: [UInt8](repeating: 0x20, count: need))
        } else {
            // UTF-16：用空格 0x20 0x00 补，奇数长度尾部补 0x00
            var i = 0
            while i + 1 < need {
                d.append(contentsOf: encoding == "UTF-16LE" ? [0x20, 0x00] : [0x00, 0x20])
                i += 2
            }
            if i < need { d.append(0x00) }
        }
        return d
    }

    // MARK: - 只读扫描：找出所有可替换的位置

    static func findHits(url: URL,
                         patterns: [RulePattern],
                         chunkSize: Int = 4 * 1024 * 1024) throws -> [Hit] {
        guard !patterns.isEmpty else { return [] }
        let usable = patterns.enumerated().filter { $0.element.fits }
        guard !usable.isEmpty else { return [] }

        let maxOld = usable.map { $0.element.oldData.count }.max() ?? 1
        let overlap = max(0, maxOld - 1)

        let fh = try FileHandle(forReadingFrom: url)
        defer { try? fh.close() }

        let total = Int64(fh.seekToEndOfFile())
        var pos: Int64 = 0
        var hits: [Hit] = []
        var seen = Set<Int64>()

        while pos < total {
            fh.seek(toFileOffset: UInt64(pos))
            let want = min(Int64(chunkSize), total - pos)
            let buf = fh.readData(ofLength: Int(want))
            if buf.isEmpty { break }

            for (idx, p) in usable {
                var start = 0
                while start < buf.count {
                    guard let r = buf.range(of: p.oldData, options: [], in: start..<buf.count) else { break }
                    let off = pos + Int64(r.lowerBound)
                    if seen.insert(off).inserted {
                        hits.append(Hit(offset: off, patternIndex: idx))
                    }
                    start = r.upperBound
                }
            }

            if Int64(want) <= Int64(overlap) { break }
            pos += Int64(want) - Int64(overlap)
        }

        // 同一位置只留最长的那个匹配，避免重叠规则打架
        var best: [Int64: Hit] = [:]
        for h in hits {
            if let cur = best[h.offset] {
                if patterns[h.patternIndex].oldData.count > patterns[cur.patternIndex].oldData.count {
                    best[h.offset] = h
                }
            } else {
                best[h.offset] = h
            }
        }
        return best.values.sorted { $0.offset < $1.offset }
    }

    // MARK: - 原地写入（长度不变）

    static func writeHits(url: URL,
                          hits: [Hit],
                          patterns: [RulePattern]) throws {
        guard !hits.isEmpty else { return }
        let fh = try FileHandle(forUpdating: url)
        defer { try? fh.close() }

        for h in hits {
            let p = patterns[h.patternIndex]
            let payload = p.paddedNew
            guard payload.count == p.oldData.count else { continue }
            fh.seek(toFileOffset: UInt64(h.offset))
            fh.write(payload)
        }
        try? fh.synchronize()
    }

    // MARK: - 一步到位（改单个文件）

    static func editFile(_ item: PakItem,
                         rules: [Rule],
                         backupRoot: URL,
                         stamp: String,
                         doBackup: Bool,
                         preview: Bool,
                         autoShorten: Bool = true) -> FileEditReport {
        var rep = FileEditReport(name: item.name, sizeBefore: item.size)
        let pats = patterns(for: rules, autoShorten: autoShorten)
        let fitting = pats.filter { $0.fits }

        if pats.isEmpty {
            rep.error = "没有一条规则能塞进去（新文比原文长），把新文改短或打开「自动截短」"
            return rep
        }
        if fitting.isEmpty {
            rep.error = "规则里的新文字太长了，等长替换塞不进去（要改短一点）"
            return rep
        }

        do {
            let hits = try findHits(url: item.url, patterns: pats)
            if hits.isEmpty {
                rep.skipped = true
                rep.sizeAfter = item.size
                return rep
            }

            if preview {
                for h in hits {
                    let key = pats[h.patternIndex].ruleText
                    rep.hits[key, default: 0] += 1
                }
                rep.sizeAfter = item.size
                return rep
            }

            // 备份原件
            if doBackup {
                let fm = FileManager.default
                let dir = backupRoot.appendingPathComponent(stamp, isDirectory: true)
                if !fm.fileExists(atPath: dir.path) {
                    try? fm.createDirectory(at: dir, withIntermediateDirectories: true)
                }
                let dst = dir.appendingPathComponent(item.name)
                if !fm.fileExists(atPath: dst.path) {
                    try? fm.copyItem(at: item.url, to: dst)
                    rep.backedUp = fm.fileExists(atPath: dst.path)
                } else {
                    rep.backedUp = true
                }
            }

            try writeHits(url: item.url, hits: hits, patterns: pats)

            for h in hits {
                let key = pats[h.patternIndex].ruleText
                rep.hits[key, default: 0] += 1
            }

            // 核对大小
            let attrs = try? FileManager.default.attributesOfItem(atPath: item.id)
            rep.sizeAfter = (attrs?[.size] as? NSNumber)?.int64Value ?? 0
            if rep.sizeAfter != rep.sizeBefore {
                rep.error = "改完大小变了（\(rep.sizeBefore) → \(rep.sizeAfter)），已记下，请还原备份"
            }
        } catch {
            rep.error = LSPaths.describe(error)
            rep.sizeAfter = rep.sizeBefore
        }
        return rep
    }

    // MARK: - 扫描预览（不写任何东西）

    static func scanOnly(_ item: PakItem, rules: [Rule]) -> FileEditReport {
        editFile(item, rules: rules, backupRoot: URL(fileURLWithPath: "/tmp"),
                 stamp: "preview", doBackup: false, preview: true)
    }
}
