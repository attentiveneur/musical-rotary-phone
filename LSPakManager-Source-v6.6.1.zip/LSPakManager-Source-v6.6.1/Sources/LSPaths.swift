import Foundation

enum LSPaths {
    static let bundleId = "com.tencent.tmgp.pubgmhd"
    static let containerRoot = "/var/mobile/Containers/Data/Application"
    static let extSet: Set<String> = ["pak", "sig", "utoc", "ucas"]

    /// 游戏里 pak 可能出现的几个位置，按优先级找
    static let pakSubPaths: [String] = [
        "/Documents/ShadowTrackerExtra/Saved/Paks",
        "/Documents/ShadowTrackerExtra/Saved/Paks/Paks",
        "/Documents/ShadowTrackerExtra/Saved/Paks/pak",
        "/Library/Caches/ShadowTrackerExtra/Saved/Paks"
    ]

    // MARK: - App 自己的沙盒

    static func docDir() -> URL {
        FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)[0]
    }

    static func backupRoot() -> URL {
        docDir().appendingPathComponent("Backups", isDirectory: true)
    }

    /// 改好的包放这里，方便从「文件」App 或别的工具拖走
    static func fixedDir() -> URL {
        docDir().appendingPathComponent("改好的", isDirectory: true)
    }

    /// 要把文件导进游戏，先把包丢这里
    static func dropDir() -> URL {
        docDir().appendingPathComponent("待导入", isDirectory: true)
    }

    /// 导成功的源文件挪到这里，避免下次重复导
    static func importedDir() -> URL {
        docDir().appendingPathComponent("已导入", isDirectory: true)
    }

    /// 从游戏里导出来的包放这里
    static func exportDir() -> URL {
        docDir().appendingPathComponent("导出的", isDirectory: true)
    }

    static func ensureDirs() {
        let fm = FileManager.default
        for u in [backupRoot(), fixedDir(), dropDir(), importedDir(), exportDir()] {
            if !fm.fileExists(atPath: u.path) {
                try? fm.createDirectory(at: u, withIntermediateDirectories: true)
            }
        }
    }

    // MARK: - 定位游戏容器

    static func canListContainer() -> Bool {
        let fm = FileManager.default
        if let list = try? fm.contentsOfDirectory(atPath: containerRoot), !list.isEmpty {
            return true
        }
        return false
    }

    static func gameContainer() -> String? {
        let fm = FileManager.default
        guard let list = try? fm.contentsOfDirectory(atPath: containerRoot) else { return nil }

        // 1) 元数据精确匹配
        for d in list where !d.hasPrefix(".") {
            let base = containerRoot + "/" + d
            let meta = base + "/.com.apple.mobile_container_manager.metadata.plist"
            if let data = fm.contents(atPath: meta),
               let obj = try? PropertyListSerialization.propertyList(from: data, options: [], format: nil),
               let dict = obj as? [String: Any],
               let ident = dict["MCMMetadataIdentifier"] as? String,
               ident == bundleId {
                return base
            }
        }

        // 2) 目录特征兜底
        for d in list where !d.hasPrefix(".") {
            let base = containerRoot + "/" + d
            if fm.fileExists(atPath: base + "/Documents/ShadowTrackerExtra") {
                return base
            }
        }
        return nil
    }

    /// 找到真正放 pak 的那个目录
    static func paksDir(container: String) -> String? {
        let fm = FileManager.default
        for sub in pakSubPaths {
            let p = container + sub
            var isDir: ObjCBool = false
            if fm.fileExists(atPath: p, isDirectory: &isDir), isDir.boolValue {
                return p
            }
        }
        // 兜底：往上找任意含 .pak 的 Saved 目录
        let saved = container + "/Documents/ShadowTrackerExtra"
        if let e = fm.enumerator(atPath: saved) {
            while let rel = e.nextObject() as? String {
                if rel.hasSuffix(".pak") {
                    return (saved + "/" + (rel as NSString).deletingLastPathComponent)
                }
            }
        }
        return nil
    }

    // MARK: - 列文件

    static func listFiles(in dir: String, exts: Set<String>? = nil, depth: Int = 1) -> [PakItem] {
        let fm = FileManager.default
        let set = exts ?? extSet
        var out: [PakItem] = []
        var seen = Set<String>()

        func walk(_ path: String, _ d: Int) {
            guard let names = try? fm.contentsOfDirectory(atPath: path) else { return }
            for n in names where !n.hasPrefix(".") {
                let full = path + "/" + n
                var isDir: ObjCBool = false
                guard fm.fileExists(atPath: full, isDirectory: &isDir) else { continue }
                if isDir.boolValue {
                    if d < depth { walk(full, d + 1) }
                } else if set.contains((n as NSString).pathExtension.lowercased()) {
                    if seen.contains(full) { continue }
                    seen.insert(full)
                    let attrs = try? fm.attributesOfItem(atPath: full)
                    let size = (attrs?[.size] as? NSNumber)?.int64Value ?? 0
                    out.append(PakItem(id: full, url: URL(fileURLWithPath: full), size: size))
                }
            }
        }
        walk(dir, 0)
        return out.sorted { $0.name < $1.name }
    }

    static func listGamePaks(container: String) -> [PakItem] {
        guard let dir = paksDir(container: container) else { return [] }
        return listFiles(in: dir, exts: ["pak"], depth: 1)
    }

    /// 深扫一个目录，把里面所有 pak / sig 都翻出来（「全盘找 pak」用）
    static func scanDeep(_ root: String, depth: Int = 8, limit: Int = 3000) -> [PakItem] {
        let fm = FileManager.default
        var out: [PakItem] = []
        var hits = 0

        func walk(_ path: String, _ level: Int) {
            if hits >= limit { return }
            guard let names = try? fm.contentsOfDirectory(atPath: path) else { return }
            for n in names where !n.hasPrefix(".") {
                if hits >= limit { return }
                let full = path + "/" + n
                var isDir: ObjCBool = false
                guard fm.fileExists(atPath: full, isDirectory: &isDir) else { continue }
                if isDir.boolValue {
                    if level < depth { walk(full, level + 1) }
                } else if extSet.contains((n as NSString).pathExtension.lowercased()) {
                    hits += 1
                    let attrs = try? fm.attributesOfItem(atPath: full)
                    let size = (attrs?[.size] as? NSNumber)?.int64Value ?? 0
                    out.append(PakItem(id: full, url: URL(fileURLWithPath: full), size: size))
                }
            }
        }

        walk(root, 0)
        return out
    }

    /// App 沙盒里能被改的包（Documents 根 + 子目录一层）
    static func listLocalPaks() -> [PakItem] {
        let items = listFiles(in: docDir().path, exts: ["pak"], depth: 2)
        return items.filter { !$0.id.contains("/Backups/") && !$0.id.contains("/改好的/") }
    }

    /// 导入源：Documents 根 + 「待导入」+ App 里存着的「已导入」
    /// 关键是最后那一条 —— 文件进了 App 就一直留着，下次点「① 导入文件」
    /// 直接从这里再导一遍，不用再去系统「文件」里挑一次。
    static func listImportSources() -> [PakItem] {
        let exts: Set<String> = ["pak", "sig", "utoc", "ucas"]
        let fresh = listFiles(in: docDir().path, exts: exts, depth: 2).filter {
            !$0.id.contains("/Backups/")
                && !$0.id.contains("/改好的/")
                && !$0.id.contains("/已导入/")
                && !$0.id.contains("/导出的/")
        }
        // App 自带的那份库：导过一次就存这里，永远不用再选文件
        let saved = listFiles(in: importedDir().path, exts: exts, depth: 1)

        var out: [PakItem] = []
        var seen = Set<String>()
        for it in fresh where !seen.contains(it.name) {   // 同名的先用「待导入」里新的那份
            seen.insert(it.name)
            out.append(it)
        }
        for it in saved where !seen.contains(it.name) {
            seen.insert(it.name)
            out.append(it)
        }
        return out.sorted { $0.name < $1.name }
    }

    /// 删文件时扫的范围：整个 ShadowTrackerExtra（没有就退回 Paks 目录）
    static func deleteScanRoot(container: String?) -> String? {
        guard let container = container else { return nil }
        let base = container + "/Documents/ShadowTrackerExtra"
        var isDir: ObjCBool = false
        if FileManager.default.fileExists(atPath: base, isDirectory: &isDir), isDir.boolValue {
            return base
        }
        return paksDir(container: container)
    }

    // MARK: - 备份 / 还原

    struct BackupSet: Identifiable, Hashable {
        var id: String { stamp }
        let stamp: String
        let dir: URL
        let files: [String]
    }

    static func backupList() -> [BackupSet] {
        let fm = FileManager.default
        let root = backupRoot()
        guard let names = try? fm.contentsOfDirectory(atPath: root.path) else { return [] }
        var out: [BackupSet] = []
        for n in names.sorted(by: >) {
            let d = root.appendingPathComponent(n)
            var isDir: ObjCBool = false
            guard fm.fileExists(atPath: d.path, isDirectory: &isDir), isDir.boolValue else { continue }
            let files = (try? fm.contentsOfDirectory(atPath: d.path)) ?? []
            out.append(BackupSet(stamp: n, dir: d, files: files))
        }
        return out
    }

    static func describe(_ error: Error) -> String {
        let ns = error as NSError
        var s = "\(ns.localizedDescription) (errno \(ns.code))"
        if ns.domain == NSPOSIXErrorDomain {
            switch ns.code {
            case 1: s += " = Operation not permitted（权限被系统拒绝）"
            case 2: s += " = No such file or directory"
            case 13: s += " = Permission denied（沙盒/签名权限不足）"
            case 28: s += " = No space left on device（空间不足）"
            default: break
            }
        }
        return s
    }

    static func freeSpaceText() -> String {
        let url = docDir()
        if let v = try? url.resourceValues(forKeys: [.volumeAvailableCapacityForImportantUsageKey]),
           let bytes = v.volumeAvailableCapacityForImportantUsage {
            return Fmt.size(bytes)
        }
        return "未知"
    }
}
