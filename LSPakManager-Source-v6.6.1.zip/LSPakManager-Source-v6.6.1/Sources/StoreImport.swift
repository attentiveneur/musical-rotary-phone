import Foundation

/// 两件事：① 导入文件 ② 删除导入的文件（按导入记录撤，不靠关键字乱猜）
extension Store {

    // MARK: - 只看不动：列出要撤哪些

    func undoScan() {
        guard !busy else { return }
        let recs = imported.filter { !$0.deleted }
        guard !recs.isEmpty else {
            log("· 导入记录还是空的")
            log("  用这个 App 导进去的文件会自动记账。以前用别的版本导的，点「认领已导入的」让它对一遍")
            ui { self.pendingUndo = [] }
            return
        }

        let fm = FileManager.default
        let alive = recs.filter { fm.fileExists(atPath: $0.gamePath) }
        let gone = recs.count - alive.count

        ui { self.pendingUndo = alive }

        log("—— 看看要撤哪些（一个都还没动）——")
        var head = "记录 \(recs.count) 条，其中 \(alive.count) 个还在游戏里"
        if gone > 0 { head += "，\(gone) 个已经不在了" }
        log(head)
        for r in alive.prefix(40) {
            log("   · \(r.name)   \(r.sizeText)   \(r.time)")
        }
        if alive.count > 40 { log("   …… 还有 \(alive.count - 40) 个") }

        if alive.isEmpty {
            log("· 没有还在游戏里的导入文件。要清掉那些过期记录，点「清掉失效记录」")
        } else {
            log("对的话点红色「确认删 \(alive.count) 个」：删之前把游戏里那份收进 Backups，覆盖过原件的自动还原")
        }
    }

    // MARK: - 删除导入的文件

    func undoRun() {
        guard !busy else { return }
        let targets = pendingUndo
        guard !targets.isEmpty else {
            log("✗ 先点「看看要撤哪些」，清单看对了再删")
            return
        }

        busy = true
        let keep = undoKeepCopy
        let restoreBak = undoRestoreBackup
        let stamp = Fmt.stamp()
        let total = targets.count
        log("==== 删除导入的文件：\(total) 个 · \(keep ? "删前留副本" : "不留副本") · \(restoreBak ? "覆盖过原件的自动还原" : "不还原") ====")

        queue.async { [weak self] in
            guard let self = self else { return }

            let reports = AutoIO.undoImports(targets,
                                             backupRoot: LSPaths.backupRoot(),
                                             stamp: stamp,
                                             keepCopy: keep,
                                             restoreBackup: restoreBak) { i, all, name in
                self.setProgress(Double(i) / Double(max(all, 1)), "\(i + 1)/\(all)  \(name)")
            }

            var ok = 0
            for r in reports {
                if let e = r.error {
                    self.log("✗ \(r.name) 没撤成：\(e)")
                } else {
                    ok += 1
                    self.log("✓ \(r.name) — \(r.action)")
                    ImportLog.markDeleted(id: r.id, hold: r.holdPath)
                }
            }

            self.setProgress(1, "完成")
            self.log("==== 删完：\(ok) / \(total) 个 ====")
            self.log("删的是游戏目录里那份；App 库里那份原封没动，想再导回去点「① 导入文件」就行")
            if keep && ok > 0 {
                self.log("删下来的那几份收在 Backups/删掉的-\(stamp)/，想放回去点那行右边的「放回」")
            }
            self.log("现在退掉游戏后台重新进，看是不是回到导入前的样子")

            let recs = ImportLog.load()
            self.ui {
                self.busy = false
                self.pendingUndo = []
                self.imported = recs
                self.banner = "已删掉 \(ok) 个导入文件"
                self.backups = LSPaths.backupList()
            }
            self.refreshGameOnly()
        }
    }

    /// 单条撤回
    func undoOne(_ r: ImportRecord) {
        guard !busy else { return }
        busy = true
        let keep = undoKeepCopy
        let restoreBak = undoRestoreBackup
        let stamp = Fmt.stamp()
        log("==== 撤回一条：\(r.name) ====")

        queue.async { [weak self] in
            guard let self = self else { return }
            let reports = AutoIO.undoImports([r],
                                             backupRoot: LSPaths.backupRoot(),
                                             stamp: stamp,
                                             keepCopy: keep,
                                             restoreBackup: restoreBak) { _, _, _ in }

            if let one = reports.first {
                if let e = one.error {
                    self.log("✗ \(one.name)：\(e)")
                } else {
                    self.log("✓ \(one.name) — \(one.action)")
                    ImportLog.markDeleted(id: one.id, hold: one.holdPath)
                }
            }

            let recs = ImportLog.load()
            self.ui {
                self.busy = false
                self.imported = recs
                self.pendingUndo = self.pendingUndo.filter { $0.id != r.id }
            }
            self.refreshGameOnly()
        }
    }

    /// 删错了，把它再放回游戏
    func redoOne(_ r: ImportRecord) {
        guard !busy else { return }
        guard let hold = r.holdPath else {
            log("· 这条当时没留副本，放不回去。用「① 导入文件」重新导一次吧")
            return
        }
        busy = true
        log("==== 放回游戏：\(r.name) ====")

        queue.async { [weak self] in
            guard let self = self else { return }
            let err = AutoIO.putBack(from: hold, to: r.gamePath) { _, _, _ in }
            if let e = err {
                self.log("✗ \(r.name) 没放回去：\(e)")
            } else {
                self.log("✓ \(r.name) 已放回游戏")
                ImportLog.markRestored(id: r.id)
            }
            let recs = ImportLog.load()
            self.ui {
                self.busy = false
                self.imported = recs
            }
            self.refreshGameOnly()
        }
    }

    /// 认领：把「已导入」文件夹里、游戏里也确实存在同名的文件补记成账
    /// 专门对付以前用别的版本导进去、现在想撤掉的情况
    func adoptParked() {
        guard !busy else { return }
        guard let pd = paksDir else {
            log("✗ 还没拿到游戏 Paks 目录，认领不了")
            return
        }
        busy = true
        let park = LSPaths.importedDir()
        log("==== 认领：App 的「已导入」文件夹 ↔ 游戏 Paks ====")

        queue.async { [weak self] in
            guard let self = self else { return }
            let fm = FileManager.default
            guard let names = try? fm.contentsOfDirectory(atPath: park.path) else {
                self.log("· 「已导入」文件夹读不到，没东西可认领")
                self.ui { self.busy = false }
                return
            }

            var n = 0
            for name in names where !name.hasPrefix(".") {
                let src = park.appendingPathComponent(name)
                var isDir: ObjCBool = false
                guard fm.fileExists(atPath: src.path, isDirectory: &isDir), !isDir.boolValue else { continue }
                let dst = pd + "/" + name
                guard fm.fileExists(atPath: dst) else { continue }
                let attrs = try? fm.attributesOfItem(atPath: dst)
                let size = (attrs?[.size] as? NSNumber)?.int64Value ?? 0
                ImportLog.add(ImportRecord(name: name,
                                           gamePath: dst,
                                           size: size,
                                           time: Fmt.shortDate(),
                                           action: "新增",
                                           backupPath: nil))
                n += 1
                self.log("✓ 记上了：\(name)")
            }

            if n == 0 {
                self.log("· 没有能认领的（「已导入」里的文件在游戏里找不到同名的）")
            } else {
                self.log("==== 认领了 \(n) 个，现在点「② 删除导入的」就能撤 ====")
            }

            let recs = ImportLog.load()
            self.ui {
                self.busy = false
                self.imported = recs
                self.banner = "认领了 \(n) 个导入文件"
            }
            self.refreshGameOnly()
        }
    }

    /// 清掉「游戏里文件已经不在了」的过期记录
    func pruneRecords() {
        let gone = ImportLog.pruneMissing()
        imported = ImportLog.load()
        pendingUndo = pendingUndo.filter { FileManager.default.fileExists(atPath: $0.gamePath) && !$0.deleted }
        log(gone > 0 ? "· 清掉 \(gone) 条失效记录" : "· 没有失效记录，账是干净的")
    }

    // MARK: - 从手机里选文件

    func pickFiles(_ urls: [URL]) {
        guard !urls.isEmpty else { return }
        let dest = LSPaths.dropDir()
        let fm = FileManager.default
        var ok = 0
        var bad = 0

        for u in urls {
            let scoped = u.startAccessingSecurityScopedResource()
            defer { if scoped { u.stopAccessingSecurityScopedResource() } }

            var isDir: ObjCBool = false
            if fm.fileExists(atPath: u.path, isDirectory: &isDir), isDir.boolValue {
                log("· \(u.lastPathComponent) 是文件夹，跳过（只收文件）")
                continue
            }

            let to = dest.appendingPathComponent(u.lastPathComponent)
            try? fm.removeItem(at: to)
            do {
                try fm.copyItem(at: u, to: to)
                let attrs = try? fm.attributesOfItem(atPath: to.path)
                let size = (attrs?[.size] as? NSNumber)?.int64Value ?? 0
                ok += 1
                log("✓ 已存进 App：\(u.lastPathComponent)   \(Fmt.size(size))")
            } catch {
                bad += 1
                log("✗ \(u.lastPathComponent) 复制失败：\(LSPaths.describe(error))")
            }
        }

        log("==== 存进 App：\(ok) 个成功，\(bad) 个失败 · 这些包会一直留在这里 ====")
        if ok > 0 { log("点大绿按钮「① 导入文件」就写进游戏") }
        refreshImportList()
    }

    /// 手动挑游戏里的包删（给「以前用别的工具导进去、没有记录」的包用）
    /// 删前留副本，删完记一笔，随时能「放回」
    func deleteGameFiles(_ targets: [PakItem]) {
        guard !busy else { return }
        guard !targets.isEmpty else { return }
        busy = true
        let keep = undoKeepCopy
        let stamp = Fmt.stamp()
        log("==== 手动删游戏里的包：\(targets.count) 个 · \(keep ? "删前留副本" : "不留副本") ====")

        queue.async { [weak self] in
            guard let self = self else { return }
            let reps = AutoIO.deleteAll(targets,
                                        backupRoot: LSPaths.backupRoot(),
                                        stamp: stamp,
                                        keepCopy: keep) { i, all, name in
                self.setProgress(Double(i) / Double(max(all, 1)), "\(i + 1)/\(all)  \(name)")
            }

            var ok = 0
            for r in reps {
                if let e = r.error {
                    self.log("✗ \(r.name)：\(e)")
                    continue
                }
                ok += 1
                self.log("✓ \(r.name) 已删")
                var rec = ImportRecord(name: r.name,
                                       gamePath: r.path,
                                       size: r.size,
                                       time: Fmt.shortDate(),
                                       action: "手动删",
                                       backupPath: nil)
                rec.deleted = true
                rec.deletedAt = Fmt.shortDate()
                rec.holdPath = r.movedTo
                ImportLog.add(rec)
            }

            self.setProgress(1, "完成")
            self.log("==== 删完：\(ok) / \(targets.count) 个 ====")
            if keep && ok > 0 {
                self.log("副本在 Backups/删掉的-\(stamp)/，「已导入」那页点「放回」能拿回来")
            }

            let recs = ImportLog.load()
            self.ui {
                self.busy = false
                self.imported = recs
                self.banner = "手动删了 \(ok) 个"
                self.scanFound = self.scanFound.filter { fm in
                    !targets.contains(where: { $0.id == fm.id })
                }
            }
            self.refreshGameOnly()
        }
    }

    // MARK: - 全盘找 pak

    func fullScan() {
        guard !busy else { return }
        busy = true
        let gp = gamePath
        let pd = paksDir
        log("==== 全盘找 pak / sig ====")

        queue.async { [weak self] in
            guard let self = self else { return }
            var found: [PakItem] = []
            var seen = Set<String>()

            func absorb(_ list: [PakItem]) {
                for it in list {
                    if seen.contains(it.id) { continue }
                    seen.insert(it.id)
                    found.append(it)
                }
            }

            if let p = pd { absorb(LSPaths.scanDeep(p, depth: 8, limit: 5000)) }
            if let c = gp { absorb(LSPaths.scanDeep(c, depth: 10, limit: 5000)) }

            // 游戏目录扫得太少，就把其他 App 的容器也翻一遍（有全盘权限才翻得动）
            if found.count < 3 {
                if let names = try? FileManager.default.contentsOfDirectory(atPath: LSPaths.containerRoot) {
                    for n in names where !n.hasPrefix(".") {
                        let base = LSPaths.containerRoot + "/" + n
                        if let c = gp, base == c { continue }
                        absorb(LSPaths.scanDeep(base, depth: 8, limit: 300))
                        if found.count > 8000 { break }
                    }
                }
            }

            let pakN = found.filter { $0.ext == "pak" }.count
            let sigN = found.filter { $0.ext == "sig" }.count
            self.log("扫到 \(found.count) 个：pak \(pakN) 个 · sig \(sigN) 个")
            for it in found.prefix(30) {
                self.log("   · \(it.name)   \(it.sizeText)")
            }
            if found.count > 30 { self.log("   …… 还有 \(found.count - 30) 个") }

            if found.isEmpty {
                self.log("· 一个都没扫到：先确认游戏装过、至少进过一次游戏")
            } else {
                self.log("· 这份清单只给你看清游戏里都有啥，一个字节都没动")
            }

            self.ui {
                self.busy = false
                self.scanFound = found
                self.scanNote = "pak \(pakN) · sig \(sigN)"
                self.banner = "全盘扫到 \(found.count) 个 pak/sig"
            }
        }
    }
}
