import Foundation

/// 一条替换规则：原文 -> 新文
struct Rule: Identifiable, Hashable, Codable {
    var id: UUID = UUID()
    var old: String
    var new: String
    var enabled: Bool = true

    var label: String { "\(old) → \(new)" }
}

/// 一个 pak / sig 文件
struct PakItem: Identifiable, Hashable {
    let id: String          // 完整路径，稳定 id
    let url: URL
    let size: Int64

    var name: String { url.lastPathComponent }
    var sizeText: String { Fmt.size(size) }
    var ext: String { url.pathExtension.lowercased() }
}

enum Fmt {
    static func size(_ b: Int64) -> String {
        let f = ByteCountFormatter()
        f.countStyle = .file
        f.allowedUnits = [.useMB, .useKB, .useGB]
        return f.string(fromByteCount: b)
    }

    static func clock() -> String {
        let f = DateFormatter()
        f.dateFormat = "HH:mm:ss"
        return f.string(from: Date())
    }

    static func stamp() -> String {
        let f = DateFormatter()
        f.dateFormat = "yyyyMMdd-HHmmss"
        return f.string(from: Date())
    }

    static func shortDate() -> String {
        let f = DateFormatter()
        f.dateFormat = "MM-dd HH:mm"
        return f.string(from: Date())
    }
}

/// 一条导入记录：哪个文件、导进了游戏的哪个位置、当时有没有覆盖原件
struct ImportRecord: Identifiable, Codable, Hashable {
    var id: String = UUID().uuidString
    var name: String
    var gamePath: String
    var size: Int64
    var time: String
    var action: String = "新增"          // 新增 / 覆盖
    var backupPath: String? = nil        // 覆盖时原件的备份路径，撤回时可还原
    var deleted: Bool = false            // 是否已经从游戏里删掉
    var deletedAt: String? = nil
    var holdPath: String? = nil          // 删掉的那份留在哪儿，能再放回去

    var sizeText: String { Fmt.size(size) }

    var statusText: String {
        if deleted { return "已删除" }
        let fm = FileManager.default
        return fm.fileExists(atPath: gamePath) ? "在游戏里" : "文件不在了"
    }

    var statusOK: Bool {
        !deleted && FileManager.default.fileExists(atPath: gamePath)
    }
}

/// 一次批量操作的结果
struct OpResult {
    var filesOK = 0
    var filesFail = 0
    var totalHits = 0
    var lines: [String] = []
}

/// 单个文件的处理结果
struct FileEditReport {
    var name: String
    var hits: [String: Int] = [:]
    var skipped: Bool = false      // 没命中任何规则
    var error: String? = nil
    var sizeBefore: Int64 = 0
    var sizeAfter: Int64 = 0
    var backedUp: Bool = false

    var hitCount: Int { hits.values.reduce(0, +) }
    var summary: String {
        if let e = error { return "✗ \(name) — \(e)" }
        if skipped { return "· \(name) — 没有命中，跳过" }
        let detail = hits.map { "\($0.key)×\($0.value)" }.joined(separator: "，")
        return "✓ \(name) — 改了 \(hitCount) 处（\(detail)），大小 \(Fmt.size(sizeBefore)) 不变"
    }
}
