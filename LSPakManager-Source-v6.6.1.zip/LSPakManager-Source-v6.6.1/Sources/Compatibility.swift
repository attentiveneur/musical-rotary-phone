//
//  Compatibility.swift
//  对外分发版：设备闸门
//
//  内核引擎只在一段系统版本里成立，超出范围强行跑大概率崩机。
//  这里在点按钮之前就拦住，并把人话原因显示出来。
//

import Foundation
import UIKit
import Darwin

struct CompatibilityResult {
    let ok: Bool
    let title: String
    let reason: String
}

enum Compatibility {

    /// 与内核引擎上游一致的支持范围：
    ///   - iOS 17.0 – 18.7.1
    ///   - iOS 26.0.x
    ///   - 设备需 A12 及以后（arm64e）
    static func check() -> CompatibilityResult {
        let v = ProcessInfo.processInfo.operatingSystemVersion
        let sys = "iOS \(v.majorVersion).\(v.minorVersion).\(v.patchVersion)"
        let hw = hardwareModel()

        if v.majorVersion < 17 {
            return CompatibilityResult(
                ok: false,
                title: "系统版本太老",
                reason: "\(hw) · \(sys)：内核引擎从 iOS 17.0 起才支持，这个版本上没有对应的内核布局。"
            )
        }

        if v.majorVersion == 17 {
            return CompatibilityResult(ok: true, title: "支持", reason: "\(hw) · \(sys)")
        }

        if v.majorVersion == 18 {
            let supported = v.minorVersion < 7 || (v.minorVersion == 7 && v.patchVersion <= 1)
            if supported {
                return CompatibilityResult(ok: true, title: "支持", reason: "\(hw) · \(sys)")
            }
            return CompatibilityResult(
                ok: false,
                title: "系统版本太新",
                reason: "\(hw) · \(sys)：只支持到 18.7.1。这个版本的内核布局对不上，跑下去大概率崩机或没反应。"
            )
        }

        if v.majorVersion == 26 && v.minorVersion == 0 {
            return CompatibilityResult(ok: true, title: "支持", reason: "\(hw) · \(sys)")
        }

        return CompatibilityResult(
            ok: false,
            title: "系统不在支持范围",
            reason: "\(hw) · \(sys)：支持 iOS 17.0–18.7.1 与 26.0.x。"
        )
    }

    /// 硬件标识，比如 iPhone15,3 / iPad13,8
    static func hardwareModel() -> String {
        var info = utsname()
        uname(&info)
        let machineSize = MemoryLayout.size(ofValue: info.machine)
        let machine = withUnsafePointer(to: &info.machine) {
            $0.withMemoryRebound(to: CChar.self, capacity: machineSize) {
                String(cString: $0)
            }
        }
        return machine.isEmpty ? "未知机型" : machine
    }

    /// 给用户看的一行设备信息
    static func deviceSummary() -> String {
        "\(hardwareModel()) · \(UIDevice.current.model) · iOS \(ProcessInfo.processInfo.operatingSystemVersionString)"
    }
}
