# 浪神文件管理器 · LSPakManager

> **Copyright (C) 2026 浪神**
> 本程序以 **GNU Affero General Public License v3.0（AGPL-3.0）** 发布，许可证全文见同目录 `LICENSE`。
> 你可以自由使用、修改、再分发；再分发（包括只发编译好的 IPA）时必须同时提供完整源码，并保留本声明。
> 本程序内嵌的内核引擎来自开源工程 `rooootdev/lara`（作者 ruter，AGPL-3.0），我方改动见 `THIRD-PARTY-NOTICES.md`。

iOS 上的游戏资源包管理工具。一个按钮打通内核权限，之后自动定位游戏 `Paks` 目录，做导入 / 备份 / 删除 / 等长改字。

```
内核读写 → 取本机内核 → 解析偏移 → 沙盒逃逸 → 全盘读写
              ↓
    导入文件 · 删除导入 · 选文件 · 全盘找 pak · 等长改字
```

---

## App 图标

图标资源在 `Sources/Assets.xcassets/AppIcon.appiconset/`，13 个尺寸（iPhone 20/29/40/60、iPad 20/29/40/76/83.5、App Store 1024），全部由同一张 1024 母图派生，**无 alpha 通道**（iOS 要求图标不透明）。

`project.yml` 里已设 `ASSETCATALOG_COMPILER_APPICON_NAME: AppIcon`，`xcodegen generate` 之后直接生效，不需要手动在 Xcode 里点选。

要换图标：把新的 1024×1024 方形 PNG（满幅、别自己画圆角、别带透明通道）覆盖 `AppIcon.appiconset/icon_1024.png` 再跑一次构建即可；其余尺寸请用脚本从母图重派生，别单独替换小图，否则会出现尺寸错位。


## App 背景

主界面背景是可换的，点右上角那个小图片图标（标题行最右）打开「背景」面板。

- 内置五套：深空 / 午夜蓝 / 墨绿 / 暗紫 / 纯黑，都是代码画的渐变，不占包体积
- 第六格「我的图片」：从相册选一张，App 会缩到最长边 1800 存进自己的 Documents，不走相册权限（用的是系统 PHPicker，不会弹授权框）
- 选过的背景记在 UserDefaults，图片存在 `Documents/background.jpg`，重开 App 还在；换机或清缓存后图片没了会自动退回「深空」，不会白屏
- 「压暗程度」只在用了自己的图片时出现，15%–85% 可调。图片太亮、上面白字看不清就往上拉

实现都在 `Sources/Appearance.swift`（`Appearance` 管状态和存取，`BackgroundLayer` 画背景，`PhotoBackgroundPicker` 包相册选择器），`ContentView` 里只有三处挂钩：`BackgroundLayer()`、标题行的按钮、`.sheet` 面板。这套东西跟内核引擎、导入删除逻辑完全解耦，不影响原有功能。

---

## 支持范围

| 项目 | 范围 |
|---|---|
| 系统 | **iOS 17.0 – 18.7.1**、**iOS 26.0.x** |
| 芯片 | **A12 及以后**（二进制按 arm64e 编译） |
| 明确不支持 | iOS 18.7.2 及以上、iOS 26.1 及以上、iOS 16.x 及以下、M5 / A19 设备 |

不在支持范围的设备，点激活按钮时会**在本地被拦下并说明原因**，不会真的去碰内核。

## 功能

| 按钮 | 干什么 |
|---|---|
| ① 导入文件（绿） | 把「待导入」里的包写进游戏目录，同名先备份原件，写完核对字节数，源文件移到「已导入」并记账 |
| ② 删除导入的（暗红） | 第一下只列清单不动手，按钮变「确认删 N 个」，第二下才删；删前收进 `Backups/删掉的-时间/`，可放回 |
| ③ 从手机里选文件（蓝） | 系统文件选择器，可多选，直接进「待导入」 |
| ④ 全盘找 pak（紫） | 先扫 Paks 目录，不全就往游戏容器、其它 App 容器翻 |
| 进阶 · 等长改字 | 折叠区。等长替换，塞不下会提示差距并可选自动截短 |

## 安装

### A. TrollStore 设备（iOS 14.0 – 16.6.1，部分 17.0）

把 `.ipa` 丢进 TrollStore 直接装，永久签名不过期。这类设备不需要内核引擎，文件权限由 TrollStore 提供。

### B. 自己签名（需要你自己的 Apple ID 或自己的证书）

用 Sideloadly / AltStore / SideStore / ESign 等工具签名安装。

- 个人免费证书：**7 天过期**，最多同时 3 个 App，到期重签。
- **必须重签 Frameworks**：`libxpf.dylib`、`libgrabkernel2.dylib` 在 IPA 的 `Frameworks/` 里，只签主程序会一打开就闪退。签名工具里找「重签全部框架 / 深度签名 / Deep Sign」这类选项。
- 本项目**不提供证书，也不代签**。

### C. 自己编译

```bash
brew install xcodegen
xcodegen generate
xcodebuild -project LSPakManager.xcodeproj -scheme LSPakManager -configuration Release -sdk iphoneos build CODE_SIGNING_ALLOWED=NO
```

或者直接走 GitHub Actions：仓库里 `.github/workflows/main.yml` 已配好，推源码 zip 上去就会编出未签名 IPA（Artifacts 里）。

## 使用要点

1. 打开 App → 点「一键激活内核 · 全盘读写」→ 等十几秒到两分钟
2. 状态变「已激活」，标题行显示「已找到：com.xxx」→ 四个按钮可用
3. **每次重开 App / 重启设备都要重新激活一次**（内核状态只活在当次运行里，这是这类工具的通性）
4. 激活失败就杀掉 App 重开再点，这类利用本来就有一定失败率
5. 动大包之前，先在 App 里把原件备份一份

## 风险（请让使用者知道）

- 内核利用属于不稳定操作：失败时可能 App 无响应、桌面重启，极少数情况需要强制重启设备。
- 改了 `.pak` 之后如果游戏启动闪退，八成是包内自校验没过，不是导入出错。把备份还原回去即可。
- 删 `.sig` 最容易让游戏校验失败直接闪退，不确定就别碰。
- 不要在存着重要数据的主力设备上试。

## 许可

**GNU Affero General Public License v3.0 (AGPL-3.0)** —— 见 [LICENSE](LICENSE)。

内核引擎部分来自 [rooootdev/lara](https://github.com/rooootdev/lara)，详见 [THIRD-PARTY-NOTICES.md](THIRD-PARTY-NOTICES.md)。

> 分发须知：AGPL-3.0 要求**发二进制的同时提供完整源码**，并且整个作品（含本项目界面部分）都以 AGPL-3.0 授权，不得附加「禁止转载 / 禁止商用」这类额外限制。

## 不包含

- 不包含任何游戏本体资源
- 不包含任何证书
- 不包含 `3105` 的任何二进制内容
