//
//  LSPakManager-Bridging-Header.h
//  只暴露内核引擎和这次实际要用的 C 接口，减少编译面
//

#ifndef LSPakManager_Bridging_Header_h
#define LSPakManager_Bridging_Header_h

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

#include <sys/types.h>
#include <stdint.h>
#include <stdbool.h>

#include "LSZlib.h"
#include "CrashGuard.h"
#include "SbxSurgeon.h"

#import "kexploit/darksword.h"
#import "kexploit/offsets.h"
#import "kexploit/pe/sbx.h"
#import "kexploit/pe/vnode.h"

#endif
