//
//  AccessEngine.swift
//  目录通道：拿游戏目录的读写权（完全不碰内核）
//
//  为什么这样最稳：
//    写入内核空间是重启的根，死等某个内核结果是卡住的根。
//    这版一个内核字节都不写，也不改页表、不做逃逸——所以不会重启、不会死卡。
//    它只做一件事：把系统的容器访问权拿到手，然后用普通的文件读写去干活。
//
//  全版本策略（26.6.1 在内，一个不漏）：
//    不看系统版本，所有版本走同一条流程，只按结果分级报告。
//    iOS 15 / 16 / 17 / 18 / 26 / 以后更高版本，一律放行。
//

import Foundation
import UIKit
import Darwin
import Combine

final class AccessEngine: ObservableObject {

    static let shared = AccessEngine()

    enum Phase: Equatable {
        case idle
        case running
        case ready
        case failed
    }

    @Published private(set) var phase: Phase = .idle
    @Published private(set) var stageText: String = "未打通"
    @Published private(set) var detailText: String = "点一下拿游戏目录读写权 · 不碰内核，不重启"
    @Published private(set) var progress: Double = 0
    @Published private(set) var logLines: [String] = []
    @Published private(set) var containerPath: String?
    @Published private(set) var routeText: String = "未选择"
    @Published private(set) var lastVerdict: String = ""
    /// 最近一次体检的结论（界面一行显示）
    @Published private(set) var probeLine: String = "还没体检"
    private var latestProbe: ProbeReport?

    private var inFlight = false
    private let queue = DispatchQueue(label: "ls.access", qos: .userInitiated)

    private init() {}

    var running: Bool { phase == .running }
    var ready: Bool { phase == .ready }

    // MARK: - 对外动作

    /// 用户点按钮：完整跑一遍，日志全留下
    func activate() {
        guard !inFlight else { return }
        inFlight = true
        phase = .running
        progress = 0
        logLines.removeAll()
        containerPath = nil
        routeText = "正在尝试"
        stageText = "正在打通"
        detailText = "第一步：看这台机器能不能直接进游戏目录"
        queue.async { [weak self] in
            guard let self = self else { return }
            self.run()
        }
    }

    /// App 刚打开时静默试一次：能通就直接就绪，用户连按钮都不用点
    func silentTry() {
        guard phase == .idle, !inFlight else { return }
        queue.async { [weak self] in
            guard let self = self else { return }
            if SandboxBridge.shared.canListContainers() {
                let container = LSPaths.scanGameContainer()
                let paks = container.flatMap { LSPaths.paksDir(container: $0) }
                if paks != nil {
                    DispatchQueue.main.async {
                        self.containerPath = container
                        self.routeText = "直连"
                        self.phase = .ready
                        self.stageText = "已打通（自动）"
                        self.detailText = "游戏目录已可读写，直接点下面按钮就行"
                        self.progress = 1
                    }
                    return
                }
            }

            let res = SandboxBridge.shared.open(bundleId: LSPaths.bundleId)
            if let t = res.token { _ = SandboxBridge.shared.consume(t) }
            let container = res.path ?? LSPaths.scanGameContainer()
            let paks = container.flatMap { LSPaths.paksDir(container: $0) }
            guard paks != nil else { return }
            DispatchQueue.main.async {
                self.containerPath = container
                self.routeText = res.via
                self.phase = .ready
                self.stageText = "已打通（自动）"
                self.detailText = "游戏目录已可读写，直接点下面按钮就行"
                self.progress = 1
            }
        }
    }

    // MARK: - 主流程

    private func run() {
        sentinel("start")
        let compat = Compatibility.check()
        log("设备：\(Compatibility.deviceSummary())")
        log("系统判定：\(compat.title) · \(compat.reason)")
        log("路线：容器通道（不写内核、不改页表、不做逃逸）")

        // ① 直连
        step(0.08, "第一步 · 直连", "看这台机器是不是本来就能读游戏目录")
        sentinel("stage=直连")
        let direct = SandboxBridge.shared.canListContainers()
        log(direct ? "· 容器目录能直接列：先走直连" : "· 容器目录列不出来：改走容器服务")

        // ② 权限体检：先查清这台机器允许到哪一步
        step(0.18, "第二步 · 权限体检", "查签名权限、容器接口、系统放行情况（只读，不改任何东西）")
        sentinel("stage=体检")
        let probe = ContainerProbe.shared.run(bundleId: LSPaths.bundleId)
        latestProbe = probe
        log("· 体检结论：\(probe.verdict.rawValue)")
        log("· " + probe.headline)
        for line in probe.text.split(separator: "\n").prefix(60) {
            if line.hasPrefix("· ") { log(String(line)) }
        }
        writeProbeFile(probe)

        // ③ 问系统要容器
        step(0.36, "第三步 · 问系统要容器", "按 bundle id 查游戏容器，并取它的沙盒令牌")
        sentinel("stage=查容器")
        let res = SandboxBridge.shared.open(bundleId: LSPaths.bundleId)
        res.notes.forEach { log("· " + $0) }

        // ④ 吃令牌
        var tokenHandle: Int64 = -1
        if let token = res.token {
            step(0.55, "第四步 · 拿访问权", "把容器令牌交给本进程（不碰内核）")
            sentinel("stage=拿访问权")
            tokenHandle = SandboxBridge.shared.consume(token)
            if tokenHandle >= 0 {
                log("· 访问权已拿到（句柄 \(tokenHandle)，全程持有）")
            } else {
                log("· 令牌没被系统接受（返回 \(tokenHandle)）")
            }
        } else {
            log("· 没有令牌可拿，先按直连试试")
        }

        // ⑤ 定位游戏目录：每个候选都先验证「真的能打开」，再决定用不用
        step(0.72, "第五步 · 定位游戏目录", "先验证容器能不能打开，再逐级往下走")
        sentinel("stage=找目录")
        sentinel("体检=\(probe.verdict.rawValue)")
        sentinel("expected=\(LSPaths.bundleId)")

        // 这台机器上装着的游戏类 App，核对 bundle id 到底对不对
        let games = LSPaths.gameBundleIds()
        if games.isEmpty {
            sentinel("已装游戏=读不到")
        } else {
            for (ident, p) in games {
                sentinel("已装游戏=\(ident) 路径=\(p)")
            }
        }

        var candidates: [(String, String)] = []
        if let p = LSPaths.scanGameContainer() { candidates.append((p, "元数据扫描")) }
        if let p = res.path { candidates.append((p, res.via)) }
        if let p = probe.mcmPath { candidates.append((p, "容器类别查询")) }
        if let p = probe.proxyPath { candidates.append((p, "App 清单服务")) }

        var container: String? = nil
        var usedRoute = res.via
        var missCount = 0
        for (p, via) in candidates where container == nil {
            guard SandboxBridge.isDataContainer(p) else {
                sentinel("候选=\(p) 来源=\(via) 跳过=不是数据容器")
                continue
            }
            let state = LSPaths.dirState(p)
            sentinel("候选=\(p) 来源=\(via) 状态=\(state)")
            if state.contains("可列=是") {
                container = p
                usedRoute = via
            } else {
                missCount += 1
            }
        }
        guard let container = container else {
            let denied = (probe.verdict == .signatureLacksPrivilege) || missCount > 0
            var detail: String
            if missCount > 0 {
                detail = "容器路径查到了，但目录打不开——系统直接拒绝。这就是签名权限的边界：普通证书签的 App 没有读别的 App 容器的权限。每一步的错误码已经写进「通道哨兵.txt」，导出发我。"
            } else if denied {
                detail = "接口都在，是签名权限不够——系统不允许进别的 App 目录。已把每一步写进「通道哨兵.txt」。"
            } else {
                detail = "四条路线都没拿到 \(LSPaths.bundleId) 的数据目录。已把每一步写进「通道哨兵.txt」。"
            }
            if let nd = res.nonDataPath {
                detail += "\n\n注意：系统只给了安装包目录 \(nd)，那是 App 本体所在，Paks 不在里面。"
            }
            finish(ok: false,
                   stage: denied ? "签名没带容器权限" : "没拿到游戏数据目录",
                   detail: detail)
            sentinel("fail=容器打不开 打不开的候选数=\(missCount)")
            dumpAll(probe)
            return
        }
        DispatchQueue.main.async {
            self.containerPath = container
            self.routeText = usedRoute
            self.probeLine = probe.verdict.rawValue
        }
        log("· 游戏容器：\(container)（路线：\(usedRoute)）")

        // ⑤b 逐级验证：这棵目录现在能开到第几层，原样写进哨兵
        step(0.80, "第五步 · 逐级验目录", "容器 → Documents → ShadowTrackerExtra → Saved → Paks")
        sentinel("stage=验层级")
        let levels = ["", "/Documents", "/Documents/ShadowTrackerExtra",
                      "/Documents/ShadowTrackerExtra/Saved",
                      "/Documents/ShadowTrackerExtra/Saved/Paks"]
        for lv in levels {
            sentinel("层级=\(lv.isEmpty ? "/" : lv) \(LSPaths.dirState(container + lv))")
        }
        sentinel("stage=验层级完")

        // ⑤c 找 Paks：固定路径 → 深扫这个容器 → 全盘扫（三层都有界，不会卡死）
        step(0.86, "第五步 · 找 Paks", "固定路径 → 深扫容器 → 全盘扫")
        var paks = LSPaths.paksDir(container: container)
        var paksVia = "固定路径"
        if paks == nil, let p = LSPaths.searchPaksDir(under: container, depth: 5, maxNodes: 1500) {
            paks = p
            paksVia = "深扫容器"
        }
        if paks == nil, let hit = LSPaths.searchPaksGlobal() {
            paks = hit.0
            paksVia = "全盘扫描(\(hit.1))"
        }
        guard let paks = paks else {
            finish(ok: false,
                   stage: "容器能打开，但没有 Paks",
                   detail: "容器列得出来，但里面没有 ShadowTrackerExtra/Saved/Paks，也没有任何 .pak。先进游戏进到大厅（资源要跑过一次才落盘），再点一次。")
            sentinel("fail=没有Paks 容器能打开")
            dumpAll(probe)
            return
        }
        log("· Paks 目录：\(paks)（来源：\(paksVia)）")
        sentinel("paks=\(paks) 来源=\(paksVia)")

        // ⑥ 读写验证
        step(0.92, "第六步 · 读写校验", "确认这个目录真的能读、能写")
        sentinel("stage=读写校验")
        let canRead = readable(paks)
        let canWrite = writable(paks)
        let count = LSPaths.listFiles(in: paks, exts: ["pak"], depth: 3).count
        log("· 读：\(canRead ? "可以" : "不行") · 写：\(canWrite ? "可以" : "不行") · 包里 \(count) 个 .pak")
        errno = 0
        _ = try? FileManager.default.contentsOfDirectory(atPath: paks)
        let readErr = errno
        sentinel("读=\(canRead ? "可以" : LSPaths.errnoName(readErr)) 写=\(canWrite ? "可以" : "不行") pak数=\(count)")

        if canRead && canWrite {
            finish(ok: true,
                   stage: "目录已打通",
                   detail: "\(Compatibility.shortSystem()) · 全盘读写已就位 · 找到 \(count) 个 pak。导入、删除都在 App 里点，不用回「文件」")
            sentinel("ok")
        } else if canRead {
            finish(ok: false,
                   stage: "只能读，不能写",
                   detail: "目录读得到（\(count) 个 pak），但写不进去。这台机器只给了只读的访问权。已生成探测和诊断，导出后发我。")
            sentinel("fail=只读")
            dumpAll(probe)
        } else {
            finish(ok: false,
                   stage: "目录进不去",
                   detail: "路径拿到了，但读不进去。已生成探测和诊断，导出后发我。")
            sentinel("fail=读不了")
            dumpAll(probe)
        }
    }

    // MARK: - 辅助

    /// 候选路径里挑第一个真的能读、而且确实是「数据容器」的
    private func firstReadable(_ candidates: String?...) -> String? {
        for c in candidates {
            guard let c = c, SandboxBridge.isDataContainer(c) else { continue }
            if readable(c) { return c }
        }
        return nil
    }

    private func readable(_ path: String) -> Bool {
        guard FileManager.default.fileExists(atPath: path) else { return false }
        if let list = try? FileManager.default.contentsOfDirectory(atPath: path) {
            _ = list
            return true
        }
        return path.withCString { access($0, R_OK) } == 0
    }

    private func writable(_ path: String) -> Bool {
        return path.withCString { access($0, W_OK) } == 0
    }

    private func step(_ p: Double, _ stage: String, _ detail: String) {
        DispatchQueue.main.async {
            self.progress = p
            self.stageText = stage
            self.detailText = detail
        }
    }

    private func finish(ok: Bool, stage: String, detail: String) {
        DispatchQueue.main.async {
            self.phase = ok ? .ready : .failed
            self.stageText = stage
            self.detailText = detail
            self.progress = ok ? 1 : 0
            self.inFlight = false
            self.lastVerdict = stage
            if ok {
                self.appendLog("✓ " + stage)
            } else {
                self.appendLog("✗ " + stage)
            }
            NotificationCenter.default.post(name: Notification.Name("LSAccessChanged"), object: nil)
        }
    }

    // MARK: - 哨兵（黑匣子）

    /// 每一步先落盘再动手：万一被系统拿掉，重开 App 第一行就能看到断在哪
    private func sentinel(_ line: String) {
        let url = LSPaths.docDir().appendingPathComponent("通道哨兵.txt")
        let text = "[\(Fmt.clock())] \(line)\n"
        let fm = FileManager.default
        // 一次新的尝试，文件太长了就清掉重记，别让一份文件翻十屏
        if line == "start" {
            if let attr = try? fm.attributesOfItem(atPath: url.path),
               let size = attr[.size] as? Int, size > 24000 {
                try? fm.removeItem(at: url)
            }
        }
        if !fm.fileExists(atPath: url.path) {
            try? text.write(to: url, atomically: true, encoding: .utf8)
            return
        }
        guard let h = try? FileHandle(forWritingTo: url) else { return }
        h.seekToEndOfFile()
        if let d = text.data(using: .utf8) { h.write(d) }
        h.synchronizeFile()
        try? h.close()
    }

    /// 上次有没有没走完的记录（给界面提示用）
    func lastSentinelLine() -> String? {
        let url = LSPaths.docDir().appendingPathComponent("通道哨兵.txt")
        guard let text = try? String(contentsOf: url, encoding: .utf8) else { return nil }
        let lines = text.split(separator: "\n").map(String.init).filter { !$0.isEmpty }
        guard let last = lines.last else { return nil }
        if last.hasSuffix("ok") || last.hasSuffix("start") { return nil }
        return last
    }

    // MARK: - 日志 / 诊断

    func appendLog(_ s: String) {
        if !Thread.isMainThread {
            DispatchQueue.main.async { [weak self] in self?.appendLog(s) }
            return
        }
        logLines.append(s)
        if logLines.count > 300 { logLines.removeFirst(logLines.count - 300) }
    }

    /// 内部用：带时间戳
    private func log(_ s: String) {
        appendLog("[\(Fmt.clock())] " + s)
    }

    func diagnosticsText() -> String {
        let compat = Compatibility.check()
        var lines: [String] = []
        lines.append("浪神文件管理器 · 通道诊断")
        lines.append("时间：\(Date())")
        lines.append("设备：\(Compatibility.deviceSummary())")
        lines.append("系统判定：\(compat.title) · \(compat.reason)")
        lines.append("路线：\(routeText)")
        lines.append("阶段：\(stageText)")
        lines.append("说明：\(detailText)")
        lines.append("容器：\(containerPath ?? "未拿到")")
        lines.append("持有令牌句柄：\(SandboxBridge.shared.heldHandles.count) 个")
        lines.append("体检结论：\(latestProbe?.verdict.rawValue ?? "未体检")")
        if let rec = lastSentinelLine() { lines.append("上次记录：\(rec)") }
        lines.append("")
        lines.append("---- 通道日志 ----")
        lines.append(contentsOf: logLines.isEmpty ? ["（还没有日志，先点一次「一键打通游戏目录」）"] : logLines)
        return lines.joined(separator: "\n")
    }

    /// 体检报告落盘（只读探测的结果，比日志详细）
    @discardableResult
    func writeProbeFile(_ probe: ProbeReport) -> URL? {
        let url = LSPaths.docDir().appendingPathComponent("通道探测.txt")
        do {
            try probe.text.write(to: url, atomically: true, encoding: .utf8)
            return url
        } catch {
            return nil
        }
    }

    /// 界面上「导出探测报告」按钮用
    @discardableResult
    func exportProbe() -> URL? {
        guard let p = latestProbe else {
            return writeProbeFile(ContainerProbe.shared.run(bundleId: LSPaths.bundleId))
        }
        let url = writeProbeFile(p)
        appendLog("· 探测报告已存到「文件 → 我的 iPhone → 浪神文件管理器 → 通道探测.txt」")
        return url
    }

    /// 失败时把两份都落盘，用户直接导出就行，不用再点两下
    private func dumpAll(_ probe: ProbeReport) {
        writeProbeFile(probe)
        exportDiagnostics()
    }

    @discardableResult
    func exportDiagnostics() -> URL? {
        let url = LSPaths.docDir().appendingPathComponent("通道诊断.txt")
        do {
            try diagnosticsText().write(to: url, atomically: true, encoding: .utf8)
            appendLog("· 诊断已存到「文件 → 我的 iPhone → 浪神文件管理器 → 通道诊断.txt」")
            return url
        } catch {
            appendLog("· 诊断没写出去：\(error.localizedDescription)")
            return nil
        }
    }
}
