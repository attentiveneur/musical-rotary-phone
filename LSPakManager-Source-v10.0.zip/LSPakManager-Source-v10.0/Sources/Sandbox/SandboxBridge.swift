//
//  SandboxBridge.swift
//  免内核通道层：走系统容器服务拿目标 App 容器的访问权
//
//  思路（和 3105 一致）：
//    先按 bundle id 问系统要「容器对象」→ 读容器路径 → 取容器沙盒令牌
//    → 把令牌吃进本进程（sandbox_extension_consume）→ 直接就能读写那棵目录。
//  全程 dlsym 动态取符号：符号在不在、签名变没变，只影响这一步的成败，
//  不会让 App 崩，更不会去动内核。
//

import Foundation
import Darwin
import CoreFoundation

final class SandboxBridge {

    static let shared = SandboxBridge()

    // MARK: - 私有 C 接口签名

    typealias QueryCreate         = @convention(c) () -> UnsafeMutableRawPointer?
    typealias QuerySetIdentifiers = @convention(c) (UnsafeMutableRawPointer?, UnsafeRawPointer?) -> Void
    typealias QueryGetSingle      = @convention(c) (UnsafeMutableRawPointer?) -> UnsafeMutableRawPointer?
    typealias QueryGetSingleErr   = @convention(c) (UnsafeMutableRawPointer?, UnsafeMutablePointer<UnsafeRawPointer?>?) -> UnsafeMutableRawPointer?
    typealias QuerySetClass       = @convention(c) (UnsafeMutableRawPointer?, UInt32) -> Void
    typealias ContainerGetPath    = @convention(c) (UnsafeMutableRawPointer?) -> UnsafeRawPointer?
    typealias ContainerCopyToken  = @convention(c) (UnsafeMutableRawPointer?, UnsafeMutablePointer<Int32>?) -> UnsafeRawPointer?
    typealias ContainerRetain     = @convention(c) (UnsafeMutableRawPointer?) -> UnsafeMutableRawPointer?
    typealias SandboxConsume      = @convention(c) (UnsafePointer<CChar>?) -> Int64

    // MARK: - 结果

    struct OpenResult {
        var path: String?
        var token: String?
        var via: String
        var notes: [String]
        /// 系统只给了「安装包目录」（不是数据目录）时记在这，界面据此说清为什么没打通
        var nonDataPath: String? = nil
        var ok: Bool { path != nil }
    }

    /// 只认数据容器：/var/mobile/Containers/Data/Application/<uuid>
    /// 安装包容器（/var/containers/Bundle/Application/...）里没有 Paks，
    /// 以前把它当成功，路径一错到底，永远找不到游戏资源。
    static func isDataContainer(_ path: String) -> Bool {
        var p = path
        if p.hasPrefix("/private/") { p = String(p.dropFirst("/private".count)) }
        return p.contains("/Containers/Data/Application/")
    }

    // MARK: - 状态

    /// 打通后一直记住，界面刷新时直接用，不再反复问系统
    private(set) var cachedPath: String?
    private(set) var cachedToken: String?
    /// 吃进来的令牌句柄必须一直持有，一释放权限就跟着没了
    private(set) var heldHandles: [Int64] = []

    private var containerLib: UnsafeMutableRawPointer?
    private var sandboxLib: UnsafeMutableRawPointer?

    private init() {}

    // MARK: - 动态库

    private func openContainerLib() -> UnsafeMutableRawPointer? {
        if let h = containerLib { return h }
        let candidates = [
            "/usr/lib/system/libsystem_containermanager.dylib",
            "/usr/lib/libsystem_containermanager.dylib",
            "/System/Library/PrivateFrameworks/MobileContainerManager.framework/MobileContainerManager"
        ]
        for p in candidates {
            if let h = dlopen(p, RTLD_NOW) {
                containerLib = h
                return h
            }
        }
        return nil
    }

    @discardableResult
    private func openSandboxLib() -> UnsafeMutableRawPointer? {
        if let h = sandboxLib { return h }
        for p in ["/usr/lib/system/libsystem_sandbox.dylib",
                  "/usr/lib/libsystem_sandbox.dylib"] {
            if let h = dlopen(p, RTLD_NOW) {
                sandboxLib = h
                return h
            }
        }
        return dlopen(nil, RTLD_NOW)
    }

    private func sym<T>(_ name: String, _ type: T.Type) -> T? {
        guard let h = openContainerLib(), let p = dlsym(h, name) else { return nil }
        return unsafeBitCast(p, to: T.self)
    }

    // MARK: - C 字符串

    /// 容器服务这几个接口返回的是 char *，只按 char * 读，读不到就当没有。
    /// 不做任何指针猜测，宁可这一步失败也不让 App 崩。
    static func cString(_ raw: UnsafeRawPointer?, limit: Int = 8192) -> String? {
        guard let raw = raw else { return nil }
        let bytes = raw.assumingMemoryBound(to: UInt8.self)
        var out = [UInt8]()
        var i = 0
        while i < limit {
            let b = bytes[i]
            if b == 0 { break }
            out.append(b)
            i += 1
        }
        guard !out.isEmpty, out.count < limit else { return nil }
        return String(bytes: out, encoding: .utf8)
    }

    // MARK: - 找容器 + 拿令牌

    /// 按 bundle id 找目标 App 的容器，并把它的沙盒令牌吃进本进程。
    func open(bundleId: String) -> OpenResult {
        var notes: [String] = []

        guard openContainerLib() != nil else {
            return OpenResult(path: nil, token: nil, via: "容器服务不可用", notes: ["容器服务加载不起来"])
        }
        guard let create = sym("container_query_create", QueryCreate.self),
              let setIds = sym("container_query_set_identifiers", QuerySetIdentifiers.self) else {
            return OpenResult(path: nil, token: nil, via: "容器查询接口不可用", notes: ["这台机器上没有容器查询接口"])
        }
        guard create() != nil else {
            return OpenResult(path: nil, token: nil, via: "查询建不起来", notes: ["容器查询对象创建失败"])
        }

        // 传 CFArrayRef 的裸指针（等价于 const void *），最稳，不依赖类型桥接
        let identArray = NSArray(object: bundleId)
        let boxed = Unmanaged.passUnretained(identArray).toOpaque()
        notes.append("按标识查询容器：\(bundleId)")

        let setClass = sym("container_query_set_class", QuerySetClass.self)

        // 同一个 query 只能取一次结果，所以每次都新建一个再问
        func attempt(_ cls: UInt32?) -> UnsafeMutableRawPointer? {
            guard let q = create() else { return nil }
            if let cls = cls, let setClass = setClass { setClass(q, cls) }
            setIds(q, boxed)
            if let getOne = self.sym("container_query_get_single_result", QueryGetSingle.self),
               let c = getOne(q) {
                return c
            }
            if let getOneErr = self.sym("container_query_get_single_result_with_error", QueryGetSingleErr.self) {
                var err: UnsafeRawPointer? = nil
                if let c = getOneErr(q, &err) { return c }
            }
            if let alt = self.sym("container_query_get_result", QueryGetSingle.self),
               let c = alt(q) {
                return c
            }
            return nil
        }

        func pathOf(_ object: UnsafeMutableRawPointer?) -> String? {
            guard let object = object else { return nil }
            if let getPath = self.sym("container_get_path", ContainerGetPath.self),
               let p = Self.cString(getPath(object)) { return p }
            if let copyPath = self.sym("container_copy_path", ContainerGetPath.self),
               let p = Self.cString(copyPath(object)) { return p }
            return nil
        }

        // 只要「数据容器」，别的容器一律跳过。
        // 类别 1 给的是安装包目录（/var/containers/Bundle/Application/...），
        // 那里是 App 本体的安装位置，Paks 不在里面——以前拿它当成功，路径一错到底。
        var container: UnsafeMutableRawPointer? = nil
        var sawNonData: String? = nil

        let loose = attempt(nil)
        if let p = pathOf(loose) {
            if Self.isDataContainer(p) {
                container = loose
                notes.append("不限类别查询命中数据容器")
            } else {
                sawNonData = p
                notes.append("不限类别查询只给到非数据目录（\(p)），继续按类别问")
            }
        }

        if container == nil {
            // 数据容器优先（2 = 数据容器）；1（安装包）放最后，拿到也不用
            for cls in [UInt32(2), 3, 4, 5, 6, 7, 8, 0, 1] {
                let clsArg: UInt32? = (cls == 0) ? nil : cls
                guard let c = attempt(clsArg) else { continue }
                guard let p = pathOf(c) else {
                    notes.append("按容器类别 \(cls) 拿到对象但没路径，跳过")
                    continue
                }
                if Self.isDataContainer(p) {
                    container = c
                    notes.append("按容器类别 \(cls) 命中数据容器")
                    break
                }
                if sawNonData == nil { sawNonData = p }
                notes.append("按容器类别 \(cls) 只给到非数据目录，跳过")
            }
        }

        guard let container = container else {
            if let nd = sawNonData {
                return OpenResult(path: nil, token: nil, via: "只有安装包目录",
                                  notes: notes + ["系统只给了安装包目录：\(nd)",
                                                  "那不是游戏数据目录，Paks 不在里面，所以这条路不算通"],
                                  nonDataPath: nd)
            }
            return OpenResult(path: nil, token: nil, via: "查询没有结果",
                              notes: notes + ["系统没返回这个 App 的容器（游戏没装、或者这台机器不放行）"])
        }
        notes.append("容器对象已拿到")

        // 一直持有容器对象：对象一被回收，租约就跟着失效
        if let retain = sym("container_retain", ContainerRetain.self) {
            _ = retain(container)
            notes.append("容器对象已长期持有")
        }

        var path: String? = nil
        if let getPath = sym("container_get_path", ContainerGetPath.self) {
            path = Self.cString(getPath(container))
        }
        if path == nil, let copyPath = sym("container_copy_path", ContainerGetPath.self) {
            path = Self.cString(copyPath(container))
        }
        if let p = path {
            notes.append("容器路径：\(p)")
        } else {
            notes.append("没读到容器路径")
        }

        var token: String? = nil
        if let copyToken = sym("container_copy_sandbox_token", ContainerCopyToken.self) {
            var code: Int32 = 0
            token = Self.cString(copyToken(container, &code), limit: 16384)
            if let t = token {
                notes.append("令牌长度：\(t.count) 字节")
            } else {
                notes.append("没取到容器令牌（code \(code)）")
            }
        } else {
            notes.append("这台机器没有取令牌的接口")
        }

        if let p = path { cachedPath = p }
        if let t = token { cachedToken = t }

        return OpenResult(path: path, token: token,
                          via: path == nil ? "查询有容器但没路径" : "容器查询 + 令牌",
                          notes: notes)
    }

    // MARK: - 吃令牌

    /// 把令牌交给系统的沙盒服务。返回 >= 0 表示成功，句柄会一直被持有。
    @discardableResult
    func consume(_ token: String) -> Int64 {
        openSandboxLib()
        guard let def = UnsafeMutableRawPointer(bitPattern: -2),
              let p = dlsym(def, "sandbox_extension_consume") else {
            return -1
        }
        let fn = unsafeBitCast(p, to: SandboxConsume.self)
        let handle = token.withCString { fn($0) }
        if handle >= 0 {
            heldHandles.append(handle)
        }
        return handle
    }

    // MARK: - 直连判断

    /// 有些环境（已经被赋予权限 / 越狱环境）本来就能直接读游戏容器，那就一步都不用多做
    func canListContainers() -> Bool {
        let root = "/var/mobile/Containers/Data/Application"
        if let list = try? FileManager.default.contentsOfDirectory(atPath: root), !list.isEmpty {
            return true
        }
        return false
    }

    /// 一次性把缓存清掉（换设备 / 重装后重新走一遍）
    func reset() {
        cachedPath = nil
        cachedToken = nil
        heldHandles.removeAll()
    }
}
