import SwiftUI
import UniformTypeIdentifiers

struct ContentView: View {
    @EnvironmentObject var store: Store
    @ObservedObject private var access = AccessEngine.shared
    @ObservedObject private var kernel = KernelEngine.shared
    @State private var tab = 0
    @State private var showAdvanced = false
    @State private var confirmItem: PakItem? = nil
    @ObservedObject private var ap = Appearance.shared
    @State private var showBg = false
    @State private var showPhotoPicker = false

    var body: some View {
        ZStack {
            BackgroundLayer()

            ScrollView {
                VStack(spacing: 12) {
                    statusCard
                    kernelCard
                    actionGrid
                    switchRow
                    listCard
                    progressCard
                    advancedCard
                    logCard
                }
                .padding(.horizontal, 14)
                .padding(.top, 10)
                .padding(.bottom, 26)
            }
        }
        .preferredColorScheme(.dark)
        .onAppear {
            store.refresh()
            access.silentTry()
        }
        .onChange(of: access.phase) { ph in
            if ph == .ready { store.refresh() }
        }
        .onChange(of: kernel.phase) { ph in
            if ph == .ready { store.refresh() }
        }
        .onChange(of: store.showPicker) { on in
            if on {
                store.showPicker = false
                openPicker()
            }
        }
        .alert("删掉这个包？",
               isPresented: Binding(get: { confirmItem != nil },
                                    set: { if !$0 { confirmItem = nil } })) {
            Button("取消", role: .cancel) { confirmItem = nil }
            Button("删掉", role: .destructive) {
                if let it = confirmItem { store.deleteGameFiles([it]) }
                confirmItem = nil
            }
        } message: {
            Text(confirmItem.map { "\($0.name)\n删前留副本。素材库那份不动，随时能「再导入」" } ?? "")
        }
        .sheet(isPresented: $showBg) {
            bgSheet
        }
    }

    // MARK: - 打开系统文件选择器（.pak 这类自定义后缀也能正常点「打开」）

    private func openPicker() {
        let s = store
        FilePicker.shared.present(onPick: { urls in
            DispatchQueue.main.async {
                if urls.isEmpty {
                    s.log("· 这次没有选中文件（文件夹会灰掉，进到文件夹里选单个文件）")
                } else {
                    s.pickFiles(urls)
                }
            }
        }, onFail: { msg in
            DispatchQueue.main.async { s.pickFailed(msg) }
        })
    }

    // MARK: - 背景面板

    private var bgSheet: some View {
        NavigationView {
            ScrollView {
                VStack(alignment: .leading, spacing: 16) {
                    Text("选一个背景")
                        .font(.system(size: 15, weight: .heavy))
                        .foregroundColor(.white)
                    Text("内置几套现成的，也可以用相册里自己的图。选完自动记住，下次打开还是这个。")
                        .font(.system(size: 11.5))
                        .foregroundColor(.white.opacity(0.45))
                        .fixedSize(horizontal: false, vertical: true)

                    LazyVGrid(columns: [GridItem(.flexible(), spacing: 10),
                                        GridItem(.flexible(), spacing: 10),
                                        GridItem(.flexible(), spacing: 10)],
                              spacing: 12) {
                        ForEach(Appearance.BgStyle.allCases) { s in
                            Button {
                                if s.isPhoto && ap.image == nil {
                                    showPhotoPicker = true
                                } else {
                                    ap.pick(s)
                                }
                            } label: {
                                bgSwatch(s)
                            }
                        }
                    }

                    Divider().background(Color.white.opacity(0.1))

                    Button {
                        showPhotoPicker = true
                    } label: {
                        HStack(spacing: 8) {
                            Image(systemName: "photo.on.rectangle.angled")
                                .font(.system(size: 14, weight: .semibold))
                            Text(ap.image == nil ? "从相册选一张图" : "换一张相册里的图")
                                .font(.system(size: 13, weight: .semibold))
                            Spacer()
                        }
                        .foregroundColor(.white)
                        .padding(.vertical, 12)
                        .padding(.horizontal, 13)
                        .frame(maxWidth: .infinity)
                        .background(Color.white.opacity(0.08))
                        .cornerRadius(11)
                    }

                    if ap.image != nil {
                        VStack(alignment: .leading, spacing: 8) {
                            HStack {
                                Text("压暗程度")
                                    .font(.system(size: 12.5, weight: .semibold))
                                    .foregroundColor(.white.opacity(0.75))
                                Spacer()
                                Text("\(Int(ap.dim * 100))%")
                                    .font(.system(size: 11, design: .monospaced))
                                    .foregroundColor(.white.opacity(0.45))
                            }
                            Slider(value: Binding(get: { ap.dim },
                                                  set: { ap.setDim($0) }),
                                   in: 0.15...0.85)
                                .tint(Color(red: 0.36, green: 0.70, blue: 1.0))
                            Text("图片太亮、字看不清就往上拉；想更透就往左。")
                                .font(.system(size: 10))
                                .foregroundColor(.white.opacity(0.35))
                            Button {
                                ap.clearImage()
                            } label: {
                                Text("删掉这张图")
                                    .font(.system(size: 11.5, weight: .semibold))
                                    .foregroundColor(Color(red: 1, green: 0.45, blue: 0.45))
                            }
                        }
                        .padding(13)
                        .background(Color.white.opacity(0.045))
                        .cornerRadius(12)
                    }
                }
                .padding(16)
            }
            .background(Color(red: 0.06, green: 0.07, blue: 0.10).ignoresSafeArea())
            .navigationTitle("背景")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .navigationBarTrailing) {
                    Button("完成") { showBg = false }
                        .foregroundColor(.cyan)
                }
            }
        }
        .preferredColorScheme(.dark)
        .sheet(isPresented: $showPhotoPicker) {
            PhotoBackgroundPicker { img in
                showPhotoPicker = false
                if let img = img {
                    ap.setImage(img)
                }
            }
        }
    }

    private func bgSwatch(_ s: Appearance.BgStyle) -> some View {
        let picked = ap.style == s
        return VStack(spacing: 6) {
            ZStack {
                if s.isPhoto {
                    if let img = ap.image {
                        Image(uiImage: img)
                            .resizable()
                            .scaledToFill()
                    } else {
                        Color.white.opacity(0.06)
                        Image(systemName: "plus")
                            .font(.system(size: 16, weight: .bold))
                            .foregroundColor(.white.opacity(0.5))
                    }
                } else {
                    LinearGradient(colors: bgPreviewColors(s),
                                   startPoint: .topLeading,
                                   endPoint: .bottomTrailing)
                }
            }
            .frame(height: 62)
            .clipShape(RoundedRectangle(cornerRadius: 10))
            .overlay(
                RoundedRectangle(cornerRadius: 10)
                    .stroke(picked ? Color(red: 0.36, green: 0.70, blue: 1.0) : Color.white.opacity(0.12),
                            lineWidth: picked ? 2 : 1)
            )
            .overlay(
                Group {
                    if picked {
                        Image(systemName: "checkmark.circle.fill")
                            .font(.system(size: 15, weight: .bold))
                            .foregroundColor(Color(red: 0.36, green: 0.70, blue: 1.0))
                            .padding(5)
                    }
                },
                alignment: .topTrailing
            )

            Text(s.title)
                .font(.system(size: 10.5, weight: picked ? .bold : .regular))
                .foregroundColor(picked ? .white : .white.opacity(0.55))
        }
    }

    private func bgPreviewColors(_ s: Appearance.BgStyle) -> [Color] {
        switch s {
        case .deep:
            return [Color(red: 0.05, green: 0.06, blue: 0.08),
                    Color(red: 0.08, green: 0.10, blue: 0.15)]
        case .night:
            return [Color(red: 0.02, green: 0.06, blue: 0.15),
                    Color(red: 0.04, green: 0.11, blue: 0.26)]
        case .forest:
            return [Color(red: 0.02, green: 0.09, blue: 0.07),
                    Color(red: 0.04, green: 0.16, blue: 0.12)]
        case .plum:
            return [Color(red: 0.09, green: 0.03, blue: 0.13),
                    Color(red: 0.16, green: 0.06, blue: 0.22)]
        case .noir:
            return [Color.black, Color(red: 0.04, green: 0.04, blue: 0.05)]
        case .photo:
            return [Color.white.opacity(0.06), Color.white.opacity(0.03)]
        }
    }

    private var activeImportCount: Int {
        store.imported.filter { !$0.deleted }.count
    }

    // MARK: - 顶部

    private var statusCard: some View {
        VStack(alignment: .leading, spacing: 8) {
            HStack(spacing: 10) {
                Text("浪神文件管理器")
                    .font(.system(size: 25, weight: .heavy))
                    .foregroundColor(.white)
                    .lineLimit(1)
                    .minimumScaleFactor(0.7)

                Spacer()

                Button {
                    showBg = true
                } label: {
                    Image(systemName: "photo.on.rectangle.angled")
                        .font(.system(size: 13, weight: .semibold))
                        .foregroundColor(.white.opacity(0.75))
                        .frame(width: 32, height: 30)
                        .background(Color.white.opacity(0.08))
                        .cornerRadius(9)
                }
            }

            HStack(spacing: 6) {
                Image(systemName: store.paksDir == nil ? "exclamationmark.triangle.fill" : "checkmark.circle.fill")
                    .font(.system(size: 13, weight: .bold))
                Text(store.paksDir == nil ? (access.ready ? "目录已打通，但还没定位到游戏目录（点 ④ 全盘找）" : "还没拿到游戏目录 —— 先点下面「一键打通游戏目录」") : "已找到：\(LSPaths.bundleId)")
                    .font(.system(size: 13.5, weight: .semibold))
                    .lineLimit(1)
                    .minimumScaleFactor(0.65)
            }
            .foregroundColor(store.paksDir == nil ? .orange : Color(red: 0.5, green: 0.92, blue: 0.62))

            Text("游戏内 \(store.gameFileCount) 个 · 素材库 \(store.importList.count) 个 · 已导入 \(activeImportCount) 个")
                .font(.system(size: 11.5))
                .foregroundColor(.white.opacity(0.42))
                .lineLimit(2)

            if let b = store.banner {
                Text(b)
                    .font(.system(size: 10.5))
                    .foregroundColor(.white.opacity(0.52))
                    .fixedSize(horizontal: false, vertical: true)
            }
        }
        .frame(maxWidth: .infinity, alignment: .leading)
        .padding(13)
        .background(Color.white.opacity(0.045))
        .cornerRadius(14)
    }

    // MARK: - 内核通道（B 方案：门诊 → 内核 → 摘沙盒）

    private var kernelButtonTitle: String {
        if kernel.ready { return "已打通 · 点这里重跑一次" }
        if kernel.running { return "正在跑…" }
        if kernel.awaitingContinue { return "② 开始内核打通（会动内核）" }
        return "① 先门诊（不碰内核）"
    }

    private var kernelCard: some View {
        VStack(alignment: .leading, spacing: 9) {
            HStack(spacing: 7) {
                Image(systemName: kernel.ready ? "bolt.fill" : "bolt.slash")
                    .font(.system(size: 14, weight: .bold))
                    .foregroundColor(kernel.ready ? Color(red: 0.50, green: 0.92, blue: 0.62)
                                                  : Color(red: 0.98, green: 0.72, blue: 0.30))
                Text("内核通道")
                    .font(.system(size: 14.5, weight: .heavy))
                    .foregroundColor(.white)
                Spacer()
                Text(kernel.stageText)
                    .font(.system(size: 11.5, weight: .semibold))
                    .foregroundColor(kernel.ready ? Color(red: 0.50, green: 0.92, blue: 0.62)
                                                  : Color(red: 0.98, green: 0.72, blue: 0.30))
                    .lineLimit(1)
                    .minimumScaleFactor(0.7)
            }

            Text(kernel.detailText)
                .font(.system(size: 11))
                .foregroundColor(.white.opacity(0.5))
                .fixedSize(horizontal: false, vertical: true)

            Text("\(Compatibility.hardwareModel()) · \(Compatibility.shortSystem()) · 先门诊，只摘一个沙盒指针")
                .font(.system(size: 10, design: .monospaced))
                .foregroundColor(.white.opacity(0.38))

            Text("门诊：\(kernel.probeLine)")
                .font(.system(size: 10))
                .foregroundColor(.white.opacity(0.45))
                .fixedSize(horizontal: false, vertical: true)

            if kernel.patchLevel > 0 {
                Text("走通级别：第 \(kernel.patchLevel) 级（1 最轻 · 3 最重）")
                    .font(.system(size: 10, design: .monospaced))
                    .foregroundColor(Color(red: 0.50, green: 0.92, blue: 0.62).opacity(0.85))
            }

            if !kernel.targetPath.isEmpty {
                Text(kernel.targetPath)
                    .font(.system(size: 9.5, design: .monospaced))
                    .foregroundColor(Color(red: 0.50, green: 0.92, blue: 0.62).opacity(0.8))
                    .lineLimit(1)
                    .truncationMode(.middle)
            }

            if kernel.running {
                ProgressView(value: max(0.02, kernel.progress))
                    .tint(Color(red: 0.36, green: 0.70, blue: 1.0))
            }

            Button {
                if kernel.awaitingContinue {
                    kernel.continueToKernel()
                } else {
                    kernel.activate()
                }
            } label: {
                HStack(spacing: 6) {
                    Image(systemName: kernel.ready ? "arrow.triangle.2.circlepath"
                                                   : (kernel.awaitingContinue ? "bolt.fill" : "stethoscope"))
                        .font(.system(size: 12.5, weight: .bold))
                    Text(kernelButtonTitle)
                        .font(.system(size: 13.5, weight: .bold))
                }
                .foregroundColor(.white)
                .frame(maxWidth: .infinity)
                .padding(.vertical, 11)
                .background(
                    LinearGradient(colors: kernel.ready
                                   ? [Color(red: 0.16, green: 0.45, blue: 0.30), Color(red: 0.12, green: 0.36, blue: 0.26)]
                                   : [Color(red: 0.36, green: 0.24, blue: 0.72), Color(red: 0.24, green: 0.42, blue: 0.86)],
                                   startPoint: .leading, endPoint: .trailing)
                )
                .cornerRadius(11)
            }
            .disabled(kernel.running)

            if !kernel.logLines.isEmpty {
                DisclosureGroup {
                    VStack(alignment: .leading, spacing: 2) {
                        ForEach(Array(kernel.logLines.suffix(60).enumerated()), id: \.offset) { _, line in
                            Text(line)
                                .font(.system(size: 9.5, design: .monospaced))
                                .foregroundColor(.white.opacity(0.45))
                                .frame(maxWidth: .infinity, alignment: .leading)
                        }
                    }
                    .padding(.top, 4)
                } label: {
                    Text("日志（\(kernel.logLines.count) 行）")
                        .font(.system(size: 10.5, weight: .semibold))
                        .foregroundColor(.white.opacity(0.42))
                }
                .tint(.white.opacity(0.4))

                Button {
                    kernel.exportDiagnostics()
                } label: {
                    HStack(spacing: 4) {
                        Image(systemName: "square.and.arrow.up.on.square")
                            .font(.system(size: 10, weight: .bold))
                        Text("导出报告（打通不了就发我这一份）")
                            .font(.system(size: 10.5, weight: .semibold))
                    }
                    .foregroundColor(.white.opacity(0.55))
                    .frame(maxWidth: .infinity, alignment: .leading)
                }
            }
        }
        .frame(maxWidth: .infinity, alignment: .leading)
        .padding(13)
        .background(Color.white.opacity(0.045))
        .cornerRadius(14)
    }

    // MARK: - 目录通道（容器访问权）

    private var accessCard: some View {
        VStack(alignment: .leading, spacing: 9) {
            HStack(spacing: 7) {
                Image(systemName: access.ready ? "folder.fill" : "folder.badge.questionmark")
                    .font(.system(size: 14, weight: .bold))
                    .foregroundColor(access.ready ? Color(red: 0.50, green: 0.92, blue: 0.62)
                                                  : Color(red: 0.98, green: 0.72, blue: 0.30))
                Text("目录通道")
                    .font(.system(size: 14.5, weight: .heavy))
                    .foregroundColor(.white)
                Spacer()
                Text(access.stageText)
                    .font(.system(size: 11.5, weight: .semibold))
                    .foregroundColor(access.ready ? Color(red: 0.50, green: 0.92, blue: 0.62)
                                                  : Color(red: 0.98, green: 0.72, blue: 0.30))
                    .lineLimit(1)
                    .minimumScaleFactor(0.7)
            }

            Text(access.detailText)
                .font(.system(size: 11))
                .foregroundColor(.white.opacity(0.5))
                .fixedSize(horizontal: false, vertical: true)

            Text("\(Compatibility.hardwareModel()) · \(Compatibility.shortSystem()) · 全版本支持")
                .font(.system(size: 10, design: .monospaced))
                .foregroundColor(.white.opacity(0.38))

            Text(access.probeLine)
                .font(.system(size: 10))
                .foregroundColor(.white.opacity(0.45))

            if access.ready, let c = access.containerPath {
                Text(c)
                    .font(.system(size: 9.5, design: .monospaced))
                    .foregroundColor(Color(red: 0.50, green: 0.92, blue: 0.62).opacity(0.8))
                    .lineLimit(1)
                    .truncationMode(.middle)
            }

            if access.running {
                ProgressView(value: max(0.02, access.progress))
                    .tint(Color(red: 0.36, green: 0.70, blue: 1.0))
            }

            Button {
                access.activate()
            } label: {
                HStack(spacing: 6) {
                    Image(systemName: access.ready ? "arrow.triangle.2.circlepath" : "bolt.fill")
                        .font(.system(size: 12.5, weight: .bold))
                    Text(access.ready ? "已打通 · 点这里重跑一次"
                                      : (access.running ? "正在打通…" : "一键打通游戏目录"))
                        .font(.system(size: 13.5, weight: .bold))
                }
                .foregroundColor(.white)
                .frame(maxWidth: .infinity)
                .padding(.vertical, 11)
                .background(
                    LinearGradient(colors: access.ready
                                   ? [Color(red: 0.16, green: 0.45, blue: 0.30), Color(red: 0.12, green: 0.36, blue: 0.26)]
                                   : [Color(red: 0.36, green: 0.24, blue: 0.72), Color(red: 0.24, green: 0.42, blue: 0.86)],
                                   startPoint: .leading, endPoint: .trailing)
                )
                .cornerRadius(11)
            }
            .disabled(access.running)

            if !access.logLines.isEmpty {
                DisclosureGroup {
                    VStack(alignment: .leading, spacing: 2) {
                        ForEach(Array(access.logLines.suffix(40).enumerated()), id: \.offset) { _, line in
                            Text(line)
                                .font(.system(size: 9.5, design: .monospaced))
                                .foregroundColor(.white.opacity(0.45))
                                .frame(maxWidth: .infinity, alignment: .leading)
                        }
                    }
                    .padding(.top, 4)
                } label: {
                    Text("通道日志（\(access.logLines.count) 行）")
                        .font(.system(size: 10.5, weight: .semibold))
                        .foregroundColor(.white.opacity(0.42))
                }
                .tint(.white.opacity(0.4))

                Button {
                    access.exportDiagnostics()
                } label: {
                    HStack(spacing: 4) {
                        Image(systemName: "square.and.arrow.up.on.square")
                            .font(.system(size: 10, weight: .bold))
                        Text("导出诊断日志（打通不了时发我）")
                            .font(.system(size: 10.5, weight: .semibold))
                    }
                    .foregroundColor(.white.opacity(0.55))
                    .frame(maxWidth: .infinity, alignment: .leading)
                }

                Button {
                    access.exportProbe()
                } label: {
                    HStack(spacing: 4) {
                        Image(systemName: "list.bullet.rectangle")
                            .font(.system(size: 10, weight: .bold))
                        Text("导出权限探测（查为什么进不去）")
                            .font(.system(size: 10.5, weight: .semibold))
                    }
                    .foregroundColor(.white.opacity(0.55))
                    .frame(maxWidth: .infinity, alignment: .leading)
                }
            }
        }
        .frame(maxWidth: .infinity, alignment: .leading)
        .padding(13)
        .background(Color.white.opacity(0.045))
        .cornerRadius(14)
    }

    // MARK: - 四个大按钮

    private var actionGrid: some View {
        LazyVGrid(columns: [GridItem(.flexible(), spacing: 9),
                            GridItem(.flexible(), spacing: 9)], spacing: 9) {
            bigButton("① 导入文件", "arrow.down.doc.fill",
                      Color(red: 0.13, green: 0.60, blue: 0.35),
                      store.importList.isEmpty ? "素材库空着，先添加" : "素材库 \(store.importList.count) 个") {
                store.importRun()
            }

            bigButton(store.pendingUndo.isEmpty ? "② 删除导入的" : "② 确认删 \(store.pendingUndo.count) 个",
                      "trash.fill",
                      store.pendingUndo.isEmpty
                        ? Color(red: 0.40, green: 0.18, blue: 0.19)
                        : Color(red: 0.68, green: 0.20, blue: 0.22),
                      store.pendingUndo.isEmpty
                        ? (activeImportCount > 0 ? "\(activeImportCount) 条记录" : "还没导入过")
                        : "点一下真删，先备份") {
                if store.pendingUndo.isEmpty { store.undoScan() } else { store.undoRun() }
            }

            bigButton("③ 添加文件", "square.and.arrow.down",
                      Color(red: 0.16, green: 0.37, blue: 0.72),
                      "选一次就够，永久留着") {
                store.showPicker = true
            }

            bigButton("④ 全盘找 pak", "magnifyingglass",
                      Color(red: 0.35, green: 0.26, blue: 0.70),
                      store.scanNote.isEmpty ? "看看游戏里都有啥" : store.scanNote) {
                tab = 2
                store.fullScan()
            }
        }
    }

    private func bigButton(_ title: String, _ icon: String, _ color: Color,
                           _ sub: String, _ action: @escaping () -> Void) -> some View {
        Button(action: action) {
            VStack(alignment: .leading, spacing: 4) {
                HStack(spacing: 5) {
                    Image(systemName: icon).font(.system(size: 13, weight: .bold))
                    Text(title)
                        .font(.system(size: 13, weight: .bold))
                        .lineLimit(1)
                        .minimumScaleFactor(0.65)
                }
                Text(sub)
                    .font(.system(size: 9.5))
                    .opacity(0.65)
                    .lineLimit(1)
            }
            .foregroundColor(.white)
            .frame(maxWidth: .infinity, alignment: .leading)
            .padding(.horizontal, 12)
            .padding(.vertical, 14)
            .background(color)
            .cornerRadius(13)
        }
        .disabled(store.busy)
    }

    // MARK: - 开关

    private var switchRow: some View {
        HStack(spacing: 9) {
            chip(store.undoKeepCopy ? "备份：开" : "备份：关",
                 "externaldrive.fill",
                 store.undoKeepCopy ? .green : .gray) {
                store.undoKeepCopy.toggle()
            }
            chip(store.undoRestoreBackup ? "还原原件：开" : "还原原件：关",
                 "arrow.uturn.backward",
                 store.undoRestoreBackup ? .green : .gray) {
                store.undoRestoreBackup.toggle()
            }
            chip("刷新", "arrow.clockwise", .cyan) {
                store.refresh()
            }
        }
    }

    private func chip(_ t: String, _ icon: String, _ c: Color,
                      _ act: @escaping () -> Void) -> some View {
        Button(action: act) {
            HStack(spacing: 5) {
                Image(systemName: icon).font(.system(size: 11, weight: .semibold))
                Text(t)
                    .font(.system(size: 11.5, weight: .medium))
                    .lineLimit(1)
                    .minimumScaleFactor(0.75)
            }
            .foregroundColor(c)
            .frame(maxWidth: .infinity)
            .padding(.vertical, 10)
            .background(c.opacity(0.12))
            .cornerRadius(10)
        }
        .disabled(store.busy)
    }

    private func smallButton(_ t: String, _ icon: String, _ c: Color,
                             _ act: @escaping () -> Void) -> some View {
        Button(action: act) {
            HStack(spacing: 5) {
                Image(systemName: icon).font(.system(size: 11, weight: .semibold))
                Text(t).font(.system(size: 10.5)).lineLimit(1).minimumScaleFactor(0.75)
            }
            .foregroundColor(.white.opacity(0.8))
            .frame(maxWidth: .infinity)
            .padding(.vertical, 9)
            .background(Color.white.opacity(0.07))
            .cornerRadius(10)
        }
        .disabled(store.busy)
    }

    // MARK: - 素材库 / 已导入 / 游戏里的包

    private var listCard: some View {
        VStack(alignment: .leading, spacing: 9) {
            HStack(spacing: 0) {
                tabButton("素材库 \(store.importList.count)", 0)
                tabButton("已导入 \(activeImportCount)", 1)
                tabButton("游戏里的包 \(store.scanFound.count)", 2)
            }
            .padding(3)
            .background(Color.white.opacity(0.06))
            .cornerRadius(10)

            if tab == 0 {
                if store.importList.isEmpty {
                    emptyHint("素材库是空的。点「③ 添加文件」选一次就行——选完永久留着，以后游戏里删多少次都不用再选")
                } else {
                    ForEach(Array(store.importList.prefix(60)), id: \.id) { f in
                        rowWaiting(f)
                    }
                    if store.importList.count > 60 {
                        Text("…… 还有 \(store.importList.count - 60) 个")
                            .font(.system(size: 10))
                            .foregroundColor(.white.opacity(0.3))
                    }
                }
            } else if tab == 1 {
                if store.imported.isEmpty {
                    emptyHint("还没有导入记录。点「① 导入文件」，导进去的会自动记账，这里能撤、也能再导入")
                } else {
                    ForEach(Array(store.imported.prefix(60))) { r in
                        rowImported(r)
                    }
                    if store.imported.count > 60 {
                        Text("…… 还有 \(store.imported.count - 60) 条")
                            .font(.system(size: 10))
                            .foregroundColor(.white.opacity(0.3))
                    }
                }
            } else {
                if store.scanFound.isEmpty {
                    emptyHint("点「④ 全盘找 pak」扫一遍。扫出来的包都在这儿列着，一个个挑着删，不按关键字乱删")
                } else {
                    ForEach(Array(store.scanFound.prefix(80))) { it in
                        rowGame(it)
                    }
                    if store.scanFound.count > 80 {
                        Text("…… 还有 \(store.scanFound.count - 80) 个")
                            .font(.system(size: 10))
                            .foregroundColor(.white.opacity(0.3))
                    }
                }
            }

            HStack(spacing: 9) {
                smallButton("认领已导入的", "tray.and.arrow.down.fill", .teal) {
                    store.adoptParked()
                }
                smallButton("清掉失效记录", "bandage.fill", .orange) {
                    store.pruneRecords()
                }
            }
        }
        .padding(12)
        .background(Color.white.opacity(0.045))
        .cornerRadius(14)
    }

    private func tabButton(_ t: String, _ idx: Int) -> some View {
        Button(action: { tab = idx }) {
            Text(t)
                .font(.system(size: 12.5, weight: .semibold))
                .foregroundColor(tab == idx ? .white : .white.opacity(0.4))
                .frame(maxWidth: .infinity)
                .padding(.vertical, 8)
                .background(tab == idx ? Color.white.opacity(0.13) : Color.clear)
                .cornerRadius(8)
        }
    }

    private func emptyHint(_ t: String) -> some View {
        Text(t)
            .font(.system(size: 10.5))
            .foregroundColor(.white.opacity(0.32))
            .frame(maxWidth: .infinity, alignment: .leading)
            .padding(.vertical, 8)
            .fixedSize(horizontal: false, vertical: true)
    }

    private func rowWaiting(_ f: PakItem) -> some View {
        HStack(spacing: 8) {
            Image(systemName: "doc.fill")
                .font(.system(size: 11))
                .foregroundColor(.white.opacity(0.3))
            VStack(alignment: .leading, spacing: 1) {
                Text(f.name)
                    .font(.system(size: 12.5, weight: .medium))
                    .foregroundColor(.white.opacity(0.9))
                    .lineLimit(1)
                    .truncationMode(.middle)
                Text("\(f.sizeText) · 素材库里")
                    .font(.system(size: 9.5))
                    .foregroundColor(.white.opacity(0.35))
                    .lineLimit(1)
                    .truncationMode(.middle)
            }
            Spacer()
            Button(action: { store.importFromVault([f]) }) {
                Text("导")
                    .font(.system(size: 10, weight: .semibold))
                    .foregroundColor(.green)
                    .padding(.horizontal, 11)
                    .padding(.vertical, 5)
                    .background(Color.green.opacity(0.16))
                    .cornerRadius(7)
            }
            .disabled(store.busy)
        }
        .padding(.vertical, 5)
        .padding(.horizontal, 9)
        .background(Color.white.opacity(0.035))
        .cornerRadius(9)
    }

    private func rowImported(_ r: ImportRecord) -> some View {
        HStack(spacing: 8) {
            Image(systemName: r.deleted ? "xmark.square" : (r.statusOK ? "checkmark.square.fill" : "questionmark.square"))
                .font(.system(size: 11))
                .foregroundColor(r.deleted ? .white.opacity(0.25) : (r.statusOK ? .green : .orange))
            VStack(alignment: .leading, spacing: 1) {
                Text(r.name)
                    .font(.system(size: 12.5, weight: .medium))
                    .foregroundColor(.white.opacity(r.deleted ? 0.45 : 0.9))
                    .lineLimit(1)
                    .truncationMode(.middle)
                Text("\(r.sizeText) · \(r.statusText) · \(r.time)")
                    .font(.system(size: 9.5))
                    .foregroundColor(.white.opacity(0.35))
                    .lineLimit(1)
            }
            Spacer()
            if r.deleted {
                Button(action: { store.redoOne(r) }) {
                    Text("再导入")
                        .font(.system(size: 10, weight: .semibold))
                        .foregroundColor(.cyan)
                        .padding(.horizontal, 9)
                        .padding(.vertical, 5)
                        .background(Color.cyan.opacity(0.14))
                        .cornerRadius(7)
                }
                .disabled(store.busy)
            } else {
                Button(action: { store.undoOne(r) }) {
                    Text("撤")
                        .font(.system(size: 10, weight: .semibold))
                        .foregroundColor(Color(red: 1, green: 0.42, blue: 0.42))
                        .padding(.horizontal, 10)
                        .padding(.vertical, 5)
                        .background(Color.red.opacity(0.16))
                        .cornerRadius(7)
                }
                .disabled(store.busy)
            }
        }
        .padding(.vertical, 5)
        .padding(.horizontal, 9)
        .background(Color.white.opacity(0.035))
        .cornerRadius(9)
    }

    private func rowGame(_ it: PakItem) -> some View {
        HStack(spacing: 8) {
            Image(systemName: it.ext == "sig" ? "signature" : "shippingbox.fill")
                .font(.system(size: 11))
                .foregroundColor(.white.opacity(0.3))
            VStack(alignment: .leading, spacing: 1) {
                Text(it.name)
                    .font(.system(size: 12.5, weight: .medium))
                    .foregroundColor(.white.opacity(0.9))
                    .lineLimit(1)
                    .truncationMode(.middle)
                Text("\(it.sizeText) · .\(it.ext) · \(tailPath(it.id, "Paks"))")
                    .font(.system(size: 9.5))
                    .foregroundColor(.white.opacity(0.35))
                    .lineLimit(1)
                    .truncationMode(.middle)
            }
            Spacer()
            Button(action: { confirmItem = it }) {
                Text("删")
                    .font(.system(size: 10, weight: .semibold))
                    .foregroundColor(Color(red: 1, green: 0.42, blue: 0.42))
                    .padding(.horizontal, 10)
                    .padding(.vertical, 5)
                    .background(Color.red.opacity(0.16))
                    .cornerRadius(7)
            }
            .disabled(store.busy)
        }
        .padding(.vertical, 5)
        .padding(.horizontal, 9)
        .background(Color.white.opacity(0.035))
        .cornerRadius(9)
    }

    private func tailPath(_ p: String, _ marker: String) -> String {
        if let r = p.range(of: "/" + marker + "/") {
            return marker + "/" + String(p[r.upperBound...])
        }
        return (p as NSString).lastPathComponent
    }

    // MARK: - 进度

    @ViewBuilder
    private var progressCard: some View {
        if store.busy {
            VStack(alignment: .leading, spacing: 6) {
                ProgressView(value: store.progressValue)
                    .progressViewStyle(LinearProgressViewStyle(tint: .green))
                Text(store.progressText)
                    .font(.system(size: 10, design: .monospaced))
                    .foregroundColor(.white.opacity(0.5))
            }
            .padding(12)
            .background(Color.white.opacity(0.045))
            .cornerRadius(12)
        }
    }

    // MARK: - 改字（进阶，折叠）

    private var advancedCard: some View {
        VStack(alignment: .leading, spacing: 8) {
            Button(action: {
                withAnimation(.easeInOut(duration: 0.15)) { showAdvanced.toggle() }
            }) {
                HStack(spacing: 6) {
                    Image(systemName: "textformat")
                        .font(.system(size: 11, weight: .bold))
                        .foregroundColor(.white.opacity(0.55))
                    Text("改字（进阶 · 跟导入无关）")
                        .font(.system(size: 12, weight: .semibold))
                        .foregroundColor(.white.opacity(0.62))
                    Spacer()
                    Image(systemName: showAdvanced ? "chevron.up" : "chevron.down")
                        .font(.system(size: 11, weight: .bold))
                        .foregroundColor(.white.opacity(0.35))
                }
            }

            if showAdvanced {
                Text("等长替换：新字不能比原字长，不然包会坏。这里改的是游戏里的包本身")
                    .font(.system(size: 9.5))
                    .foregroundColor(.white.opacity(0.3))
                    .fixedSize(horizontal: false, vertical: true)

                ForEach(store.rules) { r in
                    HStack(spacing: 8) {
                        Button(action: { store.toggleRule(r) }) {
                            Image(systemName: r.enabled ? "checkmark.circle.fill" : "circle")
                                .font(.system(size: 16))
                                .foregroundColor(r.enabled ? .green : .white.opacity(0.22))
                        }
                        VStack(alignment: .leading, spacing: 1) {
                            Text(r.old)
                                .font(.system(size: 12, weight: .medium))
                                .foregroundColor(.white.opacity(0.88))
                                .lineLimit(1)
                            Text("改成：\(r.new)")
                                .font(.system(size: 9.5))
                                .foregroundColor(.white.opacity(0.4))
                                .lineLimit(1)
                        }
                        Spacer()
                        Button(action: { store.deleteRule(r) }) {
                            Image(systemName: "xmark.circle.fill")
                                .font(.system(size: 14))
                                .foregroundColor(.white.opacity(0.2))
                        }
                    }
                    .padding(.vertical, 5)
                    .padding(.horizontal, 9)
                    .background(Color.white.opacity(0.035))
                    .cornerRadius(9)
                }

                HStack(spacing: 6) {
                    field("原文", $store.newOld)
                    field("新文", $store.newNew)
                    Button(action: { store.addRule() }) {
                        Image(systemName: "plus")
                            .font(.system(size: 13, weight: .bold))
                            .foregroundColor(.white)
                            .frame(width: 36, height: 32)
                            .background(Color.blue.opacity(0.35))
                            .cornerRadius(8)
                    }
                    .disabled(store.busy)
                }

                HStack(spacing: 9) {
                    smallButton("全自动改字", "bolt.fill", .green) { store.autoRun() }
                    smallButton("改本机的包", "doc.on.doc.fill", .blue) { store.localRun() }
                }
                HStack(spacing: 9) {
                    chip(store.previewMode ? "只看不改：开" : "只看不改：关",
                         store.previewMode ? "eye.fill" : "eye.slash",
                         store.previewMode ? .orange : .gray) { store.previewMode.toggle() }
                    chip(store.backupOn ? "改前备份：开" : "改前备份：关",
                         "externaldrive.fill",
                         store.backupOn ? .green : .gray) { store.backupOn.toggle() }
                }
                if let b = store.backups.first {
                    chip("还原最近一次备份（\(b.files.count) 个）",
                         "clock.arrow.circlepath",
                         .orange) { store.restore(b) }
                }
            }
        }
        .padding(12)
        .background(Color.white.opacity(0.045))
        .cornerRadius(14)
    }

    private func field(_ ph: String, _ binding: Binding<String>) -> some View {
        TextField(ph, text: binding)
            .font(.system(size: 12))
            .foregroundColor(.white)
            .padding(.horizontal, 9)
            .padding(.vertical, 8)
            .background(Color.white.opacity(0.07))
            .cornerRadius(8)
            .autocapitalization(.none)
            .disableAutocorrection(true)
    }

    // MARK: - 运行记录

    private var logCard: some View {
        VStack(alignment: .leading, spacing: 0) {
            HStack {
                Text("运行记录")
                    .font(.system(size: 12, weight: .semibold))
                    .foregroundColor(.white.opacity(0.55))
                Spacer()
                Button(action: { store.logs.removeAll() }) {
                    Text("清空").font(.system(size: 10)).foregroundColor(.white.opacity(0.35))
                }
            }
            .padding(.bottom, 5)

            ScrollViewReader { proxy in
                ScrollView {
                    VStack(alignment: .leading, spacing: 2) {
                        ForEach(Array(store.logs.indices), id: \.self) { idx in
                            Text(store.logs[idx])
                                .font(.system(size: 9.5, design: .monospaced))
                                .foregroundColor(color(for: store.logs[idx]))
                                .frame(maxWidth: .infinity, alignment: .leading)
                                .id(idx)
                        }
                    }
                    .padding(8)
                }
                .frame(height: 200)
                .background(Color.black.opacity(0.4))
                .cornerRadius(10)
                .onChange(of: store.logs.count) { _ in
                    if let last = store.logs.indices.last {
                        withAnimation(.easeOut(duration: 0.12)) {
                            proxy.scrollTo(last, anchor: .bottom)
                        }
                    }
                }
            }
        }
    }

    private func color(for line: String) -> Color {
        if line.contains("✗") || line.contains("⚠️") { return Color(red: 1, green: 0.45, blue: 0.45) }
        if line.contains("✓") || line.contains("完成") { return Color(red: 0.5, green: 0.92, blue: 0.62) }
        if line.contains("====") { return Color(red: 0.55, green: 0.75, blue: 1) }
        return Color.white.opacity(0.55)
    }
}
