//
//  MHAChannel.m
//  Filza 同款容器通道的实现。
//
//  拆了 Filza Mod 4.0 的包，它访问别的 App 目录靠的是这几步（顺序不能乱）：
//    1. container_query_create                    建查询
//    2. container_query_set_class                 指定容器类别
//    3. container_query_set_identifiers           按 bundle id 查
//    4. container_query_operation_set_flags       设查询标志
//    5. container_query_get_single_result_with_error
//    6. container_object_get_path                 取路径
//    7. container_object_copy_sandbox_token       取令牌
//    8. container_object_sandbox_extension_activate  ← 关键：必须这一步，目录才真开得动
//
//  它自己的签名里一个私有特权都没有（就是普通企业证书），
//  能成是因为进程身份是 com.apple.mobile.MobileHouseArrest —— 这层身份我们也有。
//  之前一直卡在 6/7 用了老 API 名字、且漏了 8。
//
//  本文件按 -fno-objc-arc 编（工程里单独给开关），所以不写 ARC 的持有语义。
//

#import <Foundation/Foundation.h>
#import <CoreFoundation/CoreFoundation.h>
#import <xpc/xpc.h>
#import <dlfcn.h>
#import <fcntl.h>
#import <unistd.h>
#import <dirent.h>
#import <errno.h>
#import <string.h>
#import <stdio.h>
#import <stdarg.h>
#import <sys/stat.h>

#import "MHAChannel.h"

// MARK: - 函数签名

typedef void *      (*fn_query_create)(void);
typedef void        (*fn_query_set_class)(void *query, uint64_t cls);
typedef void        (*fn_query_set_identifiers)(void *query, void *identifiers);
typedef void        (*fn_query_set_group_identifiers)(void *query, void *identifiers);
typedef void        (*fn_query_set_flags)(void *query, uint64_t flags);
typedef void        (*fn_query_set_part)(void *query, uint64_t part);
typedef void        (*fn_query_set_part_domain)(void *query, uint64_t domain);
typedef void *      (*fn_query_get_single)(void *query);
typedef void *      (*fn_query_get_single_err)(void *query, void **error);
typedef void        (*fn_query_free)(void *query);
typedef char *      (*fn_object_get_path)(void *object);
typedef char *      (*fn_object_get_identifier)(void *object);
typedef char *      (*fn_object_copy_token)(void *object);
typedef bool        (*fn_object_activate)(void *object);
typedef void *      (*fn_object_copy)(void *object);
typedef void        (*fn_object_free)(void *object);
typedef char *      (*fn_error_get_message)(void *error);
typedef int         (*fn_error_get_errno)(void *error);
typedef long long   (*fn_sandbox_consume)(const char *token);

// 全部用 void * 存符号地址，调用时再转成具体函数指针。
// 这样 dlsym 的返回值不用做非法隐式转换，符号缺了也只是指针为 0，不会编不过。
typedef struct {
    void *lib;
    void *create;
    void *setClass;
    void *setIds;
    void *setGroups;
    void *setFlags;
    void *setPart;
    void *setPartDomain;
    void *getOne;
    void *getOneErr;
    void *freeQuery;
    void *getPath;
    void *getIdentifier;
    void *copyToken;
    void *activate;
    void *copyObject;
    void *freeObject;
    void *errMessage;
    void *errErrno;
    void *consume;
} LSMApi;

static LSMApi gApi;
static bool gLoaded = false;
// 拿到的对象不能释放：一释放，激活的那份访问权跟着失效
static void *gHeldObjects[64];
static int gHeldCount = 0;

static void *lsSym(void *lib, const char *name) {
    void *p = dlsym(lib, name);
    return p;
}

static void lsLoad(void) {
    if (gLoaded) return;
    gLoaded = true;

    const char *paths[] = {
        "/usr/lib/system/libsystem_containermanager.dylib",
        "/usr/lib/libsystem_containermanager.dylib",
        "/System/Library/PrivateFrameworks/MobileContainerManager.framework/MobileContainerManager",
    };
    void *lib = NULL;
    for (int i = 0; i < 3 && !lib; i++) {
        lib = dlopen(paths[i], RTLD_NOW);
    }
    if (!lib) lib = dlopen(NULL, RTLD_NOW);
    if (!lib) return;
    gApi.lib = lib;

#define LS_BIND(field, name) gApi.field = lsSym(lib, name)
    LS_BIND(create,       "container_query_create");
    LS_BIND(setClass,     "container_query_set_class");
    LS_BIND(setIds,       "container_query_set_identifiers");
    LS_BIND(setGroups,    "container_query_set_group_identifiers");
    LS_BIND(setFlags,     "container_query_operation_set_flags");
    LS_BIND(setPart,      "container_query_operation_set_part");
    LS_BIND(setPartDomain, "container_query_operation_set_part_domain");
    LS_BIND(freeQuery,    "container_query_free");

    // 两代名字都在：object_* 是新接口（iOS 16+ 主用），老名字留着兜底
    gApi.getOne    = lsSym(lib, "container_query_get_single_result");
    gApi.getOneErr = lsSym(lib, "container_query_get_single_result_with_error");

    gApi.getPath       = (void *)lsSym(lib, "container_object_get_path");
    gApi.getIdentifier = (void *)lsSym(lib, "container_object_get_identifier");
    gApi.copyToken     = (void *)lsSym(lib, "container_object_copy_sandbox_token");
    gApi.activate      = (void *)lsSym(lib, "container_object_sandbox_extension_activate");
    gApi.copyObject    = (void *)lsSym(lib, "container_object_copy");
    gApi.freeObject    = (void *)lsSym(lib, "container_object_free");

    gApi.errMessage  = (void *)lsSym(lib, "container_error_get_message");
    gApi.errErrno    = (void *)lsSym(lib, "container_error_get_posix_errno");
#undef LS_BIND

    void *sbx = dlopen("/usr/lib/system/libsystem_sandbox.dylib", RTLD_NOW);
    if (!sbx) sbx = dlopen("/usr/lib/libsystem_sandbox.dylib", RTLD_NOW);
    if (!sbx) sbx = dlopen(NULL, RTLD_NOW);
    gApi.consume = (void *)lsSym(sbx, "sandbox_extension_consume");
}

/// 字符串安全写进缓冲，超长截断，永远留结尾 0
static void lsPut(char *buf, size_t len, const char *fmt, ...) {
    if (!buf || len == 0) return;
    va_list ap;
    va_start(ap, fmt);
    vsnprintf(buf, len, fmt, ap);
    va_end(ap);
}

/// 往摘要后面追加，不覆盖前面写的
static void lsAppend(char *buf, size_t len, const char *fmt, ...) {
    if (!buf || len == 0) return;
    size_t used = strlen(buf);
    if (used + 2 >= len) return;
    va_list ap;
    va_start(ap, fmt);
    vsnprintf(buf + used, len - used, fmt, ap);
    va_end(ap);
}

bool LSMHAIsDataContainer(const char *path) {
    if (!path || !*path) return false;
    const char *p = path;
    if (strncmp(p, "/private/", 9) == 0) p += 8;
    return strstr(p, "/Containers/Data/Application/") != NULL;
}

/// 目录能不能真列出来（能拿到路径 ≠ 能读）
static bool lsListable(const char *path) {
    if (!path || !*path) return false;
    DIR *d = opendir(path);
    if (!d) return false;
    closedir(d);
    return true;
}

/// 真写一个探针文件再删掉。不是 access(W_OK) 那种模糊判断
static bool lsWriteProbe(const char *path, char *why, size_t whyLen) {
    if (!path || !*path) return false;
    char tmp[4096];
    snprintf(tmp, sizeof(tmp), "%s/.ls-wprobe-%d", path, (int)getpid());
    int fd = open(tmp, O_CREAT | O_WRONLY | O_TRUNC, 0644);
    if (fd < 0) {
        lsPut(why, whyLen, "写探针打不开（errno %d %s）", errno, strerror(errno));
        return false;
    }
    ssize_t n = write(fd, "ok", 2);
    fsync(fd);
    close(fd);
    unlink(tmp);
    if (n != 2) {
        lsPut(why, whyLen, "写探针写不进（errno %d %s）", errno, strerror(errno));
        return false;
    }
    return true;
}

static int lsCountItems(const char *path) {
    DIR *d = opendir(path);
    if (!d) return -1;
    int n = 0;
    struct dirent *e;
    while ((e = readdir(d)) != NULL) {
        if (strcmp(e->d_name, ".") == 0 || strcmp(e->d_name, "..") == 0) continue;
        n++;
        if (n > 5000) break;
    }
    closedir(d);
    return n;
}

static void lsHoldObject(void *obj) {
    if (!obj) return;
    if (gHeldCount < 64) gHeldObjects[gHeldCount++] = obj;
}

static void lsErrText(void *err, char *buf, size_t len) {
    if (!buf || len == 0) return;
    buf[0] = 0;
    if (!err) return;
    if (gApi.errMessage) {
        char *m = ((fn_error_get_message)gApi.errMessage)(err);
        if (m && *m) {
            lsPut(buf, len, "%s", m);
            return;
        }
    }
    if (gApi.errErrno) {
        int e = ((fn_error_get_errno)gApi.errErrno)(err);
        if (e != 0) {
            lsPut(buf, len, "errno %d（%s）", e, strerror(e));
            return;
        }
    }
    lsPut(buf, len, "系统没给原因");
}

/// 容器类别。2 = App 数据容器（Paks 在里面）。
/// 其余按 Filza 的做法全试一遍——不同系统上同一个 App 的容器可能落在别的类别里。
static const uint64_t kClasses[LS_MHA_CLASS_COUNT] = { 2, 3, 7, 10, 12, 13, 15, 4, 6, 1 };

/// 查询一次的完整过程，成功返回容器对象，失败返回 NULL
static void *lsQueryOnce(const char *bundleId,
                         uint64_t cls,
                         uint64_t flags,
                         bool useGroups,
                         char *why, size_t whyLen) {
    if (!gApi.create || !gApi.setIds) {
        lsPut(why, whyLen, "容器查询接口缺失");
        return NULL;
    }
    void *q = ((fn_query_create)gApi.create)();
    if (!q) {
        lsPut(why, whyLen, "查询对象建不起来");
        return NULL;
    }

    if (gApi.setClass) ((fn_query_set_class)gApi.setClass)(q, cls);

    // 标识传 xpc 数组：这是容器服务内部真正认的类型
    xpc_object_t ids = xpc_array_create(NULL, 0);
    if (ids) {
        xpc_array_append_value(ids, xpc_string_create(bundleId));
        if (useGroups && gApi.setGroups) {
            ((fn_query_set_group_identifiers)gApi.setGroups)(q, ids);
        } else {
            ((fn_query_set_identifiers)gApi.setIds)(q, ids);
        }
    } else {
        CFStringRef s = CFStringCreateWithCString(NULL, bundleId, kCFStringEncodingUTF8);
        CFArrayRef arr = CFArrayCreate(NULL, (const void **)&s, 1, &kCFTypeArrayCallBacks);
        ((fn_query_set_identifiers)gApi.setIds)(q, (void *)arr);
        if (arr) CFRelease(arr);
        if (s) CFRelease(s);
    }

    if (gApi.setFlags) ((fn_query_set_flags)gApi.setFlags)(q, flags);

    void *obj = NULL;
    void *err = NULL;
    if (gApi.getOneErr) {
        obj = ((fn_query_get_single_err)gApi.getOneErr)(q, &err);
    } else if (gApi.getOne) {
        obj = ((fn_query_get_single)gApi.getOne)(q);
    }

    if (!obj && err) {
        char msg[256];
        lsErrText(err, msg, sizeof(msg));
        lsPut(why, whyLen, "类别 %llu/标志 0x%llx：%s", (unsigned long long)cls,
              (unsigned long long)flags, msg);
    } else if (!obj) {
        lsPut(why, whyLen, "类别 %llu/标志 0x%llx：没有结果", (unsigned long long)cls,
              (unsigned long long)flags);
    }

    // 查询对象用完就放，容器对象另外持有
    if (gApi.freeQuery) ((fn_query_free)gApi.freeQuery)(q);
    return obj;
}

/// 对一个容器对象：取路径 → 取令牌 → 激活 → 验证
static bool lsActivateObject(void *obj, char *outPath, size_t outLen, bool wantWrite,
                             char *why, size_t whyLen) {
    if (!obj) return false;

    char *path = NULL;
    if (gApi.getPath) path = ((fn_object_get_path)gApi.getPath)(obj);

    // 新接口没有就退回老名字（老系统上 object_* 可能不存在）
    if (!path && gApi.lib) {
        fn_object_get_path oldPath = (fn_object_get_path)dlsym(gApi.lib, "container_get_path");
        if (!oldPath) oldPath = (fn_object_get_path)dlsym(gApi.lib, "container_copy_path");
        if (oldPath) path = oldPath(obj);
    }
    if (!path || !*path) {
        lsPut(why, whyLen, "对象拿到了但没路径");
        return false;
    }
    if (!LSMHAIsDataContainer(path)) {
        lsPut(why, whyLen, "只给到非数据容器：%s", path);
        return false;
    }

    // 令牌 → 先自己 consume 一遍（老系统靠这条），再让容器对象激活（新系统靠这条）
    bool activated = false;
    if (gApi.copyToken) {
        char *token = ((fn_object_copy_token)gApi.copyToken)(obj);
        if (token && *token && gApi.consume) {
            long long h = ((fn_sandbox_consume)gApi.consume)(token);
            if (h >= 0) activated = true;
        }
    }
    if (gApi.activate) {
        if (((fn_object_activate)gApi.activate)(obj)) activated = true;
    }

    bool listable = lsListable(path);
    if (!listable) {
        lsPut(why, whyLen, "路径有了但目录打不开（激活%@）", activated ? "已发出" : "没成功");
        return false;
    }

    int items = lsCountItems(path);
    if (wantWrite) {
        char w[256] = {0};
        if (!lsWriteProbe(path, w, sizeof(w))) {
            lsPut(why, whyLen, "目录可列（%d 项）但只读：%s", items, w);
            return false;
        }
        lsPut(why, whyLen, "目录可列可写（%d 项）", items);
    } else {
        lsPut(why, whyLen, "目录可列（%d 项）", items);
    }

    lsHoldObject(obj);
    lsPut(outPath, outLen, "%s", path);
    return true;
}

bool LSMHAOpenContainer(const char *bundleId,
                        char *outPath, size_t outLen,
                        bool wantWrite,
                        char *outReason, size_t reasonLen) {
    if (outPath && outLen) outPath[0] = 0;
    if (outReason && reasonLen) outReason[0] = 0;
    if (!bundleId || !*bundleId) {
        lsPut(outReason, reasonLen, "没给 bundle id");
        return false;
    }

    lsLoad();
    if (!gApi.lib) {
        lsPut(outReason, reasonLen, "容器服务加载不起来");
        return false;
    }
    if (!gApi.create) {
        lsPut(outReason, reasonLen, "容器查询接口不存在");
        return false;
    }

    // 先报一下接口齐不齐，缺哪个一眼看出来
    lsAppend(outReason, reasonLen, "接口：");
    lsAppend(outReason, reasonLen, "query%s ", gApi.create ? "✓" : "✗");
    lsAppend(outReason, reasonLen, "ids%s ", gApi.setIds ? "✓" : "✗");
    lsAppend(outReason, reasonLen, "path%s ", gApi.getPath ? "✓" : "✗");
    lsAppend(outReason, reasonLen, "token%s ", gApi.copyToken ? "✓" : "✗");
    lsAppend(outReason, reasonLen, "activate%s ", gApi.activate ? "✓" : "✗");
    lsAppend(outReason, reasonLen, "consume%s\n", gApi.consume ? "✓" : "✗");

    char firstListable[4096] = {0};

    // 两轮标识类型：xpc 数组 / 组标识。第二轮是给某些系统上按组查才认的情况
    for (int mode = 0; mode < 2; mode++) {
        bool useGroups = (mode == 1);
        if (useGroups && !gApi.setGroups) continue;

        for (int i = 0; i < LS_MHA_CLASS_COUNT; i++) {
            uint64_t cls = kClasses[i];
            // 标志位：0 是标准；1 是 Filza 里也试过的那档（放开限制查询）
            uint64_t flagList[2] = { 0, 1 };
            for (int f = 0; f < 2; f++) {
                char why[512] = {0};
                void *obj = lsQueryOnce(bundleId, cls, flagList[f], useGroups, why, sizeof(why));
                if (!obj) {
                    lsAppend(outReason, reasonLen, "· %s%s\n", why, useGroups ? "（按组）" : "");
                    continue;
                }

                char p[4096] = {0};
                char detail[512] = {0};
                bool ok = lsActivateObject(obj, p, sizeof(p), wantWrite, detail, sizeof(detail));
                lsAppend(outReason, reasonLen, "· 类别 %llu%s：%s\n",
                         (unsigned long long)cls, useGroups ? "（按组）" : "", detail);

                if (ok) {
                    lsPut(outPath, outLen, "%s", p);
                    return true;
                }

                // 不能写但能列：记下来当兜底，继续找能写的
                if (p[0] && firstListable[0] == 0 && lsListable(p)) {
                    snprintf(firstListable, sizeof(firstListable), "%s", p);
                }
            }
        }
    }

    if (firstListable[0]) {
        lsPut(outPath, outLen, "%s", firstListable);
        lsAppend(outReason, reasonLen, "→ 有能列的目录，但写不进去（只读）\n");
        return true;
    }

    lsAppend(outReason, reasonLen, "→ 所有类别都没打开\n");
    return false;
}

bool LSMHAVerifyPath(const char *path, bool wantWrite, char *outReason, size_t reasonLen) {
    if (outReason && reasonLen) outReason[0] = 0;
    if (!path || !*path) {
        lsPut(outReason, reasonLen, "没给路径");
        return false;
    }
    bool listable = lsListable(path);
    int n = listable ? lsCountItems(path) : -1;
    if (!listable) {
        lsPut(outReason, reasonLen, "目录打不开（errno %d %s）", errno, strerror(errno));
        return false;
    }
    if (!wantWrite) {
        lsPut(outReason, reasonLen, "可列（%d 项）", n);
        return true;
    }
    char w[256] = {0};
    bool wr = lsWriteProbe(path, w, sizeof(w));
    lsPut(outReason, reasonLen, "可列（%d 项）· %s", n, wr ? "可写" : w);
    return wr;
}

int LSMHACountVisibleContainers(void) {
    return lsCountItems("/var/mobile/Containers/Data/Application");
}
