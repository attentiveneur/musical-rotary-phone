//
//  MHAChannel.h
//  照 Filza 那条路：直接问系统的容器服务要目标 App 容器的「令牌」并当场激活。
//
//  和之前那几层的区别（这就是一直不通的原因）：
//    旧代码用的是 container_get_path / container_copy_path 这套老名字。
//    iOS 16 之后容器服务把对象接口整组改名成 container_object_*，
//    而且真正能让目录「开得动」的是 container_object_sandbox_extension_activate，
//    不是自己拿字符串去 consume。少这一下，路径能打出来，目录照样是 Permission denied。
//
//  这条路做的事，全部是读 + 申请访问权：
//    查询容器对象 → 取路径 → 取令牌 → 激活 → 验证能不能列、能不能写。
//    不写内核、不改系统文件、不动页表。
//

#ifndef MHAChannel_h
#define MHAChannel_h

#include <stdbool.h>
#include <stddef.h>

#ifdef __cplusplus
extern "C" {
#endif

/// 容器类别（MCM 的编号）
/// 2 = App 数据容器（游戏的 Paks 在这里）
/// 7 = App 组  10 = 服务数据  12 = 系统数据  13 = 分区数据  15 = 受保护数据
/// 3 / 4 / 6 = 别的扩展容器，留着兜底
#define LS_MHA_CLASS_COUNT 10

/// 按 bundle id 打开目标 App 的数据容器。
///
/// @param bundleId   目标 App 的 bundle id
/// @param outPath    成功的路径写这里（调用方给缓冲）
/// @param outLen     outPath 的字节数
/// @param wantWrite  是否要求「能写」（真写一个探针文件再删掉，不做假判断）
/// @param outReason  失败原因 / 过程摘要写这里
/// @param reasonLen  outReason 的字节数
/// @return 成功拿到路径并验证通过返回 true
bool LSMHAOpenContainer(const char *bundleId,
                        char *outPath, size_t outLen,
                        bool wantWrite,
                        char *outReason, size_t reasonLen);

/// 把一个已经拿到的路径追加到诊断里：能列吗、能写吗、有多少项。
/// 只读检查 + 一个写探针（写完立刻删），失败也不留垃圾。
bool LSMHAVerifyPath(const char *path, bool wantWrite,
                     char *outReason, size_t reasonLen);

/// 这个进程当前被允许访问哪些容器（诊断用，不申请新权限）
int LSMHACountVisibleContainers(void);

/// 路径是不是 App 的数据容器（不是安装包容器）
bool LSMHAIsDataContainer(const char *path);

#ifdef __cplusplus
}
#endif

#endif /* MHAChannel_h */
