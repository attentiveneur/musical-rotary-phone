//
//  KernelEngine.swift  (v10.2)
//  内核通道：门诊 → 内核读写 → 布局校准 → 沙盒门诊 → 认槽 → 摘沙盒 → 真写入验证
//
//  设计原则（照 3105 的做法来）：
//   1. 先试免内核那条路：容器访问权本来就有，就直接收工，一个内核字节都不碰。
//   2. 真要走内核，先门诊：所有校验都是只读的，结构对不上就停，不写一个字节。
//   3. 补丁分三级，能从最小的一级通过就不往上加；每级都真去开一次游戏目录验证。
//   4. 三级都不通 → 把写过的字节全部回滚，内核恢复原样，再报结论。
//

import Foundation
import UIKit
import Darwin
import Combine

private let engineLogCallback: @convention(c) (UnsafePointer<CChar>?) -> Void = { msg in
    guard let msg = msg else { return }
    let s = String(cString: msg)
    DispatchQueue.main.async { KernelEngine.shared.appendLog("· " + s) }
}

private let engineProgressCallback: @convention(c) (Double) -> Void = { p in
    DispatchQueue.main.async { KernelEngine.shared.setProgress(p) }
}

private let engineSbxLogCallback: @convention(c) (UnsafePointer<CChar>?) -> Void = { msg in
    guard let msg = msg else { return }
    let s = String(cString: msg)
    DispatchQueue.main.async { KernelEngine.shared.appendLog("· " + s) }
}

/// v9.6：把门诊结果装进引用类型里。
/// Swift 的并发检查不允许在后台闭包里改外层 var，用个盒子装就干净了。
private final class ProbeBox {
    var p = sxs_probe_t()
    var pr: Int32 = -1
}

/// 同上：后台闭包要回传一个 Bool 结果，用盒子装避免并发捕获告警。
private final class ResultBox {
    var value = false
}

final class KernelEngine: ObservableObject {

    static let shared = KernelEngine()

    enum Phase: Equatable {
        case idle
        case running
        case partial   // 门诊跑完了，还没动内核
        case ready
        case failed
    }

    @Published private(set) var phase: Phase = .idle
    @Published private(set) var stageText: String = "未激活"
    @Published private(set) var detailText: String = "点一下：先门诊，再过内核，只摘一个沙盒指针"
    @Published private(set) var progress: Double = 0
    @Published private(set) var logLines: [String] = []
    @Published private(set) var kernelBase: UInt64 = 0
    @Published private(set) var offsetsReady: Bool = false
    /// 门诊结论（结构自洽 / 哪一层对不上）
    @Published private(set) var probeLine: String = "还没门诊"
    /// 走通的补丁级别：0 没走通，1/2/3 对应补丁级别
    @Published private(set) var patchLevel: Int = 0
    /// 打通的游戏目录
    @Published private(set) var targetPath: String = ""
    /// 门诊跑完、等用户决定要不要真的动内核
    @Published private(set) var awaitingContinue = false

    // MARK: - v12.3 内核双通道（按大版本分档，小版本全收）

    /// 一条内核通道对应一个大版本档位。两个档位各自独立记账、独立出结果。
    /// 注意：档位按「大版本」划分，不再认具体小版本号 ——
    /// iOS 26 系列下 26.0 / 26.1 … 26.6.1 / 26.6.2 / 26.9 全部落在 26 档，
    /// 27 及以上全部落在 27 档，永远不会出现「这台机器的系统不在按钮里」。
    struct KernelProfile: Identifiable, Equatable {
        let id: String          // "26" / "27"
        /// 按钮主标题
        var title: String { "iOS \(id).x" }
        /// 按钮上的覆盖范围说明
        var range: String {
            id == "27" ? "27 起含更高" : "26 全系"
        }
        /// 日志里用的档位名
        var logName: String { id == "27" ? "iOS 27 及以上" : "iOS 26 全系" }
    }

    /// 界面上那两个按钮：iOS 26.x 全系 / iOS 27.x 及以上全系
    static let availableProfiles: [KernelProfile] = [
        KernelProfile(id: "26"),
        KernelProfile(id: "27")
    ]

    /// 档位 id → 日志里的说法
    static func profileLogName(_ id: String) -> String {
        availableProfiles.first(where: { $0.id == id })?.logName ?? "iOS \(id) 全系"
    }

    /// 这一轮点的是哪个版本档位（空 = 自动按本机系统匹配）
    @Published private(set) var activeProfile: String = ""
    /// 每个档位各自的结果：未试 / 正在跑 / 已打通 / 跑过未通
    @Published private(set) var profileResult: [String: String] = [:]

    private var inFlight = false
    private(set) var cautious = false
    private var hung = false
    private var watchdog: DispatchSourceTimer?
    /// v11.1：门诊里五条容器通道的逐条结论。报告里单独一节，通了/卡在哪一眼看清。
    private(set) var containerNotes: [String] = []

    private(set) var lastCrashRecord: String?
    private(set) var lastRunTail: String?

    private init() {
        let docPath = LSPaths.docDir().path
        docPath.withCString { cg_install($0) }
        // v9.3：哨兵里只区分两种 ——
        //   CRASH=真崩了（有信号名和地址）
        //   其它=上一轮是中断/被系统强杀，没崩也留下了 RUNNING
        // 以前一律当「上次没走完」，结果卡住一次就永久降档，越降越难成。
        var lastWasCrash = false
        if let rec = cg_take_last_record() {
            let s = String(cString: rec)
            lastCrashRecord = s
            lastWasCrash = s.hasPrefix("CRASH")
            free(rec)
        }
        cg_finish()

        // v10.1：进程要是被系统直接掐掉（SIGKILL），哨兵一个字都留不下 ——
        // 那种情况下唯一能说明「停在哪一步」的，就是上一次日志的最后一行。
        lastRunTail = KernelEngine.tailOfLog(LSPaths.docDir().appendingPathComponent("lara.log"))

        let major = ProcessInfo.processInfo.operatingSystemVersion.majorVersion
        cautious = lastWasCrash || major == 18
    }

    /// 只取最后一行非空内容，不把整份日志读进来
    static func tailOfLog(_ url: URL) -> String? {
        guard let data = try? Data(contentsOf: url, options: .mappedIfSafe),
              !data.isEmpty else { return nil }
        let bytes = [UInt8](data.suffix(8192))
        let text = String(decoding: bytes, as: UTF8.self)
        let last = text
            .split(separator: "\n", omittingEmptySubsequences: true)
            .last
            .map(String.init)
        guard let line = last?.trimmingCharacters(in: .whitespaces), !line.isEmpty else { return nil }
        return line
    }

    var running: Bool { phase == .running }
    var ready: Bool { phase == .ready }

    var deviceLine: String {
        let d = UIDevice.current
        return "\(d.model) · iOS \(d.systemVersion)"
    }

    // MARK: - 对外动作

    /// 第一步：只跑门诊。全程不碰内核，不会重启。（自动档）
    func activate() { start(profile: nil) }

    /// v12.3：点的是大版本档位按钮（26 全系 / 27 起含更高）。
    /// 门诊过了就直接按这个版本的偏移集进内核，不用再点第二下。
    func activate(profile: String) { start(profile: profile) }

    /// 本机系统落在大版本里的哪一档：26 → "26"，27 及以上（28、29…）→ "27"。
    /// 15/16/17/18 这类 26 以下的机器返回空 = 走通用那一套（不拦、照跑）。
    private func autoProfileForThisDevice() -> String {
        let v = ProcessInfo.processInfo.operatingSystemVersion
        if v.majorVersion >= 27 { return "27" }
        if v.majorVersion == 26 { return "26" }
        return ""
    }

    private func start(profile: String?) {
        guard !inFlight else { return }
        if hung {
            phase = .failed
            stageText = "上一次卡住了"
            detailText = "上一次卡在里面没返回。杀掉 App 重开，再点一次（记录已经存下来了）。"
            appendLog("✗ 上一次卡住，本次不再启动新的流水线")
            return
        }

        inFlight = true
        phase = .running
        awaitingContinue = false
        hung = false
        progress = 0
        kernelBase = 0
        offsetsReady = false
        patchLevel = 0
        setTarget("")
        setProbe("门诊中…")
        stageText = "门诊中"
        detailText = "只读检查，这一步不碰内核，不会重启"
        logLines.removeAll()

        let picked = profile ?? autoProfileForThisDevice()
        activeProfile = picked
        if !picked.isEmpty { profileResult[picked] = "正在跑" }

        appendLog("设备：\(Compatibility.deviceSummary())")
        if picked.isEmpty {
            appendLog("内核档位：自动（本机系统在 26 以下，走通用偏移；26 及以上的机器会自动落到对应大版本档）")
        } else if profile == nil {
            appendLog("内核档位：\(KernelEngine.profileLogName(picked))（按本机系统自动匹配，该大版本下所有小版本通用）")
        } else {
            appendLog("内核档位：\(KernelEngine.profileLogName(picked))（你点的这个按钮，该大版本下所有小版本通用）")
        }
        appendLog("内存：可用 \(cg_available_mb()) MB / 物理 \(cg_physical_mb()) MB")

        // v10.1：这一行回答「上次到底停在哪」。被系统掐掉时，这是唯一的现场。
        if let tail = lastRunTail {
            appendLog("上次日志停在这一行：" + tail)
        }

        if let last = lastCrashRecord {
            let oneLine = last
                .replacingOccurrences(of: "\n", with: " ")
                .trimmingCharacters(in: .whitespaces)
            if oneLine.hasPrefix("CRASH") {
                appendLog("⚠ 上次是真崩溃：" + oneLine)
                cautious = true
            } else {
                appendLog("上次是中断（不是崩溃）：" + oneLine)
            }
        }

        ds_set_safe_mode(cautious ? 1 : 0)
        appendLog(cautious ? "档位：保守（真崩溃过 / 18 系列）" : "档位：标准")
        appendLog("日志规则：每次开跑先把上一份日志改名 lara.prev.log，lara.log 只装本次运行")
        appendLog("第一步只做门诊；门诊结果出来了，你再决定要不要动内核")

        cg_beat()
        ds_set_log_callback(engineLogCallback)
        ds_set_progress_callback(engineProgressCallback)
        sbx_setlogcallback(engineSbxLogCallback)
        startWatchdog()

        let worker = Thread { [weak self] in
            self?.runCheckup()
        }
        worker.stackSize = 8 * 1024 * 1024
        worker.qualityOfService = .userInitiated
        worker.start()
    }

    /// 第二步：门诊看过了，真动内核。这一步只有你点了才会跑。
    func continueToKernel() {
        guard !inFlight, phase == .partial else { return }
        inFlight = true
        phase = .running
        awaitingContinue = false
        stageText = "内核写入中"
        detailText = "这一步会动内核，中途可能会重启一次；重启了就重开 App 看报告"
        appendLog("继续：开始内核这一段")
        cg_beat()
        startWatchdog()

        let worker = Thread { [weak self] in
            self?.runKernel()
        }
        worker.stackSize = 16 * 1024 * 1024
        worker.qualityOfService = .userInitiated
        worker.start()
    }

    private func markStep(_ stage: String) {
        stage.withCString { cg_mark($0) }
    }

    // MARK: - 主流程

    // MARK: - 容器通道梯子（v11.1 · 全程零内核）

    private func noteContainer(_ s: String) {
        containerNotes.append(s)
        appendLog("· " + s)
    }

    /// 先跑完所有「不碰内核」的通道，通了就当场收工。
    /// 返回 true = 已打通，调用方必须立刻 return，绝不许再落地到内核。
    private func runContainerLadder() -> Bool {
        containerNotes.removeAll()
        update(stage: "通道", detail: "先跑不碰内核的通道：容器查询 / 令牌 / 租约 / 容器类 / 元数据")
        let bid = LSPaths.bundleId

        // ① 容器查询 + 沙盒令牌
        let q = SandboxBridge.shared.open(bundleId: bid)
        q.notes.forEach { noteContainer($0) }
        if let t = q.token {
            let h = SandboxBridge.shared.consume(t)
            noteContainer(h >= 0 ? "令牌：已吞进本进程（句柄 \(h)，全程持有）"
                                 : "令牌：系统不收（返回 \(h)）")
        }

        // ② 容器租约 —— 3105 走的就是这条
        let lease = SandboxBridge.shared.openViaLease(bundleId: bid)
        lease.notes.forEach { noteContainer($0) }

        // ③ 容器类直取
        let app = SandboxBridge.shared.openViaAppContainer(bundleId: bid)
        app.notes.forEach { noteContainer($0) }

        // ④ 谁给出「列得出来」的数据容器，就按谁往下验
        var cands: [(String, String)] = []
        if let p = lease.path { cands.append((p, lease.via)) }
        if let p = app.path { cands.append((p, app.via)) }
        if let p = q.path { cands.append((p, q.via)) }
        if let p = LSPaths.scanGameContainer() { cands.append((p, "元数据扫描")) }

        for (p, via) in cands {
            guard SandboxBridge.isDataContainer(p) else {
                noteContainer("候选[\(via)] 不是数据容器，跳过")
                continue
            }
            let items = (try? FileManager.default.contentsOfDirectory(atPath: p))?.count
            noteContainer("候选[\(via)] 能列=" + (items == nil ? "否" : "是（\(items!) 项）") + " · \(p)")
            guard items != nil else { continue }

            // 能列只是第一步：真去 Paks 里建文件、写一字节、删掉，建删都过才算真通
            let v = verifyContainer(p)
            noteContainer("候选[\(via)] 验真：\(v.text)")
            guard v.ok, let paks = v.path else { continue }

            setTarget(paks)
            cg_finish()
            noteContainer("通道打通 ✅ 走的是「\(via)」")
            finishReady(note: "容器通道已打通（\(via)）· 内核一个字节都没碰")
            return true
        }

        noteContainer("五条容器通道全不通：直连 / 容器查询+令牌 / 租约 / 容器类 / 元数据扫描")
        return false
    }

    /// 验一棵「已经拿到访问权的容器」：Paks 在不在、能不能列、能不能真写。
    /// 不能用 verifyTarget()：它先要求整个容器根目录可列，而租约/令牌这条通道
    /// 只给我们目标 App 这一棵，根目录照样 EPERM —— 用它会把真通的判成不通。
    private func verifyContainer(_ container: String) -> (ok: Bool, path: String?, text: String) {
        var paks = LSPaths.paksDir(container: container)
        var via = "固定路径"
        if paks == nil, let p = LSPaths.searchPaksDir(under: container, depth: 5, maxNodes: 1500) {
            paks = p
            via = "深扫容器"
        }
        guard let paks = paks else {
            return (false, nil, "容器能列，但里面没有 ShadowTrackerExtra/Saved/Paks（先进游戏到大厅再来一次）")
        }
        let n = openCount(paks)
        if n < 0 {
            return (false, nil, "Paks 打不开（\(errnoText(sxs_errno()))）")
        }
        let probe = (paks as NSString).appendingPathComponent(".ls_write_probe")
        let wrote = realWriteTest(probe)
        let text = "Paks 能列 \(n) 项（\(via)）· 真实写入：\(wrote ? "成" : "败")"
        return (wrote, paks, text)
    }

    // MARK: - 段 0：门诊（纯用户态，绝对不碰内核）

    private func runCheckup() {
        markStep("门诊")
        update(stage: "门诊", detail: "只读检查，这一步不碰内核")

        let pac = isPacRuntime()
        appendLog("架构：\(pac ? "arm64e（带 PAC）" : "arm64（不带 PAC）")")

        // v12.0：这条通道全靠「冒充容器服务的身份」。签名工具一改 bundle id，
        // 后面五条通道全部白给，而且从外面完全看不出来。这里第一行就把它亮出来。
        let myId = Bundle.main.bundleIdentifier ?? "(读不到)"
        appendLog("本 App 身份：" + myId)
        if myId == "com.apple.mobile.MobileHouseArrest" {
            appendLog("身份正确：系统会把我当容器服务，通道有戏")
        } else {
            appendLog("身份被改掉了 —— 应该是 com.apple.mobile.MobileHouseArrest")
            appendLog("原因：签名时勾了「修改 bundle id」，或被签名工具自动改。这条通道全靠它")
        }

        // 快路：容器访问权本来就有 → 直接收工，一个内核字节都不碰
        let rootCount = openCount(LSPaths.containerRoot)
        if rootCount >= 0 {
            appendLog("快路：数据容器根目录能列（\(rootCount) 项），根本不用碰内核")
            setProbe("容器访问权本来就有，跳过内核")
            cg_finish()
            finishReady(note: "容器访问权本来就有 —— 一个内核字节都没碰")
            return
        }
        appendLog("快路：数据容器根目录打不开（\(errnoText(sxs_errno()))），先走不碰内核的通道")

        // v11.1：这里原来是洞。
        // v11.0 把容器租约那几条通道写进了 AccessEngine，但门诊压根没调用它 ——
        // 只试了「根目录能不能列」一个动作就直接宣布「得走内核」，
        // 所以上一份报告里才会出现「凭证路线：还没跑过 / 可写区判定：还没判定」。
        // 现在门诊先把五条不碰内核的通道全跑一遍，通了当场收工，一个内核字节都不碰。
        if runContainerLadder() { return }

        appendLog("通道全试完都不通，下面才轮到内核（这台机器内核读原语实测很弱，能不通就不碰）")

        if !pac {
            setProbe("架构是 arm64，读不了内核指针")
            fail("这版得是 arm64e 才能读内核指针",
                 detail: "当前 App 是 arm64 架构，内核指针带签名还原不了。这属于打包问题，导出报告发我。")
            return
        }

        let major = ProcessInfo.processInfo.operatingSystemVersion.majorVersion
        if major >= 18 {
            appendLog("系统是 iOS \(major) 系列：自动按保守档跑，改动量降到最低")
        }

        // 磁盘余量：抓内核缓存要几十兆
        if let attrs = try? FileManager.default.attributesOfFileSystem(forPath: LSPaths.docDir().path),
           let free = attrs[.systemFreeSize] as? NSNumber {
            let mb = free.int64Value / 1048576
            appendLog("可用空间：\(mb) MB")
            if mb < 200 {
                appendLog("⚠ 空间不太够，抓内核缓存可能失败，建议先清一点")
            }
        }

        setProbe("容器通道全被挡 · 按点选的版本进内核")
        setProgressMain(0.15)
        cg_finish()
        DispatchQueue.main.async {
            self.stopWatchdog()
            self.phase = .partial
            self.awaitingContinue = true
            self.inFlight = false
            self.stageText = "通道全挡 · 准备进内核"
            let tag = self.activeProfile.isEmpty ? "通用偏移" : "\(KernelEngine.profileLogName(self.activeProfile)) 偏移集"
            self.detailText = "五条不碰内核的通道全被挡住（结论在报告里）。按 \(tag) 继续进内核，中途可能重启一次。"
            self.appendLog("门诊结束：容器通道全挡 ✅ 五条都跑了，结论在报告「容器通道」那一节")
            if !self.activeProfile.isEmpty {
                self.appendLog("按 \(KernelEngine.profileLogName(self.activeProfile)) 继续 → 马上进内核（可能重启，重启后重开 App 看报告）")
                self.continueToKernel()
            } else {
                self.appendLog("自动档：不自动动内核。要跑内核就点上面 iOS 26.x 和 iOS 27.x 两个按钮里的一个")
            }
        }
    }

    /// v9.7：内核缓存是不是完整的 —— IMG4 的头两个字节一定是 30 84。
    /// 上次下载被强杀留下的半截文件过不了这一关，绝不拿它去喂解析器。
    private func isKernelCacheIntact(_ path: String) -> Bool {
        guard let h = FileHandle(forReadingAtPath: path) else { return false }
        defer { try? h.close() }
        let head = h.readData(ofLength: 2)
        guard head.count == 2 else { return false }
        let b = [UInt8](head)
        return b[0] == 0x30 && b[1] == 0x84
    }

    // MARK: - 段 1~5：内核

    /// v9.6：带超时 + 心跳的后台执行。
    /// 上一版就是死在没有这个东西上：dlkcache 是个同步调用，联网下载内核缓存几十兆，
    /// 中间不打心跳、不报进度、也不知道要等多久，界面上就一行「读取内核配置」干等。
    /// 现在把它丢到后台，主线程边等边打心跳，到点就放弃，绝不让整条流程陪它耗。
    private func runWithBeats(_ seconds: Double, _ name: String, _ work: @escaping () -> Bool) -> Bool {
        let box = ResultBox()
        let sem = DispatchSemaphore(value: 0)
        DispatchQueue.global(qos: .userInitiated).async {
            box.value = work()
            sem.signal()
        }
        let deadline = Date().addingTimeInterval(seconds)
        var ticks = 0
        while Date() < deadline {
            if sem.wait(timeout: .now() + 0.2) == .success {
                return box.value
            }
            cg_beat()
            ticks += 1
            if ticks % 25 == 0 {
                let left = Int(deadline.timeIntervalSinceNow)
                appendLog("· \(name) 还在跑，已等 \(Int(seconds) - left) 秒（最多 \(Int(seconds)) 秒）")
            }
        }
        appendLog("⚠ \(name) 超过 \(Int(seconds)) 秒没回来，不等了，继续往下走")
        return false
    }

    // MARK: - 写入次数（防止拿同一招无限重启）

    private func attemptFileURL() -> URL {
        LSPaths.docDir().appendingPathComponent("写入次数.txt")
    }

    func kernelAttemptCount() -> Int {
        // v11.1：这个计数以前是跨版本累计的 —— 上一版点过 3 次，装上新的就
        // 直接判「本版已经跑过 3 次」，内核这一段等于被人堵死在门口。
        // 现在存成「版本:次数」，换了版本自动从 0 算起。
        guard let s = try? String(contentsOf: attemptFileURL(), encoding: .utf8) else { return 0 }
        let t = s.trimmingCharacters(in: .whitespacesAndNewlines)
        guard let colon = t.firstIndex(of: ":") else { return 0 }   // 旧格式（纯数字）= 别的版本留下的
        guard String(t[..<colon]) == attemptKey else { return 0 }
        return Int(t[t.index(after: colon)...]) ?? 0
    }

    /// v12.3：计数按「版本 + 档位」分开算 —— 26 档点满 3 次，不影响 27 档那边。
    private var attemptKey: String {
        activeProfile.isEmpty ? buildVersion : "\(buildVersion)-\(activeProfile)"
    }

    private func bumpKernelAttempt() -> Int {
        let n = kernelAttemptCount() + 1
        try? "\(attemptKey):\(n)".write(to: attemptFileURL(), atomically: true, encoding: .utf8)
        return n
    }

    private var buildVersion: String {
        (Bundle.main.infoDictionary?["CFBundleShortVersionString"] as? String) ?? "0"
    }

    private func resetKernelAttempt() {
        try? "\(attemptKey):0".write(to: attemptFileURL(), atomically: true, encoding: .utf8)
    }

    private func runKernel() {
        let attempts = bumpKernelAttempt()
        appendLog("本版第 \(attempts) 次点开始（同一版最多 3 次）")
        if !activeProfile.isEmpty {
            appendLog("本次按 \(KernelEngine.profileLogName(activeProfile)) 这一档跑：该大版本下所有小版本走同一条路，偏移靠本机内核缓存解析 + 实测校准，不套死表")
        }
        if attempts > 3 {
            fail("这一版已经跑过 3 次，不再往下写",
                 detail: "同一版连续 3 次都没成，就不要再拿同一个路子试了。杀掉 App 重开，把报告导出给我 —— 报告里的「槽扫描」「可写区判定」「沙盒自检」三行就是下一步的靶子。")
            return
        }

        // ---- 段 1：内核读写 ----
        markStep("载入偏移")
        offsets_init()

        markStep("内核读写")
        update(stage: "内核读写", detail: "正在扫物理内存；每 1024 页会在日志里报一次进度")
        setProgressMain(0.08)
        let r = ds_run()
        guard r == 0, ds_is_ready() else {
            setProbe("内核读写没成功")
            fail("内核读写没成功（返回 \(r)）",
                 detail: "漏洞利用没通。杀 App 重开再点一次；连点两三次都不行就是这台机器这条利用暂时没覆盖到。导出报告发我。")
            return
        }
        let kb = ds_get_kernel_base()
        DispatchQueue.main.async { self.kernelBase = kb }
        appendLog(String(format: "内核基址：0x%llx", kb))
        setProgressMain(0.35)

        // ---- 段 2：布局校准（只读）----
        markStep("核对本机内核")
        update(stage: "核对本机内核", detail: "先确认进程结构对得上，再去取内核配置")
        let pre = OffsetsDoctor.preflight { line in
            DispatchQueue.main.async { self.appendLog(line) }
        }
        for n in pre.notes { appendLog("· " + n) }
        if pre.adjusted > 0 { appendLog("预检校准 \(pre.adjusted) 处偏移") }
        guard pre.ok else {
            setProbe("进程结构对不上")
            fail("这台机器的进程结构和已知布局对不上",
                 detail: "刚拿到内核读写就发现结构不一致，这时候往下写就是拿整机冒险，所以停在这里。点「导出报告」发我。")
            return
        }

        // ---- 段 2.5：内核缓存（v9.7：可选 + 先验真伪，绝不阻塞）----
        // v9.6 把它从必经之路摘下来了，但还留了个洞：只要有 1MB 以上就直接拿去解析。
        // v9.5 那次下载是被强杀的，十有八九在 Documents 里留下一份半截文件 ——
        // 半截的内核缓存喂给解析器，轻则白等 30 秒，重则在里面踩到坏数据把整个 App 带走。
        // 所以这一版先看文件头：IMG4 一定是 30 84，不是就当场删掉、直接跳过。
        markStep("读取内核配置")
        update(stage: "读取内核配置", detail: "可取可不取；拿不到也能继续打通，最多等 20 秒")
        var ok = false

        let cachedPath = LSPaths.docDir().appendingPathComponent("kernelcache").path
        var cachedSize = 0
        if FileManager.default.fileExists(atPath: cachedPath),
           let attrs = try? FileManager.default.attributesOfItem(atPath: cachedPath),
           let sz = attrs[.size] as? NSNumber {
            cachedSize = sz.intValue
        }

        var usableCache = false
        if cachedSize > 1024 * 1024 {
            appendLog("本机有个内核缓存文件 \(cachedSize / 1048576) MB，先验一下是不是完整的")
            if isKernelCacheIntact(cachedPath) {
                usableCache = true
            } else {
                appendLog("这份不完整（上次下载被打断留下的半截），删掉，这一步直接跳过")
                try? FileManager.default.removeItem(atPath: cachedPath)
            }
        } else if cachedSize > 0 {
            appendLog("本机那份只有 \(cachedSize / 1024) KB，是半截，删掉")
            try? FileManager.default.removeItem(atPath: cachedPath)
        }

        if usableCache {
            appendLog("本机已有完整内核缓存，直接解析（最多等 20 秒）")
            ok = runWithBeats(20, "解析已缓存的内核缓存") { dlkcache() }
            if !ok {
                // 解析不成就把文件清掉，否则下次还在同一处白等一遍
                try? FileManager.default.removeItem(atPath: cachedPath)
                appendLog("这份缓存解析不了，已删掉，下次不再拿它试")
            }
        } else {
            appendLog("跳过内核缓存 · 沙盒补丁不依赖它：proc→ucred→label→sandbox 全程现场自校准")
            appendLog("不抓了 · 本机抓取要动系统分区，用不上就不碰")
        }
        DispatchQueue.main.async { self.offsetsReady = ok }
        if ok {
            appendLog("内核缓存到手，顺带做一次布局核对")
            setProgressMain(0.55)
        } else {
            appendLog("内核缓存没取到 —— 不影响，继续往下走（沙盒这一段不依赖它）")
            setProgressMain(0.55)
        }

        // ---- 段 2.6：布局核对（v9.6：拿不到 kernproc 就不做，不拦路）----
        markStep("校准内核布局")
        update(stage: "校准内核布局", detail: "有内核缓存才做，没有就跳过")
        if ok {
            let verdict = OffsetsDoctor.verify(kernelBase: kernelBase) { line in
                DispatchQueue.main.async { self.appendLog(line) }
            }
            for n in verdict.notes { appendLog("· " + n) }
            if verdict.adjusted > 0 {
                appendLog("共校准 \(verdict.adjusted) 处偏移，已对齐本机内核")
            }
            if !verdict.ok {
                // v9.6：这里不再拦路。上一版在这里直接 fail，等于自己把路堵死。
                appendLog("布局核对没全过 —— 但沙盒这一段只用 proc_ro 一条链，继续往下走")
            }
        } else {
            appendLog("跳过布局核对（没有内核缓存，不拿整机冒险去猜）")
        }
        setProgressMain(0.65)

        // ---- 段 3：沙盒门诊（只读，一个字节都不写）----
        markStep("沙盒门诊")
        update(stage: "沙盒门诊", detail: "只读走一遍 ucred → sandbox → 扩展链，不写；每 5 秒报一次心跳")
        cg_beat()
        let box = ProbeBox()
        let got = runWithBeats(45, "沙盒门诊（只读扫 ucred → sandbox）") {
            box.pr = sxs_probe(&box.p)
            return true
        }
        if !got {
            fail("沙盒门诊 45 秒没扫完",
                 detail: "内核读写是成功的，但门诊这一遍读得太慢或者卡住了。导出报告发我。")
            return
        }
        let p = box.p
        let pr = box.pr
        let note = String(cString: sxs_note(&box.p))
        setProbe(note)
        appendLog("门诊：" + note)

        if pr != 0 || p.ok != 1 {
            // v10.0：门诊不再一刀切拦死。
            // 上一版门诊只看 label+0x10 这一条链，链对不上就收工；
            // 而下一段现在是十六槽逐个打分，证据比门诊这一条链强得多。
            // 所以这里只记事、不拦路 —— 认不出沙盒，后面一个字都不会写。
            appendLog("门诊没全过：" + note)
            appendLog("继续：下一段按十六槽实证扫描认沙盒，认不出就不写，内核一个字节不动")
        } else {
            appendLog(String(format: "门诊通过：ucred=0x%llx sandbox=0x%llx 槽=%d 节点=%d",
                             p.ucred, p.sandbox, p.slots, p.nodes))
        }
        setProgressMain(0.72)

        // ---- 段 4：摘沙盒（v10.0 实证版）----
        // 前几版的教训：v9.7 去改扩展链上的类别字符串，写到内核只读映像 → 两次重启；
        // v9.8 把「可写区」下限写死成 0xffffffE0…，本机的 label 在 0xffffffdd… 被误判成只读 → 一刀没下。
        // v10.0 两头都改了：
        //   判定改成排除法（只有内核映像才拒），
        //   认沙盒改成实证（扫 label 十六个槽，读到扩展路径才认，最像的那个才动）。
        markStep("摘沙盒")
        update(stage: "摘沙盒", detail: "先认哪个槽是沙盒，再只摘那一个指针，改完立刻去开游戏目录")
        cg_beat()

        let credN = sxs_cred_patch()
        let credNote = String(cString: sxs_cred_note())
        appendLog("摘沙盒：" + credNote)
        appendLog("可写区判定：" + String(cString: sxs_gate_note()))   // 放没放行、为什么，全写出来
        appendLog(String(cString: sxs_label_scan()))                    // v10.0：十六槽逐个打分，证据进日志
        appendLog(String(cString: sxs_sandbox_refs()))                 // 同一个沙盒还挂在哪些位置
        if credN > 0 {
            appendLog(String(cString: sxs_sandbox_selfcheck()))        // 内核侧到底认不认
        }

        var won = false
        var usedLevel = 0

        if credN >= 0 {
            usleep(250_000)   // 给沙盒一点时间重新评估
            let v = verifyTarget()
            appendLog("摘沙盒后验证：" + v.text)
            if v.ok {
                won = true
                usedLevel = 1
                setTarget(v.path ?? "")
            }
        } else {
            appendLog("✗ 这一刀没下（原因见上一行），内核一个字节都没动")
        }

        if !won {
            markStep("回滚")
            update(stage: "回滚", detail: "把写过的字节按原样写回")
            let n = sxs_cred_rollback()
            appendLog(String(format: "回滚 %d 处，凭证恢复原样", n))
            setProbe("摘沙盒没让目录开门，已回滚")
            if credN == -5 {
                fail("摘沙盒这一刀没下（判定没放行）",
                     detail: "内核读写是通的，但写之前那道判定没放行：\(String(cString: sxs_gate_note()))。内核一个字节都没动。导出报告发我，我照这行改判定。")
            } else if credN == -7 {
                fail("认不出哪个槽是沙盒（十六槽全试完，都不开门）",
                     detail: "内核读写通了，label 十六个槽也都扫了，但没有一个摘掉之后能让目录开门。已全部回滚，内核恢复原样。报告里「槽扫描」那一行就是下一步的靶子，发我。")
            } else {
                fail("沙盒摘掉了，目录还是没开门",
                     detail: "内核读写通了、沙盒指针也真摘掉了（\(String(cString: sxs_sandbox_selfcheck()))），目录依然是 EPERM —— 说明拦你的不只是沙盒这一层。已全部回滚。报告里「沙盒自检」和「槽扫描」这两行是下一步的关键，发我。")
            }
            return
        }

        // ---- 段 5：验证交付 ----
        markStep("验证")
        update(stage: "验证", detail: "真去游戏目录里数一遍")
        DispatchQueue.main.async { self.patchLevel = usedLevel }
        cg_finish()
        finishReady(note: "摘沙盒打通，游戏目录已可读写")
    }

    // MARK: - 目录验证

    /// 真去开目录、真去数文件。不用猜，用 errno 说话。
    private func verifyTarget() -> (ok: Bool, path: String?, text: String) {
        let rootN = openCount(LSPaths.containerRoot)
        if rootN < 0 {
            return (false, nil, "数据容器根还是打不开（\(errnoText(sxs_errno()))）")
        }

        guard let container = LSPaths.scanGameContainer() else {
            return (false, nil, "数据容器能列（\(rootN) 项），但里面没有 \(LSPaths.bundleId)，可能游戏没装")
        }

        guard let paks = LSPaths.paksDir(container: container) else {
            return (false, nil, "找到游戏容器，但里面没有 Paks 目录")
        }

        let n = openCount(paks)
        if n < 0 {
            return (false, nil, "Paks 目录打不开（\(errnoText(sxs_errno()))）")
        }

        // v10.0：光「能列」不算通 —— access(W_OK) 只查权限位，不走沙盒写检查，
        // 以前就吃过这个假阳性。这里真建一个探测文件、写 1 字节、再删掉，
        // 建删都过才算真可写。探测文件名带点，游戏不会读它。
        let probe = (paks as NSString).appendingPathComponent(".ls_write_probe")
        let wrote = realWriteTest(probe)
        return (true, paks, "Paks 能列 \(n) 项，真实写入：\(wrote ? "成" : "败")（权限位：\(canWrite(paks) ? "可写" : "只读")）")
    }

    /// 真建文件、真写、真删。三步都过才算可写。
    private func realWriteTest(_ path: String) -> Bool {
        let fm = FileManager.default
        _ = fm.createFile(atPath: path, contents: Data([0x4C]))
        guard let fh = FileHandle(forWritingAtPath: path) else {
            try? fm.removeItem(atPath: path)
            return false
        }
        defer { try? fh.close() }
        guard (try? fh.write(contentsOf: Data([0x53]))) != nil else {
            try? fm.removeItem(atPath: path)
            return false
        }
        try? fm.removeItem(atPath: path)
        return !fm.fileExists(atPath: path)
    }

    private func finishReady(note: String) {
        DispatchQueue.main.async {
            self.stopWatchdog()
            self.phase = .ready
            self.stageText = "已激活"
            self.detailText = note + "，现在可以导入和删除了"
            self.progress = 1
            self.inFlight = false
            self.lastCrashRecord = nil
            self.resetKernelAttempt()
            if !self.activeProfile.isEmpty { self.profileResult[self.activeProfile] = "已打通" }
            self.appendLog("全部完成：" + note)
            // 打通之后立刻让文件列表刷新
            NotificationCenter.default.post(name: Notification.Name("LSRefreshGameFiles"), object: nil)
        }
    }

    // MARK: - 看门狗

    private func startWatchdog() {
        stopWatchdog()
        let t = DispatchSource.makeTimerSource(queue: .main)
        t.schedule(deadline: .now() + 1, repeating: 1)
        t.setEventHandler { [weak self] in self?.tickWatchdog() }
        t.resume()
        watchdog = t
    }

    private func stopWatchdog() {
        watchdog?.cancel()
        watchdog = nil
    }

    private func tickWatchdog() {
        guard phase == .running, inFlight else { return }

        // v9.2：内核读写阶段把搜索实况实时刷到界面上。
        // 以前这一阶段界面上只有一句话，看不出到底在动还是死了。
        if stageText.contains("内核读写"), let live = searchStatsLine() {
            detailText = live
        }

        let budget: Double
        if stageText.contains("内核读写") {
            budget = 240
        } else if stageText.contains("读取内核配置") {
            budget = 240
        } else if stageText.contains("校准内核布局") {
            budget = 180
        } else if stageText.contains("摘沙盒") {
            budget = 60
        } else {
            budget = 45
        }
        let age = Double(cg_beat_age_ms()) / 1000.0
        guard cg_beat_age_ms() > 0, age > budget else { return }

        hung = true
        let stage = String(cString: cg_current_stage())
        let note = stage.isEmpty ? stageText : stage
        let markText = "超时卡住/" + note
        markText.withCString { cg_mark($0) }
        stopWatchdog()
        phase = .failed
        inFlight = false
        stageText = "卡住了（\(Int(budget)) 秒没反应）"
        detailText = "它停在「\(note)」这一步。记录已写进哨兵。杀掉 App 重开再点一次；还是同一处就说明这条路径在你这台机器上走不通。"
        appendLog("✗ 超时：\(Int(age)) 秒没心跳，停在 \(note)")
        exportDiagnostics()
    }

    // MARK: - 本机内核抓取（兜底路线）

    private func fetchLocalKernelCache() -> Bool {
        guard ds_is_ready(),
              ds_get_our_proc() != 0,
              ds_get_our_task() != 0,
              off_proc_p_fd != 0,
              off_filedesc_fd_ofiles != 0,
              off_fileproc_fp_glob != 0,
              off_fileglob_fg_data != 0,
              off_vnode_v_data != 0,
              off_namecache_nc_vp != 0,
              off_namecache_nc_child_tqe_next != 0 else {
            appendLog("偏移还没备齐，走下载那条路")
            return false
        }

        guard let hash = bootManifestHash() else {
            appendLog("没找到本机系统分区标识")
            return false
        }

        let sysPath = "/private/preboot/\(hash)/System/Library/Caches/com.apple.kernelcaches/kernelcache"
        let docs = LSPaths.docDir()
        let outPath = docs.appendingPathComponent("kernelcache").path
        let fakeRead = "/private/preboot/Cryptexes/OS/System/Library/CoreServices/RestoreVersion.plist"

        unlink(outPath)

        var origVnode: UInt64 = 0
        var origData: UInt64 = 0

        let redirected = fakeRead.withCString { fakeC in
            sysPath.withCString { sysC in
                vn_fileredirect(fakeC, sysC, &origVnode, &origData)
            }
        }
        guard redirected else {
            appendLog("重定向没成")
            return false
        }

        let src = open(fakeRead, O_RDONLY)
        guard src >= 0 else {
            _ = vn_fileunredirect(origVnode, origData)
            return false
        }

        let dst = open(outPath, O_WRONLY | O_CREAT | O_TRUNC, 0o644)
        guard dst >= 0 else {
            close(src)
            _ = vn_fileunredirect(origVnode, origData)
            return false
        }

        defer {
            close(src)
            close(dst)
            _ = vn_fileunredirect(origVnode, origData)
        }

        var buffer = [UInt8](repeating: 0, count: 0x4000)
        let bufSize = buffer.count
        var total = 0

        while true {
            let n = buffer.withUnsafeMutableBytes { raw -> Int in
                guard let base = raw.baseAddress else { return -1 }
                return read(src, base, bufSize)
            }
            if n < 0 {
                appendLog("读内核出错了")
                return false
            }
            if n == 0 { break }

            var written = 0
            while written < n {
                let w = buffer.withUnsafeBytes { raw -> Int in
                    guard let base = raw.baseAddress else { return -1 }
                    return write(dst, base.advanced(by: written), n - written)
                }
                if w <= 0 {
                    appendLog("写内核出错了")
                    return false
                }
                written += w
            }
            total += n
            cg_beat()
        }

        guard total > 0, FileManager.default.fileExists(atPath: outPath) else {
            appendLog("抓出来的文件是空的")
            return false
        }

        if let h = FileHandle(forReadingAtPath: outPath) {
            let magic = h.readData(ofLength: 2)
            h.closeFile()
            if magic.count == 2, magic[0] == 0x30, magic[1] == 0x84 {
                appendLog(String(format: "本机内核抓到了：%.1f MB", Double(total) / 1048576.0))
                return dlkcache()
            }
        }
        unlink(outPath)
        appendLog("抓到的不是内核文件")
        return false
    }

    private func bootManifestHash() -> String? {
        let root = "/private/preboot"
        let fm = FileManager.default
        guard let pattern = try? NSRegularExpression(pattern: "^[A-Fa-f0-9]{64,128}$") else { return nil }
        guard let en = fm.enumerator(atPath: root) else { return nil }
        for case let item as String in en {
            let name = (item as NSString).lastPathComponent
            let range = NSRange(name.startIndex..<name.endIndex, in: name)
            if pattern.firstMatch(in: name, range: range) != nil {
                return name
            }
        }
        return nil
    }

    // MARK: - 诊断

    /// v9.2：搜索实况。这几行回答一个问题 —— 它是在往前推，还是早就停下了。
    private func searchStatsLine() -> String? {
        var ok: UInt64 = 0, fail: UInt64 = 0, pages: UInt64 = 0
        var idx: UInt64 = 0, num: UInt64 = 0
        var pageIn: UInt64 = 0, pagesIn: UInt64 = 0, elapsed: UInt64 = 0
        ds_search_stats(&ok, &fail, &pages, &idx, &num, &pageIn, &pagesIn, &elapsed)
        guard num > 0 || ok > 0 || fail > 0 else { return nil }
        var hits: UInt64 = 0, rejFilt: UInt64 = 0, rejNotOurs: UInt64 = 0
        var rejFreed: UInt64 = 0, rejOld: UInt64 = 0
        var avgUs: UInt64 = 0, maxUs: UInt64 = 0, cap: UInt64 = 0
        var h0: UInt64 = 0, h1: UInt64 = 0, h2: UInt64 = 0, h3: UInt64 = 0, h4: UInt64 = 0
        ds_search_extra(&hits, &rejFilt, &rejNotOurs, &rejFreed, &rejOld,
                        &avgUs, &maxUs, &cap, &h0, &h1, &h2, &h3, &h4)

        let head = "搜索实况：第 \(idx)/\(num) 块 · 本块第 \(pageIn)/\(pagesIn) 页 · 已扫 \(pages) 页"
        let tail = "物理读 成 \(ok) 败 \(fail) · 命中 \(hits) · 每页 \(String(format: "%.1f", Double(avgUs) / 1000.0)) ms · 已用 \(elapsed / 1000) 秒"
        return head + " · " + tail
    }

    func diagnosticsText() -> String {
        var lines: [String] = []
        lines.append("浪神文件管理器 · 内核报告（v12.6）")
        lines.append("时间：\(Date())")
        lines.append("设备：\(Compatibility.deviceSummary())")
        lines.append("架构：\(isPacRuntime() ? "arm64e（PAC）" : "arm64")")
        lines.append("阶段：\(stageText)")
        lines.append("说明：\(detailText)")
        lines.append("门诊：\(probeLine)")
        lines.append("走通的层：\(patchLevel == 0 ? "无" : "摘沙盒")")
        lines.append(String(format: "内核基址：0x%llx", kernelBase))
        lines.append("内核缓存：" + (offsetsReady ? "已就位（顺带做了布局核对）" : "跳过 —— 不影响，沙盒那一段全程现场自校准"))
        lines.append("目标目录：\(targetPath.isEmpty ? "（无）" : targetPath)")
        lines.append("档位：\(cautious ? "保守（上次没走完 / 18 系列）" : "标准")")
        lines.append("内核档位：\(activeProfile.isEmpty ? "自动 / 通用偏移（26 以下）" : KernelEngine.profileLogName(activeProfile) + "（该大版本下所有小版本通用）")")
        lines.append("覆盖范围：iOS 26 全系（26.0 起含 26.9）、iOS 27 及以上全系，一个不漏")
        lines.append("引擎当前阶段：\(String(cString: cg_current_stage()))")
        lines.append(String(format: "距上次心跳：%.1f 秒", Double(cg_beat_age_ms()) / 1000.0))
        if let s = searchStatsLine() { lines.append(s) }
        // v10.2：上一次整机重启的根子就在这一组数里 —— 映射失败有没有清状态、
        // 对端有没有同步上、一页到底重试了多少轮。以后再重启，看这几行就能定位。
        var pyFatal: Int32 = 0
        var pyReason = [CChar](repeating: 0, count: 192)
        var pyResets: UInt64 = 0, pyMapFail: UInt64 = 0, pyStreak: UInt64 = 0
        var pyWait: UInt64 = 0, pyWaitMax: UInt64 = 0, pyCap: UInt64 = 0
        ds_phys_stats(&pyFatal, &pyReason, 192, &pyResets, &pyMapFail, &pyStreak,
                      &pyWait, &pyWaitMax, &pyCap)
        let pyReasonText = pyReason.withUnsafeBufferPointer { buf -> String in
            guard let base = buf.baseAddress else { return "（无）" }
            return String(cString: base)
        }
        lines.append("物理路径：\(pyFatal != 0 ? "已刹车" : "正常") · \(pyReasonText)")
        lines.append("物理路径计数：状态复位 \(pyResets) 次 · 映射失败 \(pyMapFail) 次（当前连续 \(pyStreak)）· 同步超时 \(pyWait) 次（单页最多 \(pyWaitMax)）· 每页重试上限 \(pyCap) 轮")
        // v10.1：喷 socket 那几十秒以前在报告里完全看不出来 ——
        // 导出来就是「页 0/0 · 每页 0.0ms」，看着像死了，其实正在正常往前喷。
        var spDone: UInt64 = 0, spTotal: UInt64 = 0, spEl: UInt64 = 0
        var spNow: Int32 = 0
        ds_spray_stats(&spDone, &spTotal, &spEl, &spNow)
        if spTotal > 0 {
            lines.append("喷 socket：\(spDone)/\(spTotal) · 已用 \(spEl / 1000) 秒" + (spNow != 0 ? "（正在喷，不是卡住）" : "（已喷完）"))
        }
        // v9.4：这两行是给「是慢还是扫错地方」下定论的
        var mh: UInt64 = 0, rn: UInt64 = 0, ro: UInt64 = 0, rf: UInt64 = 0, rl: UInt64 = 0
        var au: UInt64 = 0, mu: UInt64 = 0, cp: UInt64 = 0
        var h0: UInt64 = 0, h1: UInt64 = 0, h2: UInt64 = 0, h3: UInt64 = 0, h4: UInt64 = 0
        ds_search_extra(&mh, &rn, &ro, &rf, &rl, &au, &mu, &cp, &h0, &h1, &h2, &h3, &h4)
        lines.append("命中本进程标记页数：\(mh)")
        lines.append("驳回去向：无filt \(rn) · 非我们的 \(ro) · 已释放 \(rf) · 试过 \(rl)")
        lines.append(String(format: "每页耗时：平均 %.1f ms · 最慢 %.0f ms · 每页重试上限 %llu 轮", Double(au) / 1000.0, Double(mu) / 1000.0, cp))
        lines.append("成功轮数分布：<8 \(h0) · <32 \(h1) · <128 \(h2) · <512 \(h3) · 更多 \(h4)")
        // v9.5：写 socket 控制块那一段的实况 —— 分开记，才分得清写没写进去和读不读得回来
        var cwW: UInt64 = 0, cwOk: UInt64 = 0, cwFail: UInt64 = 0
        var gsoT: UInt64 = 0, gsoH: UInt64 = 0
        var verdict = [CChar](repeating: 0, count: 160)
        ds_corrupt_stats(&cwW, &cwOk, &cwFail, &gsoT, &gsoH, &verdict, 160)
        lines.append("写验证：写 \(cwW) 次 · 内核侧确认 \(gsoH)/\(gsoT) · 读回成功 \(cwOk) · 读回失败 \(cwFail)")
        let verdictText = verdict.withUnsafeBufferPointer { buf -> String in
            guard let base = buf.baseAddress else { return "（无）" }
            return String(cString: base)
        }
        lines.append("写 socket 判定：\(verdictText.isEmpty ? "（无）" : verdictText)")
        lines.append("凭证路线：\(String(cString: sxs_cred_note()))")
        // 这四行决定下一步 —— 判定放没放行、哪个槽被认成沙盒、沙盒真摘掉没有、同一个沙盒还挂在哪儿
        lines.append("可写区判定：\(String(cString: sxs_gate_note()))")
        lines.append("槽扫描：\(String(cString: sxs_label_scan()))")
        lines.append(String(cString: sxs_sandbox_refs()))
        lines.append(String(cString: sxs_sandbox_selfcheck()))
        lines.append("凭证改动条数：\(sxs_cred_count())")
        lines.append("写入次数（本版累计）：\(kernelAttemptCount())")
        lines.append("最近一次结论：\(String(cString: sxs_verdict()))")
        lines.append("数据容器根：\(openCount(LSPaths.containerRoot) >= 0 ? "能列" : "打不开（\(errnoText(sxs_errno()))）")")
        // v11.1：上一版的教训 —— 门诊只试了一个动作就宣布「得走内核」，
        // 新加的租约通道压根没被调用过，报告里写「凭证路线：还没跑过」，等于白跑一轮。
        // 从现在起这几条通道的逐条结论必须落在报告里，一眼看清是没跑还是跑失败了。
        if containerNotes.isEmpty {
            lines.append("容器通道：（没跑）")
        } else {
            lines.append("容器通道：\(containerNotes.count) 条结论")
            lines.append(contentsOf: containerNotes.map { "  · " + $0 })
        }
        if let rec = lastCrashRecord {
            lines.append("上次没走完：\(rec.trimmingCharacters(in: .whitespacesAndNewlines))")
        }
        if let tail = lastRunTail {
            lines.append("上次日志停在这行：\(tail)")
        }
        lines.append("")
        lines.append("---- 引擎日志 ----")
        lines.append(contentsOf: logLines)
        return lines.joined(separator: "\n")
    }

    @discardableResult
    func exportDiagnostics() -> URL? {
        let url = LSPaths.docDir().appendingPathComponent("内核报告.txt")
        do {
            try diagnosticsText().write(to: url, atomically: true, encoding: .utf8)
            appendLog("报告已存到「文件 → 我的 iPhone → 浪神文件管理器 → 内核报告.txt」")
            return url
        } catch {
            appendLog("报告没写出去：\(error.localizedDescription)")
            return nil
        }
    }

    // MARK: - 状态

    func appendLog(_ s: String) {
        if !Thread.isMainThread {
            DispatchQueue.main.async { [weak self] in self?.appendLog(s) }
            return
        }
        logLines.append(s)
        if logLines.count > 240 {
            logLines.removeFirst(logLines.count - 240)
        }
    }

    func setProgress(_ p: Double) {
        progress = max(0, min(1, p))
    }

    /// 后台线程不能直接改界面状态，统一从这里过
    private func setProbe(_ s: String) {
        DispatchQueue.main.async { self.probeLine = s }
    }

    private func setTarget(_ s: String) {
        DispatchQueue.main.async { self.targetPath = s }
    }

    private func setProgressMain(_ p: Double) {
        DispatchQueue.main.async { self.progress = max(0, min(1, p)) }
    }

    private func update(stage: String, detail: String) {
        DispatchQueue.main.async {
            self.stageText = stage
            self.detailText = detail
        }
    }

    private func fail(_ what: String, detail: String) {
        cg_finish()
        DispatchQueue.main.async {
            self.stopWatchdog()
            self.phase = .failed
            self.stageText = what
            self.detailText = detail
            self.inFlight = false
            if !self.activeProfile.isEmpty, self.profileResult[self.activeProfile] == "正在跑" {
                self.profileResult[self.activeProfile] = "跑过未通"
            }
            self.appendLog("✗ " + what)
        }
    }
}

// MARK: - 小工具

/// 数目录条目（C 接口要裸 C 字符串）
private func openCount(_ path: String) -> Int32 {
    return path.withCString { sxs_open_count($0) }
}

/// 目录能不能写
private func canWrite(_ path: String) -> Bool {
    return path.withCString { sxs_writable($0) == 1 }
}

private func errnoText(_ e: Int32) -> String {
    switch e {
    case 0:   return "OK"
    case 1:   return "EPERM(1·系统拒绝)"
    case 2:   return "ENOENT(2·不存在)"
    case 13:  return "EACCES(13·没权限)"
    case 20:  return "ENOTDIR(20·不是目录)"
    case 30:  return "EROFS(30·只读)"
    default:  return "errno(\(e))"
    }
}

/// 当前是不是 arm64e 运行时（内核指针带 PAC 必须走这条路）
private func isPacRuntime() -> Bool {
    var sub: cpu_subtype_t = 0
    var size = MemoryLayout<cpu_subtype_t>.size
    let r = sysctlbyname("hw.cpusubtype", &sub, &size, nil, 0)
    guard r == 0 else { return false }
    return sub == CPU_SUBTYPE_ARM64E
}
