import Foundation

/// 自动导文件 + 自动删文件
enum AutoIO {

    // MARK: - 结果结构

    struct ImportReport {
        var name: String
        var action: String
        var error: String? = nil
        var size: Int64 = 0
        var backedUp: Bool = false
        var dstPath: String? = nil
        var backupPath: String? = nil
    }

    /// 撤回一条导入的结果
    struct UndoReport {
        var id: String
        var name: String
        var gamePath: String
        var action: String
        var error: String? = nil
        var holdPath: String? = nil
    }

    struct DeleteReport {
        var name: String
        var path: String
        var size: Int64
        var error: String? = nil
        var movedTo: String? = nil
    }

    // MARK: - 工具

    /// 按时间戳建一个子目录，比如 Backups/导入前-20260101-120000
    static func stampedDir(_ root: URL, _ prefix: String, _ stamp: String) -> URL {
        return root.appendingPathComponent("\(prefix)-\(stamp)", isDirectory: true)
    }

    private static func makeDir(_ url: URL) -> Bool {
        let fm = FileManager.default
        if fm.fileExists(atPath: url.path) { return true }
        do {
            try fm.createDirectory(at: url, withIntermediateDirectories: true)
            return true
        } catch {
            return false
        }
    }

    private static func fileSize(_ path: String) -> Int64 {
        let attrs = try? FileManager.default.attributesOfItem(atPath: path)
        return (attrs?[.size] as? NSNumber)?.int64Value ?? 0
    }

    /// 分块复制，边复制边报进度。
    /// 用它的理由：几百兆的 pak 用系统一步复制，界面会像死掉一样，
    /// 分块之后进度条一直动，用户知道它在干活。
    static func copyWithProgress(from: URL,
                                 to: URL,
                                 onProgress: (Double) -> Void) throws {
        let fm = FileManager.default
        let src = try FileHandle(forReadingFrom: from)
        defer { try? src.close() }

        guard fm.createFile(atPath: to.path, contents: nil) else {
            throw NSError(domain: "LSPak", code: 1,
                          userInfo: [NSLocalizedDescriptionKey: "建不了目标文件"])
        }
        let dst = try FileHandle(forWritingTo: to)
        defer { try? dst.close() }

        let total = fileSize(from.path)
        if total <= 0 {
            // 空文件或读不到大小，直接搬
            try dst.write(contentsOf: try src.readToEnd() ?? Data())
            onProgress(1)
            return
        }

        let chunk = 4 * 1024 * 1024   // 4MB 一块
        var done: Int64 = 0
        while true {
            let data = try src.read(upToCount: chunk) ?? Data()
            if data.isEmpty { break }
            try dst.write(contentsOf: data)
            done += Int64(data.count)
            onProgress(min(1.0, Double(done) / Double(total)))
        }
        onProgress(1)
    }


    // MARK: - 自动导入

    /// 把 items 全部导进 dstDir：临时文件写入 → 原子替换 → 核对字节数
    /// noBackup = true 时直接覆盖原件，一份备份都不留（浪神 v12.6 指定的做法）
    static func importAll(items: [PakItem],
                          into dstDir: String,
                          backupRoot: URL,
                          stamp: String,
                          overwrite: Bool,
                          clearSource: Bool,
                          sourcePark: URL,
                          skipIdentical: Bool = false,
                          noBackup: Bool = false,
                          progress: (Int, Int, String) -> Void) -> [ImportReport] {

        let fm = FileManager.default
        let dstBase = URL(fileURLWithPath: dstDir, isDirectory: true)
        let bakDir = stampedDir(backupRoot, "导入前", stamp)
        var reports: [ImportReport] = []

        for (i, it) in items.enumerated() {
            progress(i, items.count, it.name)

            var rep = ImportReport(name: it.name, action: "", size: it.size)
            let dst = dstBase.appendingPathComponent(it.name)
            let dstPath = dst.path

            var isDir: ObjCBool = false
            let exists = fm.fileExists(atPath: dstPath, isDirectory: &isDir)

            if exists && isDir.boolValue {
                rep.action = "跳过"
                rep.error = "游戏目录里有个同名文件夹，不敢覆盖"
                reports.append(rep)
                continue
            }

            // 游戏里已经是同一份（大小一致）就不再覆盖一遍，
            // 否则每点一次「导入」都会往 Backups 里多塞一份几百兆
            if exists && skipIdentical && fileSize(dstPath) == it.size {
                rep.action = "跳过（游戏里已经是这份）"
                rep.dstPath = dstPath
                reports.append(rep)
                continue
            }

            if exists && !overwrite {
                rep.action = "跳过（同名已在，覆盖没开）"
                rep.backedUp = false
                reports.append(rep)
                continue
            }

            // 同名先备份原件，备份不成功就不动它
            // v12.6：noBackup 打开时这一步整段跳过 —— 直接覆盖，不占手机空间
            if exists && !noBackup {
                if !makeDir(bakDir) {
                    rep.action = "跳过"
                    rep.error = "建备份目录失败，没敢动原文件"
                    reports.append(rep)
                    continue
                }
                let bak = bakDir.appendingPathComponent(it.name)
                try? fm.removeItem(at: bak)
                do {
                    try fm.copyItem(at: dst, to: bak)
                    rep.backedUp = true
                    rep.backupPath = bak.path
                } catch {
                    rep.action = "跳过"
                    rep.error = "备份原件失败（\(LSPaths.describe(error))），没敢动它"
                    reports.append(rep)
                    continue
                }
            }

            // 先写临时文件，成功了再替换，避免中途断了留下半个包
            let tmp = dstBase.appendingPathComponent(".ls_tmp_\(it.name)")
            try? fm.removeItem(at: tmp)
            do {
                try fm.copyItem(at: it.url, to: tmp)
                if exists {
                    try fm.removeItem(at: dst)
                }
                try fm.moveItem(at: tmp, to: dst)
            } catch {
                try? fm.removeItem(at: tmp)
                rep.action = "失败"
                rep.error = LSPaths.describe(error)
                reports.append(rep)
                continue
            }

            // 逐字节核对，大小不一致就算失败
            let after = fileSize(dstPath)
            if after != it.size {
                rep.action = "失败"
                if noBackup {
                    rep.error = "写进去以后大小不对（\(it.size) → \(after)），再点一次导入就会重写"
                } else {
                    rep.error = "写进去以后大小不对（\(it.size) → \(after)），已停在原地，请用备份还原"
                }
                reports.append(rep)
                continue
            }

            rep.action = exists ? (noBackup ? "已直接覆盖（未备份）" : "覆盖成功") : "新增成功"
            rep.dstPath = dstPath

            // 源文件挪去「已导入」，下次不会重复导
            if clearSource {
                if makeDir(sourcePark) {
                    let park = sourcePark.appendingPathComponent(it.name)
                    try? fm.removeItem(at: park)
                    do {
                        try fm.moveItem(at: it.url, to: park)
                        rep.action += " · 源已清走"
                    } catch {
                        rep.action += " · 源没挪走"
                    }
                }
            }

            reports.append(rep)
        }

        progress(items.count, items.count, "完成")
        return reports
    }

    // MARK: - 扫要删的

    /// 在 root 下按关键字 + 后缀找文件（只找，不动手）
    static func scanForDelete(root: String,
                              keyword: String,
                              ext: String,
                              depth: Int = 4,
                              limit: Int = 5000) -> [PakItem] {

        let fm = FileManager.default
        let kw = keyword.trimmingCharacters(in: .whitespacesAndNewlines).lowercased()
        let wantedExt = ext.trimmingCharacters(in: .whitespacesAndNewlines).lowercased()
        var out: [PakItem] = []
        var scanned = 0

        func walk(_ path: String, _ level: Int) {
            if scanned >= limit { return }
            guard let names = try? fm.contentsOfDirectory(atPath: path) else { return }
            for n in names where !n.hasPrefix(".") {
                if scanned >= limit { return }
                let full = path + "/" + n
                var isDir: ObjCBool = false
                guard fm.fileExists(atPath: full, isDirectory: &isDir) else { continue }

                if isDir.boolValue {
                    if level < depth { walk(full, level + 1) }
                    continue
                }

                scanned += 1
                let low = n.lowercased()
                let extOK: Bool = (wantedExt.isEmpty || wantedExt == "any")
                    ? true
                    : low.hasSuffix("." + wantedExt)
                let kwOK: Bool = kw.isEmpty ? true : low.contains(kw)
                if extOK && kwOK {
                    let size = fileSize(full)
                    out.append(PakItem(id: full, url: URL(fileURLWithPath: full), size: size))
                }
            }
        }

        walk(root, 0)
        return out.sorted { $0.name < $1.name }
    }

    // MARK: - 自动删

    /// keepCopy = true 时是「挪到备份」，不是真删，后悔能拿回来
    static func deleteAll(_ targets: [PakItem],
                          backupRoot: URL,
                          stamp: String,
                          keepCopy: Bool,
                          progress: (Int, Int, String) -> Void) -> [DeleteReport] {

        let fm = FileManager.default
        let hold = stampedDir(backupRoot, "删掉的", stamp)
        var reports: [DeleteReport] = []

        for (i, t) in targets.enumerated() {
            progress(i, targets.count, t.name)
            var rep = DeleteReport(name: t.name, path: t.id, size: t.size)

            do {
                if keepCopy {
                    if !makeDir(hold) {
                        rep.error = "建备份目录失败，没删"
                        reports.append(rep)
                        continue
                    }
                    var dest = hold.appendingPathComponent(t.name)
                    if fm.fileExists(atPath: dest.path) {
                        let n = Int(Date().timeIntervalSince1970 * 1000)
                        dest = hold.appendingPathComponent("\(n)_\(t.name)")
                    }
                    try fm.moveItem(at: t.url, to: dest)
                    rep.movedTo = dest.path
                } else {
                    try fm.removeItem(at: t.url)
                }
            } catch {
                rep.error = LSPaths.describe(error)
            }

            reports.append(rep)
        }

        progress(targets.count, targets.count, "完成")
        return reports
    }

    // MARK: - 删除导入的文件（撤回）

    /// 把已经导进游戏的文件撤掉：
    /// 1) 游戏里那份 → 挪进 Backups/删掉的-时间/（或直删）
    /// 2) 当初覆盖过原件的 → 自动把原件写回去
    ///
    /// vaultDir 传进来以后：素材库里已经有同名的（说明这份是从素材库导的），
    /// 就不再多留一份副本了 —— 否则反复「导入→删除」会把手机塞满。
    static func undoImports(_ recs: [ImportRecord],
                            backupRoot: URL,
                            stamp: String,
                            keepCopy: Bool,
                            restoreBackup: Bool,
                            vaultDir: URL? = nil,
                            progress: (Int, Int, String) -> Void) -> [UndoReport] {

        let fm = FileManager.default
        let hold = stampedDir(backupRoot, "删掉的", stamp)
        var out: [UndoReport] = []

        for (i, r) in recs.enumerated() {
            progress(i, recs.count, r.name)
            var rep = UndoReport(id: r.id, name: r.name, gamePath: r.gamePath, action: "")
            let game = URL(fileURLWithPath: r.gamePath)
            let existsGame = fm.fileExists(atPath: r.gamePath)

            // 1) 先处理游戏里那份
            if existsGame {
                // 素材库里已经有这份 → 它就是备份，不再重复留
                let hasVaultCopy = vaultDir.map {
                    fm.fileExists(atPath: $0.appendingPathComponent(r.name).path)
                } ?? false
                let needCopy = keepCopy && !hasVaultCopy

                if needCopy {
                    if !makeDir(hold) {
                        rep.error = "建备份目录失败，没敢动"
                        out.append(rep)
                        continue
                    }
                    var dest = hold.appendingPathComponent(r.name)
                    if fm.fileExists(atPath: dest.path) {
                        let n = Int(Date().timeIntervalSince1970 * 1000)
                        dest = hold.appendingPathComponent("\(n)_\(r.name)")
                    }
                    do {
                        try fm.moveItem(at: game, to: dest)
                        rep.holdPath = dest.path
                        rep.action = "已从游戏删掉"
                    } catch {
                        rep.error = LSPaths.describe(error)
                        out.append(rep)
                        continue
                    }
                } else {
                    do {
                        try fm.removeItem(at: game)
                        rep.action = "已从游戏删掉"
                    } catch {
                        rep.error = LSPaths.describe(error)
                        out.append(rep)
                        continue
                    }
                }
            } else {
                rep.action = "游戏里本来就没有"
            }

            // 2) 原来是覆盖上传的，把原件还回去
            if restoreBackup, let bp = r.backupPath {
                if fm.fileExists(atPath: bp) {
                    do {
                        if fm.fileExists(atPath: r.gamePath) {
                            try? fm.removeItem(at: game)
                        }
                        try fm.copyItem(at: URL(fileURLWithPath: bp), to: game)
                        rep.action += " · 原件已还原"
                    } catch {
                        rep.action += " · 原件还原失败：\(LSPaths.describe(error))"
                    }
                } else {
                    rep.action += " · 备份里的原件找不到了"
                }
            }

            out.append(rep)
        }

        progress(recs.count, recs.count, "完成")
        return out
    }

    /// 把删掉留着的那一份再放回游戏
    static func putBack(from holdPath: String,
                        to gamePath: String,
                        progress: (Int, Int, String) -> Void) -> String? {

        let fm = FileManager.default
        progress(0, 1, (gamePath as NSString).lastPathComponent)
        guard fm.fileExists(atPath: holdPath) else {
            return "留存的副本不见了：\(holdPath)"
        }
        let src = URL(fileURLWithPath: holdPath)
        let dst = URL(fileURLWithPath: gamePath)
        let tmp = dst.deletingLastPathComponent()
            .appendingPathComponent(".ls_tmp_putback_\(dst.lastPathComponent)")
        try? fm.removeItem(at: tmp)
        do {
            try fm.copyItem(at: src, to: tmp)
            if fm.fileExists(atPath: gamePath) {
                try fm.removeItem(at: dst)
            }
            try fm.moveItem(at: tmp, to: dst)
        } catch {
            try? fm.removeItem(at: tmp)
            return LSPaths.describe(error)
        }
        progress(1, 1, "完成")
        return nil
    }

    // MARK: - 给界面看的一句话说明

    static func extLabel(_ ext: String) -> String {
        switch ext {
        case "pak": return "只 .pak"
        case "sig": return "只 .sig"
        case "any": return "任意后缀"
        default: return ext
        }
    }
}
