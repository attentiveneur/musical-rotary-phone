import Foundation

/// v12.6：一键移出 —— 把「导进游戏的那些文件」一次全搬回素材库。
///
/// 跟单个「移出」走同一套铁律，一步不省：
///   先分块拷进素材库 → 核对两边字节数完全一致 → 才删游戏里那份。
/// 任何一步不对就退回去，游戏里那份原样不动，绝不会出现「游戏里没了、素材库里也没有」。
/// 同名不覆盖：素材库里已有同名文件，这次存成「名字-时间戳.pak」，绝不盖掉旧的那份。
/// 游戏里那份删掉就删掉了，不回滚、不还原原件（v12.6 浪神指定）。
extension Store {

    /// 一键移出：账本优先，账本没有也能兜住旧版导进去的
    func moveOutAll() {
        guard !busy else { return }

        guard let pd = paksDir else {
            log("✗ 还没拿到游戏目录，移不了")
            log("  先回上面点「一键打通游戏目录」，打通了再点这个")
            return
        }

        let fm = FileManager.default
        var seen = Set<String>()
        var targets: [(path: String, name: String, recID: String?)] = []

        // ① 账本：这个 App 导进游戏、还在游戏里的 → 全搬回来
        for r in imported where !r.deleted {
            if fm.fileExists(atPath: r.gamePath), seen.insert(r.gamePath).inserted {
                targets.append((r.gamePath, r.name, r.id))
            }
        }
        let byLog = targets.count

        // ② 兜底：素材库里有的名字，游戏目录里也有、而且大小一模一样 —— 就是同一份文件
        //    专治「用旧版导进去、没记账」的情况。只认大小完全一致，不靠名字瞎猜。
        var vaultSize: [String: Int64] = [:]
        for v in LSPaths.listImportSources() {
            let old = vaultSize[v.name] ?? -1
            if v.size > old { vaultSize[v.name] = v.size }
        }
        if !vaultSize.isEmpty {
            for it in LSPaths.listFiles(in: pd, exts: ["pak", "sig"], depth: 3) {
                guard let vs = vaultSize[it.name], vs == it.size else { continue }
                if seen.insert(it.url.path).inserted {
                    targets.append((it.url.path, it.name, nil))
                }
            }
        }

        guard !targets.isEmpty else {
            log("· 游戏里没有要移出的文件：账本里没有还在游戏里的，素材库也没有同名同大小的包")
            log("  想单独搬某个包：去「游戏里的包」页签，每个右边有「移出」")
            ui { self.banner = "没有要移出的文件" }
            return
        }

        busy = true
        let stamp = Fmt.stamp()
        let total = targets.count
        let vault = LSPaths.vaultDir()
        let byMatch = total - byLog

        log("==== 一键移出：\(total) 个 → 素材库 ====")
        if byLog > 0 { log("· 账本里记着 \(byLog) 个") }
        if byMatch > 0 { log("· 素材库同名同大小的兜到了 \(byMatch) 个") }
        log("顺序：先拷进素材库 → 核对大小 → 才删游戏里那份")

        queue.async { [weak self] in
            guard let self = self else { return }

            if !fm.fileExists(atPath: vault.path) {
                try? fm.createDirectory(at: vault, withIntermediateDirectories: true)
            }

            var ok = 0
            var bad = 0
            var claimed = 0

            for (i, t) in targets.enumerated() {
                self.setProgress(Double(i) / Double(max(total, 1)),
                                 "\(i + 1)/\(total)  \(t.name)")

                let src = URL(fileURLWithPath: t.path)
                let base = (t.name as NSString).deletingPathExtension
                let ext = (t.name as NSString).pathExtension

                // v12.6：素材库里已经有同名、同大小的一份 → 就是同一份，
                // 不用再把几百兆搬一遍，直接把游戏里那份删掉就行。
                // 这样「导入 → 移出」来回点，素材库不会越堆越多。
                let sameInVault = vault.appendingPathComponent(t.name)
                let srcSize = ((try? fm.attributesOfItem(atPath: src.path))?[.size] as? NSNumber)?.int64Value ?? -1
                let vaultSameSize = ((try? fm.attributesOfItem(atPath: sameInVault.path))?[.size] as? NSNumber)?.int64Value ?? -2

                if srcSize >= 0 && srcSize == vaultSameSize {
                    do {
                        try fm.removeItem(at: src)
                    } catch {
                        bad += 1
                        self.log("✗ \(t.name)：素材库里已有这份，但游戏里那份没删掉（\(LSPaths.describe(error))）")
                        continue
                    }
                    if let id = t.recID {
                        ImportLog.markDeleted(id: id, hold: sameInVault.path)
                    } else {
                        claimed += 1
                    }
                    ok += 1
                    self.log("✓ \(t.name) → 素材库里已有这份，游戏里已删（没重复拷）")
                    continue
                }

                // 同名绝不覆盖：已有就加时间戳，再撞就往后加序号
                var dst = vault.appendingPathComponent(t.name)
                var n = 1
                while fm.fileExists(atPath: dst.path) {
                    n += 1
                    let suffix = n == 2 ? "-\(stamp)" : "-\(stamp)-\(n)"
                    dst = vault.appendingPathComponent("\(base)\(suffix).\(ext)")
                }

                do {
                    try AutoIO.copyWithProgress(from: src, to: dst) { p in
                        let baseDone = Double(i) / Double(max(total, 1))
                        self.setProgress(baseDone + p / Double(max(total, 1)),
                                         "\(i + 1)/\(total)  \(t.name)")
                    }
                } catch {
                    try? fm.removeItem(at: dst)
                    bad += 1
                    self.log("✗ \(t.name)：拷进素材库失败（\(LSPaths.describe(error))）")
                    self.log("  游戏里那份原样没动")
                    continue
                }

                // 大小核对：对不上就把素材库这份删掉，绝不往下删源文件
                let a = ((try? fm.attributesOfItem(atPath: src.path))?[.size] as? NSNumber)?.int64Value ?? -1
                let b = ((try? fm.attributesOfItem(atPath: dst.path))?[.size] as? NSNumber)?.int64Value ?? -2
                guard a >= 0, a == b else {
                    try? fm.removeItem(at: dst)
                    bad += 1
                    self.log("✗ \(t.name)：大小对不上（游戏里 \(a) / 素材库 \(b)）")
                    self.log("  素材库那份已删，游戏里那份原样不动")
                    continue
                }

                do {
                    try fm.removeItem(at: src)
                } catch {
                    bad += 1
                    self.log("⚠ \(t.name)：素材库那份存好了，但游戏里那份没删掉（\(LSPaths.describe(error))）")
                    continue
                }

                if let id = t.recID {
                    ImportLog.markDeleted(id: id, hold: dst.path)
                } else {
                    claimed += 1
                }
                ok += 1
                self.log("✓ \(t.name) → 素材库/\(dst.lastPathComponent)（\(Fmt.size(a))）")
            }

            self.setProgress(1, "完成")
            self.log("==== 移出结束：成功 \(ok) / 失败 \(bad)，共 \(total) 个 ====")
            if ok > 0 {
                self.log("游戏里这些包已经从目录消失；素材库留着，点「① 一键导入」随时放回去")
            }
            if claimed > 0 {
                self.log("· 其中 \(claimed) 个是照「同名同大小」认出来的，没进账本，想记账点「认领」")
            }

            let recs = ImportLog.load()
            let vaultList = LSPaths.listImportSources()
            self.ui {
                self.busy = false
                self.imported = recs
                self.importList = vaultList
                self.banner = "已移出 \(ok) 个" + (bad > 0 ? "（\(bad) 个没成，看记录）" : "")
            }
            self.refreshGameOnly()
        }
    }
}
