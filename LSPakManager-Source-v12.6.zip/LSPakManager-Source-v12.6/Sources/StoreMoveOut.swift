import Foundation

/// v12.3：把游戏 Paks 里的包搬到素材库 —— 真移动，不是复制个快捷方式。
/// 顺序死守：先拷到素材库 → 核对两边大小一致 → 才删游戏里那份。
/// 任何一步不对就退回去，绝不出现「游戏里没了、素材库里也没有」的半截状态。
/// 同名文件加时间后缀 —— 移到素材库，绝不覆盖已有那份。
extension Store {

    func moveOutGameFile(_ it: PakItem) {
        guard !busy else { return }

        let src = it.url
        let vault = LSPaths.vaultDir()
        let stamp = Fmt.stamp()
        let base = (it.name as NSString).deletingPathExtension
        let ext = (it.name as NSString).pathExtension

        ui { self.busy = true }
        setProgress(0.05, "移出：\(it.name)")

        log("==== 移出游戏：\(it.name) ====")
        log("源：\(it.id)")

        queue.async { [weak self] in
            guard let self = self else { return }
            let fm = FileManager.default

            if !fm.fileExists(atPath: vault.path) {
                try? fm.createDirectory(at: vault, withIntermediateDirectories: true)
            }

            // 素材库里已有同名的 -> 加时间后缀，绝不覆盖
            var dst = vault.appendingPathComponent(it.name)
            if fm.fileExists(atPath: dst.path) {
                dst = vault.appendingPathComponent("\(base)-\(stamp).\(ext)")
                self.log("· 素材库里已有同名文件，这次存成 \(dst.lastPathComponent)")
            }
            self.log("目标：素材库/\(dst.lastPathComponent)")

            self.setProgress(0.3, "复制中…")
            do {
                try fm.copyItem(at: src, to: dst)
            } catch {
                self.log("✗ 没移成：拷进素材库失败（\(error.localizedDescription)）")
                self.log("  游戏里那份原样没动")
                self.setProgress(0, "")
                self.ui { self.busy = false }
                return
            }

            // 大小核对：对不上就把素材库这份删掉，绝不往下删源文件
            let a = ((try? fm.attributesOfItem(atPath: src.path))?[.size] as? NSNumber)?.int64Value ?? -1
            let b = ((try? fm.attributesOfItem(atPath: dst.path))?[.size] as? NSNumber)?.int64Value ?? -2
            guard a >= 0, a == b else {
                try? fm.removeItem(at: dst)
                self.log("✗ 大小对不上（游戏里 \(a) 字节 / 素材库 \(b) 字节）")
                self.log("  已经把素材库那份删掉了，游戏里那份原样不动")
                self.setProgress(0, "")
                self.ui { self.busy = false }
                return
            }
            self.log("· 大小核对通过：\(Fmt.size(a))")

            self.setProgress(0.75, "删掉游戏里那份…")
            do {
                try fm.removeItem(at: src)
            } catch {
                self.log("⚠ 素材库那份已经存好了（\(dst.lastPathComponent)），但游戏里那份没删掉")
                self.log("  原因：\(error.localizedDescription)")
                self.log("  你可以点「④ 全盘找 pak」再试一次移出，或直接点「删」")
                self.setProgress(0, "")
                self.ui { self.busy = false }
                self.refresh()
                return
            }

            self.log("✓ 已移出：\(it.name) → 素材库/\(dst.lastPathComponent)")
            self.log("  游戏里那份已删；素材库留着，点「① 一键导入」随时能放回去")
            self.setProgress(1, "完成")
            self.ui {
                self.busy = false
                self.banner = "已移出 \(it.name)（素材库里有备份）"
            }
            self.refresh()
        }
    }
}
