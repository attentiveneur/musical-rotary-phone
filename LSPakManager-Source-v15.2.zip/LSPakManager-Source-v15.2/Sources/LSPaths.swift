//
//  LSPaths.swift
//  v14.0
//
//  这一版只干搬运：把包送进游戏目录，把包从游戏目录搬出来。
//  改包、换字、改资源这些活 v14 里一个都没有。
//

import Foundation

enum LSPaths {

    static let pakExts: Set<String> = ["pak", "sig", "uasset", "ucas", "utoc"]

    // MARK: - 自己的目录

    static func docDir() -> URL {
        FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)[0]
    }

    /// ① 待导入：你把包丢这里，点「一键导入」送进游戏
    static func inboxDir() -> URL {
        docDir().appendingPathComponent("① 待导入", isDirectory: true)
    }

    /// ② 已移出：从游戏里搬出来的包落这里，文件 App 里能直接看见
    static func outDir() -> URL {
        docDir().appendingPathComponent("② 已移出", isDirectory: true)
    }

    /// ③ 已导入：送进游戏后，本地留的一份记录副本（不删原文件）
    static func sentDir() -> URL {
        docDir().appendingPathComponent("③ 已导入", isDirectory: true)
    }

    /// 中转用的临时落脚点
    static func tempDir() -> URL {
        let u = FileManager.default.temporaryDirectory.appendingPathComponent("ls15", isDirectory: true)
        try? FileManager.default.createDirectory(at: u, withIntermediateDirectories: true)
        return u
    }

    static func ensureDirs() {
        let fm = FileManager.default
        for u in [inboxDir(), outDir(), sentDir()] {
            var isDir: ObjCBool = false
            if !fm.fileExists(atPath: u.path, isDirectory: &isDir) {
                try? fm.createDirectory(at: u, withIntermediateDirectories: true)
            }
        }
    }

    // MARK: - 列文件

    static func listPaks(in dir: URL, depth: Int = 2) -> [PakItem] {
        let fm = FileManager.default
        var out: [PakItem] = []
        var seen = Set<String>()

        func walk(_ url: URL, _ level: Int) {
            guard let names = try? fm.contentsOfDirectory(atPath: url.path) else { return }
            for n in names where !n.hasPrefix(".") {
                let full = url.appendingPathComponent(n)
                var isDir: ObjCBool = false
                guard fm.fileExists(atPath: full.path, isDirectory: &isDir) else { continue }
                if isDir.boolValue {
                    if level < depth { walk(full, level + 1) }
                } else if pakExts.contains(full.pathExtension.lowercased()) {
                    if seen.contains(full.path) { continue }
                    seen.insert(full.path)
                    let attrs = try? fm.attributesOfItem(atPath: full.path)
                    let size = (attrs?[.size] as? NSNumber)?.int64Value ?? 0
                    out.append(PakItem(id: full.path, url: full, size: size))
                }
            }
        }

        walk(dir, 0)
        return out.sorted { $0.name < $1.name }
    }

    static func size(of url: URL) -> Int64 {
        let attrs = try? FileManager.default.attributesOfItem(atPath: url.path)
        return (attrs?[.size] as? NSNumber)?.int64Value ?? 0
    }

    static func uniqueURL(_ dir: URL, name: String) -> URL {
        let fm = FileManager.default
        var target = dir.appendingPathComponent(name)
        if !fm.fileExists(atPath: target.path) { return target }
        let base = (name as NSString).deletingPathExtension
        let ext = (name as NSString).pathExtension
        var i = 2
        while i < 999 {
            let n = ext.isEmpty ? "\(base)-\(i)" : "\(base)-\(i).\(ext)"
            target = dir.appendingPathComponent(n)
            if !fm.fileExists(atPath: target.path) { return target }
            i += 1
        }
        return dir.appendingPathComponent(UUID().uuidString + "-" + name)
    }

    static func describe(_ error: Error) -> String {
        let ns = error as NSError
        var s = ns.localizedDescription
        if ns.domain == NSURLErrorDomain {
            switch ns.code {
            case -1004: s = "连不上（对端没开服务或端口不对）"
            case -1001: s = "超时（网络没通）"
            case -1009: s = "设备没联网"
            case -1022: s = "系统拦了明文 http"
            default: break
            }
        }
        return s
    }

    static func freeSpaceText() -> String {
        let url = docDir()
        if let v = try? url.resourceValues(forKeys: [.volumeAvailableCapacityForImportantUsageKey]),
           let bytes = v.volumeAvailableCapacityForImportantUsage {
            return Fmt.size(bytes)
        }
        return "未知"
    }
}
