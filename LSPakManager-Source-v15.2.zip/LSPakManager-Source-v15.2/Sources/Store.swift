//
//  Store.swift
//  v15.2
//
//  这一版只有一件事：一个中转站，包在那里进出。
//
//  放包进中转站  → 自动送进游戏 Paks（不用点）
//  点「全部移出」→ 从 Paks 搬回同一个中转站（不用你再找地方）
//
//  全程只用 MOVE / PUT / GET，删除只在最后兜底，
//  所以「只能移动不能删除」的机器也照样跑得通。
//

import Foundation
import SwiftUI
import Combine

@MainActor
final class Store: ObservableObject {

    // ── 界面状态 ──
    @Published var logLines: [String] = []
    @Published var connected = false
    @Published var busy = false
    @Published var busyText = ""
    @Published var statusText = "未连接"
    @Published var gamePath: String? = nil
    @Published var records: [TransferRecord] = []

    // ── 中转站 / 自动 ──
    @Published var transitPath: String = ""
    @Published var autoOn: Bool = true
    @Published var autoPullAfter: Int = 0      // 0 = 不自动撤
    @Published var lastScanText = "还没扫"
    @Published var transitCount = 0
    @Published var landingCount = 0            // 中转站里被移出回来的包

    // ── 连接参数 ──
    @Published var host: String = "127.0.0.1"
    @Published var port: Int = 8888

    let bridge = FilzaBridge.shared

    private var handled: Set<String> = []
    private var pilotTask: Task<Void, Never>?
    private var importedAt: [String: Date] = [:]
    private var pulling = false

    private let kHost = "ls15.host"
    private let kPort = "ls15.port"
    private let kBase = "ls15.base"
    private let kGame = "ls15.game"
    private let kTransit = "ls15.transit"
    private let kAuto = "ls15.auto"
    private let kAutoPull = "ls15.autopull"
    private let kRecords = "ls15.records"
    private let kHandled = "ls15.handled"

    init() {
        LSPaths.ensureDirs()
        let d = UserDefaults.standard

        if let h = d.string(forKey: kHost), !h.isEmpty { host = h }
        let p = d.integer(forKey: kPort)
        if p > 0 { port = p }
        bridge.host = host
        bridge.port = port
        bridge.basePath = d.string(forKey: kBase) ?? ""

        if let g = d.string(forKey: kGame), !g.isEmpty { gamePath = g }
        if let t = d.string(forKey: kTransit), !t.isEmpty { transitPath = t }
        if d.object(forKey: kAuto) != nil { autoOn = d.bool(forKey: kAuto) }
        autoPullAfter = d.integer(forKey: kAutoPull)

        if let data = d.data(forKey: kRecords),
           let r = try? JSONDecoder().decode([TransferRecord].self, from: data) {
            records = r
        }
        if let arr = d.array(forKey: kHandled) as? [String] { handled = Set(arr) }
    }

    // MARK: - 日志

    func log(_ s: String) {
        logLines.append("\(Fmt.clock())  \(s)")
        if logLines.count > 200 { logLines.removeFirst(logLines.count - 200) }
    }

    func clearLog() { logLines.removeAll() }

    // MARK: - 连接

    func connect(autoprobe: Bool = true) async {
        guard !busy else { return }
        busy = true
        busyText = "正在连 Filza 服务"
        defer { busy = false }

        host = host.trimmingCharacters(in: .whitespaces)
        if host.isEmpty { host = "127.0.0.1" }
        bridge.host = host
        bridge.port = port

        log("连 \(host):\(port) …")
        let (ok, msg) = await bridge.ping(host: host, port: port)
        if ok {
            connected = true
            statusText = "已连上 Filza"
            saveConn()
            log("✓ \(msg)")
            if gamePath == nil { await locate(silent: true) }
            return
        }

        if autoprobe {
            log("这个端口没通，自动找一下别的端口…")
            busyText = "正在找 Filza 的端口"
            if let p = await bridge.probePorts() {
                port = p
                let (ok2, msg2) = await bridge.ping(host: host, port: p)
                if ok2 {
                    connected = true
                    statusText = "已连上 \(host):\(p)"
                    saveConn()
                    log("✓ 在 \(p) 端口找到服务")
                    log("✓ \(msg2)")
                    if gamePath == nil { await locate(silent: true) }
                    return
                }
            }
        }

        connected = false
        statusText = "没连上"
        log("✗ \(msg)")
        log("· 先确认 Filza 里的网络 / WiFi 服务开关是开的")
    }

    private func saveConn() {
        let d = UserDefaults.standard
        d.set(host, forKey: kHost)
        d.set(port, forKey: kPort)
        d.set(bridge.basePath, forKey: kBase)
    }

    // MARK: - 找游戏目录

    func locate(silent: Bool = false) async {
        guard connected else {
            if !silent { log("✗ 先连上 Filza 服务") }
            return
        }
        if !silent { busyText = "正在找游戏的 Paks 目录" }
        let r = await bridge.locateGame()
        switch r {
        case .success(let loc):
            gamePath = loc.paksRel
            UserDefaults.standard.set(loc.paksRel, forKey: kGame)
            log("✓ 找到游戏目录")
        case .failure(let why):
            gamePath = nil
            if !silent { log("✗ \(why.message)") }
        }
    }

    private func ensureGame() async -> String? {
        if let g = gamePath, !g.isEmpty { return g }
        let r = await bridge.locateGame()
        if case .success(let loc) = r {
            gamePath = loc.paksRel
            UserDefaults.standard.set(loc.paksRel, forKey: kGame)
            log("✓ 找到游戏目录")
            return loc.paksRel
        }
        if case .failure(let why) = r { log("✗ \(why.message)") }
        return nil
    }

    // MARK: - 中转站

    func setTransit(_ p: String) {
        var s = p.trimmingCharacters(in: .whitespaces)
        while s.count > 1 && s.hasSuffix("/") { s.removeLast() }
        transitPath = s
        UserDefaults.standard.set(s, forKey: kTransit)
        transitCount = 0
        log("· 中转站定为 \(s)")
        Task { await prepareTransit() }
    }

    /// 中转站不存在就建出来
    func prepareTransit() async {
        guard connected, !transitPath.isEmpty else { return }
        do {
            try await bridge.ensureDir(transitPath)
        } catch {
            log("· 中转站建不出来（可能已经有了）：\(LSPaths.describe(error))")
        }
        await refreshTransitCount()
    }

    func refreshTransitCount() async {
        guard connected, !transitPath.isEmpty else { transitCount = 0; return }
        let list = (try? await bridge.list(transitPath)) ?? []
        let files = list.filter {
            !$0.isDir && !$0.name.hasPrefix(".") &&
            LSPaths.pakExts.contains(($0.name as NSString).pathExtension.lowercased())
        }
        let pending = files.filter { !handled.contains($0.name) }
        transitCount = pending.count
        landingCount = files.count - pending.count
    }

    // MARK: - 自动巡逻

    func startPilot() {
        guard pilotTask == nil else { return }
        pilotTask = Task { [weak self] in
            while !Task.isCancelled {
                try? await Task.sleep(nanoseconds: 4_000_000_000)
                if Task.isCancelled { return }
                guard let me = self else { return }
                await me.pilotOnce()
            }
        }
    }

    func stopPilot() {
        pilotTask?.cancel()
        pilotTask = nil
    }

    private func pilotOnce() async {
        guard autoOn, connected, !busy, !transitPath.isEmpty else { return }
        await scanTransit(silent: true)
        if autoPullAfter > 0 { await autoPullDue() }
    }

    /// 扫中转站：有新包就送进游戏
    func scanTransit(silent: Bool = false) async {
        guard !busy else { return }
        guard connected else {
            if !silent { log("✗ 还没连上 Filza") }
            return
        }
        guard !transitPath.isEmpty else {
            if !silent { log("✗ 先选中转文件夹") }
            return
        }

        busy = true
        busyText = "检查中转站"
        defer { busy = false }

        var list: [RemoteEntry] = []
        do {
            list = try await bridge.list(transitPath)
        } catch {
            log("✗ 中转站打不开：\(LSPaths.describe(error))")
            return
        }
        lastScanText = Fmt.clock()

        let files = list.filter {
            !$0.isDir && !$0.name.hasPrefix(".") &&
            LSPaths.pakExts.contains(($0.name as NSString).pathExtension.lowercased())
        }
        let pending = files.filter { !handled.contains($0.name) }
        transitCount = pending.count
        landingCount = files.count - pending.count

        guard !pending.isEmpty else {
            if !silent {
                if files.isEmpty {
                    log("中转站里没有包")
                } else {
                    log("中转站里 \(files.count) 个包都是撤回来的，不会再送进去")
                    log("· 想重新送，点「清空处理名单」")
                }
            }
            return
        }

        guard let paks = await ensureGame() else { return }

        let existing = (try? await bridge.list(paks)) ?? []
        var sizeByName: [String: Int64] = [:]
        for e in existing where !e.isDir { sizeByName[e.name] = e.size }

        var pushed = 0
        var skipped = 0
        var failed = 0

        for f in pending {
            // 游戏里已经有同名、同大小 —— 就是这一份，不用再送
            if let s = sizeByName[f.name], s == f.size {
                handled.insert(f.name)
                persistHandled()
                skipped += 1
                continue
            }

            busyText = "送进游戏 \(f.name)"
            let src = "\(transitPath)/\(f.name)"
            let dst = "\(paks)/\(f.name)"

            do {
                try await pushOne(name: f.name, from: src, to: dst)
                pushed += 1
                importedAt[f.name] = Date()
                addRecord(name: f.name, size: f.size, direction: "导入",
                          remote: dst, ok: true, note: "中转站 → 游戏")
                log("↑ \(f.name)  \(Fmt.size(f.size))  → 进游戏")
            } catch {
                failed += 1
                let msg = LSPaths.describe(error)
                log("✗ \(f.name)：\(msg)")
                addRecord(name: f.name, size: f.size, direction: "导入",
                          remote: dst, ok: false, note: msg)
            }
        }

        if pushed + failed > 0 {
            log("扫完：进 \(pushed) · 跳过 \(skipped) · 失败 \(failed)")
        }
        await refreshTransitCount()
    }

    /// 先试一步 MOVE；服务不支持跨目录就退成下载 + 上传
    private func pushOne(name: String, from src: String, to dst: String) async throws {
        do {
            try await bridge.move(src, to: dst)
            return
        } catch {
            // 落到下面走退化路线
        }

        let tmp = LSPaths.tempDir().appendingPathComponent(name)
        try await bridge.download(src, to: tmp)
        try await bridge.upload(tmp, to: dst)
        try? FileManager.default.removeItem(at: tmp)

        // 中转站里那份挪进 _zaka_done（不删，你要找还能找回来）
        let done = "\(transitPath)/_zaka_done"
        try? await bridge.mkcol(done)
        try? await bridge.move(src, to: "\(done)/\(name)")
    }

    // MARK: - 移出（搬回中转站）

    /// 「全部移出」：把经我送进游戏的包，全部搬回中转站
    func exportAll() async {
        guard !busy else { return }
        guard connected else { log("✗ 还没连上 Filza"); return }
        guard !transitPath.isEmpty else { log("✗ 先选中转文件夹"); return }
        guard let paks = await ensureGame() else { return }

        let list = (try? await bridge.list(paks)) ?? []
        let mine = Set(records.filter { $0.direction == "导入" && $0.ok }
            .map { ($0.remotePath as NSString).lastPathComponent })
        let targets = list.filter { !$0.isDir && mine.contains($0.name) }.map { $0.name }

        guard !targets.isEmpty else {
            log("· 游戏里现在没有我送进去的包")
            return
        }
        await pull(names: targets)
    }

    private func pull(names: [String]) async {
        guard !pulling else { return }
        pulling = true
        let wasBusy = busy
        busy = true
        busyText = "正在搬回中转站"
        defer {
            busy = wasBusy
            pulling = false
        }

        guard let paks = await ensureGame() else { return }
        try? await bridge.ensureDir(transitPath)

        var ok = 0
        var failed = 0

        for (i, name) in names.enumerated() {
            busyText = "搬回 \(i + 1)/\(names.count)  \(name)"
            do {
                try await pullOne(name: name, paks: paks)
                ok += 1
                handled.insert(name)
                persistHandled()
                importedAt.removeValue(forKey: name)
                log("↓ \(name)  → 回到中转站")
                addRecord(name: name, size: 0, direction: "移出",
                          remote: "\(paks)/\(name)", ok: true,
                          note: "已回到 \(transitPath)")
            } catch {
                failed += 1
                let msg = LSPaths.describe(error)
                log("✗ \(name)：\(msg)")
                addRecord(name: name, size: 0, direction: "移出",
                          remote: "\(paks)/\(name)", ok: false, note: msg)
            }
        }

        log("搬回结束：成 \(ok) · 败 \(failed)")
        await refreshTransitCount()
    }

    private func pullOne(name: String, paks: String) async throws {
        let remote = "\(paks)/\(name)"
        let target = "\(transitPath)/\(name)"

        // 一步到位：直接从 Paks 移回中转站
        do {
            try await bridge.move(remote, to: target)
            return
        } catch {
            // 跨容器不让 MOVE，就下载再传
        }

        let tmp = LSPaths.tempDir().appendingPathComponent(name)
        try await bridge.download(remote, to: tmp)
        try await bridge.upload(tmp, to: target)

        // 游戏目录那份拿掉：先挪进 _zaka_out，挪不动才删
        let hide = "\(paks)/_zaka_out"
        try? await bridge.mkcol(hide)
        do {
            try await bridge.move(remote, to: "\(hide)/\(name)")
        } catch {
            try? await bridge.delete(remote)
        }

        // 本地也留一份，文件 App 里能直接看见
        let local = LSPaths.uniqueURL(LSPaths.outDir(), name: name)
        try? FileManager.default.copyItem(at: tmp, to: local)
        try? FileManager.default.removeItem(at: tmp)
    }

    /// 进游戏后到点了，自动撤出来（默认关）
    private func autoPullDue() async {
        let now = Date()
        let due = importedAt.filter {
            now.timeIntervalSince($0.value) >= Double(autoPullAfter)
        }.map { $0.key }

        guard !due.isEmpty else { return }
        for n in due { importedAt.removeValue(forKey: n) }
        log("· 到点了，自动搬回 \(due.count) 个")
        await pull(names: due)
    }

    // MARK: - 给选择器用

    func remoteList(_ path: String) async -> ([RemoteEntry], String) {
        guard connected else { return ([], "还没连上 Filza") }
        do {
            return (try await bridge.list(path), "")
        } catch {
            return ([], LSPaths.describe(error))
        }
    }

    // MARK: - 处理名单

    private func persistHandled() {
        if handled.count > 800 {
            handled = Set(Array(handled).suffix(800))
        }
        UserDefaults.standard.set(Array(handled), forKey: kHandled)
    }

    func resetHandled() {
        handled.removeAll()
        importedAt.removeAll()
        UserDefaults.standard.removeObject(forKey: kHandled)
        log("· 处理名单已清空，中转站里的包下次会被当成新包")
    }

    // MARK: - 记录

    private func addRecord(name: String, size: Int64, direction: String,
                           remote: String, ok: Bool, note: String = "") {
        records.append(TransferRecord(name: name,
                                      direction: direction,
                                      remotePath: remote,
                                      size: size,
                                      time: Fmt.shortDate(),
                                      ok: ok,
                                      note: note))
        if records.count > 300 { records.removeFirst(records.count - 300) }
        if let data = try? JSONEncoder().encode(records) {
            UserDefaults.standard.set(data, forKey: kRecords)
        }
    }

    func clearRecords() {
        records.removeAll()
        UserDefaults.standard.removeObject(forKey: kRecords)
    }

    // MARK: - 存设置

    func saveAuto() {
        let d = UserDefaults.standard
        d.set(autoOn, forKey: kAuto)
        d.set(autoPullAfter, forKey: kAutoPull)
    }

    // MARK: - 自检

    func diagnose() async {
        guard !busy else { return }
        busy = true
        busyText = "正在自检"
        defer { busy = false }

        log("── 自检 ──")
        log("系统 \(Compatibility.shortSystem()) · \(Compatibility.hardwareModel())")
        log("服务 \(bridge.endpoint)  根 \(bridge.basePath.isEmpty ? "/" : bridge.basePath)")
        log("中转站 \(transitPath.isEmpty ? "（没选）" : transitPath)")

        guard connected else {
            log("· 服务没连上，先点「连接」")
            return
        }

        if !transitPath.isEmpty {
            if let l = try? await bridge.list(transitPath) {
                log("中转站里 \(l.count) 项")
                for e in l.prefix(10) { log("  \(e.isDir ? "📁" : "📄") \(e.name)  \(e.sizeText)") }
            } else {
                log("中转站打不开")
            }
        }

        if let g = gamePath {
            if let l = try? await bridge.list(g) {
                log("Paks 里 \(l.count) 项")
                for e in l.prefix(10) { log("  \(e.isDir ? "📁" : "📄") \(e.name)  \(e.sizeText)") }
            } else {
                log("Paks 列不出")
            }
        }
    }
}
