//
//  Models.swift
//  v14.0
//

import Foundation

/// 本地一个 pak / sig 文件
struct PakItem: Identifiable, Hashable {
    let id: String          // 完整路径，稳定 id
    let url: URL
    let size: Int64

    var name: String { url.lastPathComponent }
    var sizeText: String { Fmt.size(size) }
    var ext: String { url.pathExtension.lowercased() }
}

/// 远程（游戏目录里）一个文件或文件夹
struct RemoteEntry: Identifiable, Hashable {
    var id: String { path }
    let path: String
    let name: String
    let isDir: Bool
    let size: Int64

    var sizeText: String { isDir ? "文件夹" : Fmt.size(size) }
}

enum Fmt {
    static func size(_ b: Int64) -> String {
        let f = ByteCountFormatter()
        f.countStyle = .file
        f.allowedUnits = [.useMB, .useKB, .useGB]
        return f.string(fromByteCount: b)
    }

    static func clock() -> String {
        let f = DateFormatter()
        f.dateFormat = "HH:mm:ss"
        return f.string(from: Date())
    }

    static func stamp() -> String {
        let f = DateFormatter()
        f.dateFormat = "yyyyMMdd-HHmmss"
        return f.string(from: Date())
    }

    static func shortDate() -> String {
        let f = DateFormatter()
        f.dateFormat = "MM-dd HH:mm"
        return f.string(from: Date())
    }
}

/// 一条搬运记录：谁、从哪、到哪、成没成
struct TransferRecord: Identifiable, Codable, Hashable {
    var id: String = UUID().uuidString
    var name: String
    var direction: String        // 导入 / 移出
    var remotePath: String
    var size: Int64
    var time: String
    var ok: Bool
    var note: String = ""

    var sizeText: String { Fmt.size(size) }
}
