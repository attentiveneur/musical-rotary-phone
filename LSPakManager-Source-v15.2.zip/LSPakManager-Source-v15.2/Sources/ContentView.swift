//
//  ContentView.swift
//  v15.2
//
//  界面只有三块：连上没有 / 中转站在哪 / 一个撤出按钮。
//  没有改包、没有换字、没有内核。
//

import SwiftUI
import UIKit

let colorHUD   = Color(red: 0.20, green: 0.86, blue: 0.60)
let colorAmber = Color(red: 1.00, green: 0.66, blue: 0.24)
let colorCard  = Color.white.opacity(0.055)
let colorLine  = Color.white.opacity(0.10)

struct ContentView: View {

    @EnvironmentObject private var store: Store
    @Environment(\.scenePhase) private var scenePhase

    @State private var portText = ""
    @State private var didAppear = false
    @State private var showPicker = false
    @State private var showAdvanced = false

    var body: some View {
        ZStack {
            BackgroundLayer()

            ScrollView {
                VStack(spacing: 12) {
                    header
                    statusCard
                    transitCard
                    autoCard
                    exportButton
                    logCard
                    advancedCard
                }
                .padding(.horizontal, 14)
                .padding(.top, 10)
                .padding(.bottom, 30)
            }
        }
        .preferredColorScheme(.dark)
        .sheet(isPresented: $showPicker) {
            DirPicker(initial: store.transitPath) { picked in
                store.setTransit(picked)
            }
            .environmentObject(store)
        }
        .onAppear {
            if portText.isEmpty { portText = String(store.port) }
            if !didAppear {
                didAppear = true
                store.log("· 浪神搬运 v15.2 · \(Compatibility.shortSystem())")
                store.log("· 一个中转站，进出都走它")
                Task {
                    await store.connect()
                    await store.prepareTransit()
                    if store.autoOn { await store.scanTransit(silent: true) }
                }
            }
            if store.autoOn { store.startPilot() }
        }
        .onChange(of: scenePhase) { ph in
            if ph == .active {
                if store.autoOn { store.startPilot() }
                Task { await store.refreshTransitCount() }
            } else {
                store.stopPilot()
            }
        }
    }

    // MARK: - 顶

    private var header: some View {
        VStack(alignment: .leading, spacing: 3) {
            Text("浪神搬运")
                .font(.system(size: 24, weight: .heavy))
                .foregroundColor(.white)
            Text("v15.2 · 一个中转站 · 自动进出")
                .font(.system(size: 11, weight: .semibold))
                .foregroundColor(colorHUD.opacity(0.85))
        }
        .frame(maxWidth: .infinity, alignment: .leading)
    }

    // MARK: - 状态

    private var statusCard: some View {
        HStack(spacing: 10) {
            Circle()
                .fill(store.connected ? colorHUD : Color.orange)
                .frame(width: 8, height: 8)
                .shadow(color: (store.connected ? colorHUD : .orange).opacity(0.9), radius: 6)

            VStack(alignment: .leading, spacing: 2) {
                Text(store.busy ? store.busyText : store.statusText)
                    .font(.system(size: 13, weight: .bold))
                    .foregroundColor(.white)
                Text(store.gamePath == nil ? "游戏目录：还没找到" : "游戏目录：已记住")
                    .font(.system(size: 10.5))
                    .foregroundColor(.white.opacity(0.55))
                    .lineLimit(1)
            }
            Spacer()
            Button {
                Task { await store.connect(); await store.prepareTransit() }
            } label: {
                Text("连接")
                    .font(.system(size: 12, weight: .bold))
                    .padding(.horizontal, 12).padding(.vertical, 7)
                    .background(colorHUD.opacity(0.16))
                    .foregroundColor(colorHUD)
                    .clipShape(Capsule())
            }
            .disabled(store.busy)
        }
        .padding(12)
        .background(colorCard)
        .overlay(RoundedRectangle(cornerRadius: 12).stroke(colorLine, lineWidth: 1))
        .cornerRadius(12)
    }

    // MARK: - 中转站

    private var transitCard: some View {
        VStack(alignment: .leading, spacing: 8) {
            HStack {
                Text("中转站")
                    .font(.system(size: 11.5, weight: .bold))
                    .foregroundColor(.white.opacity(0.55))
                Spacer()
                Button {
                    showPicker = true
                } label: {
                    Text("换")
                        .font(.system(size: 12, weight: .bold))
                        .padding(.horizontal, 12).padding(.vertical, 5)
                        .background(colorHUD.opacity(0.16))
                        .foregroundColor(colorHUD)
                        .clipShape(Capsule())
                }
            }

            Text(store.transitPath.isEmpty ? "还没选（点右上角「换」挑一个文件夹）" : store.transitPath)
                .font(.system(size: 11.5, design: .monospaced))
                .foregroundColor(store.transitPath.isEmpty ? Color.orange.opacity(0.85) : .white)
                .lineLimit(3)
                .frame(maxWidth: .infinity, alignment: .leading)

            VStack(alignment: .leading, spacing: 3) {
                Text("包放进这里 → 自动进游戏")
                    .font(.system(size: 10.5))
                    .foregroundColor(colorHUD.opacity(0.85))
                Text("撤出来的包 → 自动回到这里")
                    .font(.system(size: 10.5))
                    .foregroundColor(colorAmber.opacity(0.85))
            }

            HStack(spacing: 8) {
                countBox("待进游戏", store.transitCount, colorHUD)
                countBox("已撤回", store.landingCount, colorAmber)
                countBox("上次检查", -1, .white.opacity(0.7))
            }
        }
        .padding(12)
        .background(colorCard)
        .overlay(RoundedRectangle(cornerRadius: 12).stroke(colorLine, lineWidth: 1))
        .cornerRadius(12)
    }

    private func countBox(_ title: String, _ n: Int, _ c: Color) -> some View {
        VStack(spacing: 1) {
            if n < 0 {
                Text(store.lastScanText)
                    .font(.system(size: 12.5, weight: .heavy, design: .rounded))
                    .foregroundColor(c)
            } else {
                Text("\(n)")
                    .font(.system(size: 16, weight: .heavy, design: .rounded))
                    .foregroundColor(c)
            }
            Text(title)
                .font(.system(size: 9.5, weight: .semibold))
                .foregroundColor(.white.opacity(0.45))
        }
        .frame(maxWidth: .infinity)
        .padding(.vertical, 8)
        .background(Color.white.opacity(0.045))
        .cornerRadius(9)
    }

    // MARK: - 自动

    private var autoCard: some View {
        VStack(spacing: 10) {
            HStack {
                VStack(alignment: .leading, spacing: 2) {
                    Text("自动搬运")
                        .font(.system(size: 13, weight: .bold))
                        .foregroundColor(.white)
                    Text(store.autoOn ? "开：放进去就自己送，不用点" : "关：只在你点的时候动")
                        .font(.system(size: 10))
                        .foregroundColor(.white.opacity(0.5))
                }
                Spacer()
                Toggle("", isOn: $store.autoOn)
                    .labelsHidden()
                    .onChange(of: store.autoOn) { v in
                        store.saveAuto()
                        if v { store.startPilot() } else { store.stopPilot() }
                    }
            }

            Divider().background(Color.white.opacity(0.08))

            HStack {
                Text("进游戏后自动撤出")
                    .font(.system(size: 11.5, weight: .semibold))
                    .foregroundColor(.white.opacity(0.75))
                Spacer()
                Picker("", selection: $store.autoPullAfter) {
                    Text("不撤").tag(0)
                    Text("30秒").tag(30)
                    Text("1分").tag(60)
                    Text("5分").tag(300)
                }
                .pickerStyle(.segmented)
                .frame(width: 190)
                .onChange(of: store.autoPullAfter) { _ in store.saveAuto() }
            }
        }
        .padding(12)
        .background(colorCard)
        .overlay(RoundedRectangle(cornerRadius: 12).stroke(colorLine, lineWidth: 1))
        .cornerRadius(12)
    }

    // MARK: - 大按钮

    private var exportButton: some View {
        Button {
            Task { await store.exportAll() }
        } label: {
            HStack(spacing: 10) {
                VStack(alignment: .leading, spacing: 3) {
                    Text("全部移出")
                        .font(.system(size: 18, weight: .heavy))
                        .foregroundColor(.black)
                    Text("把送进游戏的包搬回中转站")
                        .font(.system(size: 10.5, weight: .medium))
                        .foregroundColor(.black.opacity(0.62))
                }
                Spacer()
                Image(systemName: "arrow.down.to.line")
                    .font(.system(size: 20, weight: .heavy))
                    .foregroundColor(.black.opacity(0.7))
            }
            .padding(.horizontal, 15)
            .padding(.vertical, 14)
            .frame(maxWidth: .infinity)
            .background(
                LinearGradient(colors: [colorAmber, colorAmber.opacity(0.78)],
                               startPoint: .topLeading, endPoint: .bottomTrailing)
            )
            .cornerRadius(14)
            .shadow(color: colorAmber.opacity(store.busy ? 0 : 0.32), radius: 12, y: 4)
        }
        .disabled(store.busy)
        .opacity(store.busy ? 0.55 : 1)
    }

    // MARK: - 日志

    private var logCard: some View {
        VStack(alignment: .leading, spacing: 6) {
            HStack {
                Text("运行记录")
                    .font(.system(size: 11.5, weight: .bold))
                    .foregroundColor(.white.opacity(0.55))
                Spacer()
                Button {
                    store.clearLog()
                } label: {
                    Text("清空")
                        .font(.system(size: 10.5, weight: .semibold))
                        .foregroundColor(.white.opacity(0.4))
                }
            }

            if store.logLines.isEmpty {
                Text("等一下，正在自动连…")
                    .font(.system(size: 10.5, design: .monospaced))
                    .foregroundColor(.white.opacity(0.3))
                    .frame(maxWidth: .infinity, alignment: .leading)
                    .padding(.vertical, 6)
            } else {
                VStack(alignment: .leading, spacing: 3) {
                    ForEach(logRows) { row in
                        Text(row.text)
                            .font(.system(size: 10, design: .monospaced))
                            .foregroundColor(lineColor(row.text))
                            .frame(maxWidth: .infinity, alignment: .leading)
                            .fixedSize(horizontal: false, vertical: true)
                    }
                }
            }
        }
        .padding(11)
        .background(colorCard)
        .overlay(RoundedRectangle(cornerRadius: 12).stroke(colorLine, lineWidth: 1))
        .cornerRadius(12)
    }

    private var logRows: [LogRow] {
        var out: [LogRow] = []
        let tail = store.logLines.suffix(60)
        var i = 0
        for t in tail {
            out.append(LogRow(id: i, text: t))
            i += 1
        }
        return out
    }

    private func lineColor(_ s: String) -> Color {
        if s.contains("✓") { return colorHUD }
        if s.contains("✗") { return Color(red: 1, green: 0.45, blue: 0.4) }
        if s.contains("↑") { return colorHUD }
        if s.contains("↓") { return colorAmber }
        return Color.white.opacity(0.62)
    }

    // MARK: - 高级

    private var advancedCard: some View {
        VStack(spacing: 8) {
            Button {
                withAnimation(.easeInOut(duration: 0.16)) { showAdvanced.toggle() }
            } label: {
                HStack {
                    Text("高级")
                        .font(.system(size: 11.5, weight: .bold))
                        .foregroundColor(.white.opacity(0.5))
                    Spacer()
                    Image(systemName: showAdvanced ? "chevron.up" : "chevron.down")
                        .font(.system(size: 10, weight: .bold))
                        .foregroundColor(.white.opacity(0.35))
                }
            }

            if showAdvanced {
                HStack(spacing: 8) {
                    Text("地址")
                        .font(.system(size: 11, weight: .bold))
                        .foregroundColor(.white.opacity(0.5))
                    TextField("127.0.0.1", text: $store.host)
                        .font(.system(size: 12, design: .monospaced))
                        .foregroundColor(.white)
                        .textInputAutocapitalization(.never)
                        .autocorrectionDisabled(true)
                        .keyboardType(.URL)
                        .padding(7)
                        .background(Color.white.opacity(0.06))
                        .cornerRadius(7)

                    Text("端口")
                        .font(.system(size: 11, weight: .bold))
                        .foregroundColor(.white.opacity(0.5))
                    TextField("8888", text: $portText)
                        .font(.system(size: 12, design: .monospaced))
                        .foregroundColor(.white)
                        .keyboardType(.numberPad)
                        .frame(width: 62)
                        .padding(7)
                        .background(Color.white.opacity(0.06))
                        .cornerRadius(7)
                }

                HStack(spacing: 8) {
                    smallButton("测试连接") {
                        store.port = Int(portText) ?? 8888
                        Task { await store.connect() }
                    }
                    smallButton("找游戏目录") {
                        Task { await store.locate() }
                    }
                    smallButton("自检") {
                        Task { await store.diagnose() }
                    }
                }

                HStack(spacing: 8) {
                    smallButton("立刻扫一次") {
                        Task { await store.scanTransit() }
                    }
                    smallButton("清空处理名单") {
                        store.resetHandled()
                        Task { await store.refreshTransitCount() }
                    }
                }
            }
        }
        .padding(11)
        .background(colorCard)
        .overlay(RoundedRectangle(cornerRadius: 12).stroke(colorLine, lineWidth: 1))
        .cornerRadius(12)
    }

    private func smallButton(_ title: String, _ action: @escaping () -> Void) -> some View {
        Button(action: action) {
            Text(title)
                .font(.system(size: 11.5, weight: .bold))
                .frame(maxWidth: .infinity)
                .padding(.vertical, 8)
                .background(Color.white.opacity(0.07))
                .foregroundColor(.white.opacity(0.85))
                .cornerRadius(8)
        }
        .disabled(store.busy)
    }
}

struct LogRow: Identifiable {
    let id: Int
    let text: String
}

// MARK: - 分享

struct ShareSheet: UIViewControllerRepresentable {
    let items: [Any]
    func makeUIViewController(context: Context) -> UIActivityViewController {
        UIActivityViewController(activityItems: items, applicationActivities: nil)
    }
    func updateUIViewController(_ c: UIActivityViewController, context: Context) {}
}
