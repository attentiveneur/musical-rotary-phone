//
//  FilzaBridge.swift
//  v14.0
//
//  这一层是整版的全部关键：借 Filza 自己的网络服务去碰游戏目录。
//
//  为什么这么干：
//  自签 App 没有游戏的沙盒授权，系统一律回「Operation not permitted」。
//  但 Filza 那个网络服务是跑在 Filza 进程里的——它有什么权限，这个服务就有什么权限。
//  我们在自己 App 里发一条本机 http 请求给它，等于借了它的手。
//  于是「进 Paks」「出 Paks」都不用你在 Filza 里手动点了。
//
//  支持 WebDAV（PROPFIND / PUT / GET / MOVE / DELETE），
//  外加自动找端口、自动找游戏容器。
//

import Foundation

enum BridgeError: LocalizedError {
    case notConnected
    case http(Int, String)
    case badResponse(String)
    case noService

    var errorDescription: String? {
        switch self {
        case .notConnected:
            return "还没连上 Filza"
        case .http(let code, let msg):
            return msg.isEmpty ? "服务返回 \(code)" : "服务返回 \(code)：\(msg)"
        case .badResponse(let s):
            return s
        case .noService:
            return "这个端口上没有文件服务"
        }
    }
}

/// Result 的失败类型必须符合 Error 协议（Swift 规定），不能直接用 String。
/// 所以把「找不到游戏目录」这类失败包一层。
struct BridgeFailure: Error {
    let message: String
    init(_ message: String) { self.message = message }
}

final class FilzaBridge {

    static let shared = FilzaBridge()

    /// Filza 网络服务地址
    var host: String = "127.0.0.1"
    var port: Int = 8888
    /// 服务根目录相对路径（自动探测出来的，比如 "private/var/mobile"）
    var basePath: String = ""

    private let session: URLSession

    private init() {
        let cfg = URLSessionConfiguration.ephemeral
        cfg.timeoutIntervalForRequest = 20
        cfg.timeoutIntervalForResource = 900
        cfg.httpShouldSetCookies = false
        cfg.requestCachePolicy = .reloadIgnoringLocalAndRemoteCacheData
        session = URLSession(configuration: cfg)
    }

    // MARK: - 地址

    var endpoint: String { "http://\(host):\(port)" }

    private func makeURL(_ path: String) -> URL? {
        var p = path
        if !p.hasPrefix("/") { p = "/" + p }
        // 已经带着服务根前缀的，就不再重复拼
        var already = false
        if !basePath.isEmpty {
            let b = "/" + basePath.trimmingCharacters(in: CharacterSet(charactersIn: "/"))
            if p == b || p.hasPrefix(b + "/") { already = true }
        }
        let full: String
        if already || basePath.isEmpty {
            full = p
        } else {
            let b = basePath.trimmingCharacters(in: CharacterSet(charactersIn: "/"))
            full = "/" + b + p
        }

        // 路径分段编码，保留 "/"
        let encoded = full.split(separator: "/", omittingEmptySubsequences: false)
            .map { seg -> String in
                let s = String(seg)
                return s.addingPercentEncoding(withAllowedCharacters: .urlPathAllowed) ?? s
            }
            .joined(separator: "/")

        return URL(string: endpoint + encoded)
    }

    // MARK: - 基础请求

    private func request(_ method: String, _ path: String, headers: [String: String] = [:]) throws -> URLRequest {
        guard let url = makeURL(path) else { throw BridgeError.badResponse("路径写不成地址：\(path)") }
        var r = URLRequest(url: url)
        r.httpMethod = method
        for (k, v) in headers { r.setValue(v, forHTTPHeaderField: k) }
        return r
    }

    // MARK: - 连接测试

    /// 能不能连上、是不是文件服务
    func ping(host: String? = nil, port: Int? = nil) async -> (Bool, String) {
        if let h = host { self.host = h }
        if let p = port { self.port = p }

        var lastErr = ""
        for base in Self.baseCandidates {
            self.basePath = base
            do {
                _ = try await propfind("/", depth: 0)
                return (true, base.isEmpty ? "已连通（根目录）" : "已连通（\(base)）")
            } catch {
                if let be = error as? BridgeError, case .http(let code, _) = be {
                    if code == 401 || code == 403 {
                        return (false, "端口通了，但服务要账号密码（\(code)）")
                    }
                    lastErr = "服务返回 \(code)"
                } else {
                    lastErr = LSPaths.describe(error)
                }
                continue
            }
        }
        self.basePath = ""

        // 端口能通、但 PROPFIND 不认 —— 说明它在跑，只是不是 WebDAV 模式
        if await plainHTTPWorks() {
            return (false, "端口通着，但这个模式不支持自动读写；换成 WebDAV 模式再点连接")
        }
        return (false, "连不上 \(host ?? self.host):\(port ?? self.port)（\(lastErr)）")
    }

    /// 端口上是不是有个普通的网页服务在跑
    private func plainHTTPWorks() async -> Bool {
        guard let url = URL(string: "http://\(host):\(port)/") else { return false }
        var r = URLRequest(url: url)
        r.httpMethod = "GET"
        r.timeoutInterval = 3
        do {
            let (_, resp) = try await session.data(for: r)
            guard let http = resp as? HTTPURLResponse else { return false }
            return (200...399).contains(http.statusCode)
        } catch {
            return false
        }
    }

    /// 服务根目录的几种可能写法，挨个试
    static let baseCandidates = [
        "",
        "private/var/mobile",
        "var/mobile"
    ]

    // MARK: - 列目录

    func propfind(_ path: String, depth: Int) async throws -> [RemoteEntry] {
        let req = try request("PROPFIND", path, headers: [
            "Depth": depth == 0 ? "0" : "1",
            "Content-Type": "application/xml; charset=utf-8"
        ])
        let body = """
        <?xml version="1.0" encoding="utf-8"?>
        <D:propfind xmlns:D="DAV:"><D:prop>
        <D:resourcetype/><D:getcontentlength/><D:displayname/><D:getcontenttype/>
        </D:prop></D:propfind>
        """
        var r = req
        r.httpBody = body.data(using: .utf8)

        let (data, resp) = try await session.data(for: r)
        guard let http = resp as? HTTPURLResponse else { throw BridgeError.badResponse("没有 http 回应") }
        guard (200...299).contains(http.statusCode) || http.statusCode == 207 else {
            throw BridgeError.http(http.statusCode, Self.snippet(data))
        }
        return XMLMultiStatus.parse(data)
    }

    /// 列一个目录里的东西（不含自己）
    func list(_ path: String) async throws -> [RemoteEntry] {
        let all = try await propfind(path, depth: 1)
        let selfPath = normalize(path)
        return all.filter { normalize($0.path) != selfPath }
    }

    /// 这个路径存不存在（能 PROPFIND 通就算存在）
    func exists(_ path: String) async -> Bool {
        do {
            _ = try await propfind(path, depth: 0)
            return true
        } catch {
            return false
        }
    }

    private func normalize(_ p: String) -> String {
        var s = p
        if let r = s.range(of: "://") {
            // 绝对 URL，砍掉 scheme://host 部分
            s = String(s[r.upperBound...])
            if let slash = s.firstIndex(of: "/") { s = String(s[slash...]) }
        }
        while s.count > 1 && s.hasSuffix("/") { s.removeLast() }
        return s.removingPercentEncoding ?? s
    }

    static func snippet(_ d: Data) -> String {
        let s = String(data: d.prefix(160), encoding: .utf8) ?? ""
        return s.replacingOccurrences(of: "\n", with: " ").trimmingCharacters(in: .whitespaces)
    }

    // MARK: - 上传

    func upload(_ local: URL, to remotePath: String) async throws {
        let req = try request("PUT", remotePath, headers: [
            "Content-Type": "application/octet-stream"
        ])
        let (data, resp) = try await session.upload(for: req, fromFile: local)
        guard let http = resp as? HTTPURLResponse else { throw BridgeError.badResponse("没有 http 回应") }
        guard (200...299).contains(http.statusCode) || http.statusCode == 201 || http.statusCode == 204 else {
            throw BridgeError.http(http.statusCode, Self.snippet(data))
        }
    }

    // MARK: - 下载

    func download(_ remotePath: String, to local: URL) async throws {
        let req = try request("GET", remotePath)
        let (tmp, resp) = try await session.download(for: req)
        guard let http = resp as? HTTPURLResponse else { throw BridgeError.badResponse("没有 http 回应") }
        guard (200...299).contains(http.statusCode) else {
            throw BridgeError.http(http.statusCode, "取文件失败")
        }
        let fm = FileManager.default
        try? fm.removeItem(at: local)
        try fm.moveItem(at: tmp, to: local)
    }

    func fetchData(_ remotePath: String) async throws -> Data {
        let req = try request("GET", remotePath)
        let (data, resp) = try await session.data(for: req)
        guard let http = resp as? HTTPURLResponse else { throw BridgeError.badResponse("没有 http 回应") }
        guard (200...299).contains(http.statusCode) else {
            throw BridgeError.http(http.statusCode, "取内容失败")
        }
        return data
    }

    // MARK: - 移动 / 删除

    func move(_ from: String, to: String) async throws {
        guard let dst = makeURL(to) else { throw BridgeError.badResponse("目标路径不合法") }
        let req = try request("MOVE", from, headers: [
            "Destination": dst.absoluteString,
            "Overwrite": "T"
        ])
        let (data, resp) = try await session.data(for: req)
        guard let http = resp as? HTTPURLResponse else { throw BridgeError.badResponse("没有 http 回应") }
        guard (200...299).contains(http.statusCode) || http.statusCode == 201 || http.statusCode == 204 else {
            throw BridgeError.http(http.statusCode, Self.snippet(data))
        }
    }

    func delete(_ path: String) async throws {
        let req = try request("DELETE", path)
        let (data, resp) = try await session.data(for: req)
        guard let http = resp as? HTTPURLResponse else { throw BridgeError.badResponse("没有 http 回应") }
        guard (200...299).contains(http.statusCode) || http.statusCode == 204 else {
            throw BridgeError.http(http.statusCode, Self.snippet(data))
        }
    }

    /// 一层层建好目录（已存在不算错）
    func ensureDir(_ path: String) async throws {
        let parts = path.split(separator: "/").map(String.init)
        guard !parts.isEmpty else { return }
        var cur = ""
        for p in parts {
            cur += "/" + p
            do { try await mkcol(cur) } catch { /* 多半是已存在，忽略 */ }
        }
    }

    func mkcol(_ path: String) async throws {
        let req = try request("MKCOL", path)
        let (data, resp) = try await session.data(for: req)
        guard let http = resp as? HTTPURLResponse else { throw BridgeError.badResponse("没有 http 回应") }
        // 405 = 已经存在，不算错
        guard (200...299).contains(http.statusCode) || http.statusCode == 405 else {
            throw BridgeError.http(http.statusCode, Self.snippet(data))
        }
    }

    // MARK: - 找游戏目录

    /// 游戏 Paks 目录在服务里的相对路径（相对服务根）
    struct GameLocation {
        let containerRel: String     // Containers/Data/Application/<UUID>
        let paksRel: String          // .../Documents/ShadowTrackerExtra/Saved/Paks
    }

    /// 挨个 UUID 试，谁有 Documents/ShadowTrackerExtra/Saved/Paks 就是游戏
    func locateGame() async -> Result<GameLocation, BridgeFailure> {
        let roots = ["Containers/Data/Application", "/private/var/mobile/Containers/Data/Application"]
        var rootUsed: String? = nil
        var uuids: [String] = []

        for r in roots {
            if let entries = try? await propfind(r, depth: 1), entries.count > 2 {
                rootUsed = r
                uuids = entries.filter { $0.isDir }.map { $0.name }.filter { $0.count >= 32 }
                break
            }
        }
        guard let root = rootUsed, !uuids.isEmpty else {
            return .failure(BridgeFailure("列不出 App 容器目录（Containers/Data/Application）。服务根可能不是「本地」。"))
        }

        let suffix = "Documents/ShadowTrackerExtra/Saved/Paks"
        var found: String? = nil

        // 串行敲，别一次打几百个请求把服务打崩；命中就立刻停
        for u in uuids {
            let p = "\(root)/\(u)/\(suffix)"
            if await exists(p) { found = u; break }
        }

        guard let uuid = found else {
            return .failure(BridgeFailure("扫完 \(uuids.count) 个容器，没找到和平精英的 Paks 目录。游戏可能没装在这台机器上，或者组件名不一样。"))
        }

        let containerRel = "\(root)/\(uuid)"
        return .success(GameLocation(containerRel: containerRel,
                                    paksRel: "\(containerRel)/\(suffix)"))
    }

    // MARK: - 端口探测

    /// 常见端口，逐个敲
    static let commonPorts: [Int] = [8888, 8080, 8090, 8000, 9000, 4040, 1234, 5000, 3000, 7000, 9999, 8008, 2019, 888, 80]

    /// 自动找 Filza 的服务端口
    func probePorts(extra: [Int] = []) async -> Int? {
        let candidates = Array(Set(Self.commonPorts + extra)).sorted()
        for p in candidates {
            if await quickProbe(port: p) { return p }
        }
        return nil
    }

    private func quickProbe(port: Int) async -> Bool {
        guard let url = URL(string: "http://\(host):\(port)/") else { return false }
        var r = URLRequest(url: url)
        r.httpMethod = "PROPFIND"
        r.timeoutInterval = 2.0
        r.setValue("0", forHTTPHeaderField: "Depth")
        r.httpBody = """
        <?xml version="1.0"?><D:propfind xmlns:D="DAV:"><D:prop><D:resourcetype/></D:prop></D:propfind>
        """.data(using: .utf8)
        do {
            let (_, resp) = try await session.data(for: r)
            guard let http = resp as? HTTPURLResponse else { return false }
            return (200...299).contains(http.statusCode) || http.statusCode == 207
        } catch {
            return false
        }
    }
}

// MARK: - PROPFIND XML 解析

final class XMLMultiStatus: NSObject, XMLParserDelegate {

    static func parse(_ data: Data) -> [RemoteEntry] {
        let p = XMLParser(data: data)
        p.shouldProcessNamespaces = true
        let d = XMLMultiStatus()
        p.delegate = d
        p.parse()
        return d.entries
    }

    private var entries: [RemoteEntry] = []
    private var inResponse = false
    private var currentHref = ""
    private var currentLen: Int64 = 0
    private var isCollection = false
    private var text = ""

    func parser(_ parser: XMLParser, didStartElement elementName: String,
                namespaceURI: String?, qualifiedName qName: String?,
                attributes attributeDict: [String: String] = [:]) {
        text = ""
        switch elementName {
        case "response":
            inResponse = true
            currentHref = ""
            currentLen = 0
            isCollection = false
        case "collection":
            isCollection = true
        default:
            break
        }
    }

    func parser(_ parser: XMLParser, foundCharacters string: String) {
        text += string
    }

    func parser(_ parser: XMLParser, didEndElement elementName: String,
                namespaceURI: String?, qualifiedName qName: String?) {
        guard inResponse else { return }
        switch elementName {
        case "href":
            if currentHref.isEmpty { currentHref = text.trimmingCharacters(in: .whitespacesAndNewlines) }
        case "getcontentlength":
            currentLen = Int64(text.trimmingCharacters(in: .whitespacesAndNewlines)) ?? 0
        case "response":
            inResponse = false
            appendEntry()
        default:
            break
        }
        text = ""
    }

    private func appendEntry() {
        var path = currentHref
        if let r = path.range(of: "://") {
            path = String(path[r.upperBound...])
            if let s = path.firstIndex(of: "/") { path = String(path[s...]) }
        }
        path = path.removingPercentEncoding ?? path
        while path.count > 1 && path.hasSuffix("/") { path.removeLast() }
        guard !path.isEmpty else { return }

        let name = (path as NSString).lastPathComponent
        entries.append(RemoteEntry(path: path,
                                   name: name.isEmpty ? path : name,
                                   isDir: isCollection,
                                   size: currentLen))
    }
}
